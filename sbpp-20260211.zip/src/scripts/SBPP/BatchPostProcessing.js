

#feature-id    Skynet Observatory > Batch Post-Processing v2

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/DataType.jsh>


#define DEFAULT_AUTOSTRETCH_SCLIP  -2.80
#define DEFAULT_AUTOSTRETCH_TBGND   0.25
#define DEFAULT_AUTOSTRETCH_CLINK   true

(function () {

// ---------------------------
// Helper functions
// ---------------------------

var g_lastPH = null;

function neutralRow()
{
   return [0.0, 0.5, 1.0, 0.0, 1.0];
}

function makeNeutralMatrix()
{
   return [
      neutralRow(), // R
      neutralRow(), // G
      neutralRow(), // B
      neutralRow(), // RGB/K
      neutralRow()  // Alpha
   ];
}

function cloneMatrix( M )
{
   var C = [];
   for ( var i = 0; i < M.length; ++i )
      C.push( [ M[i][0], M[i][1], M[i][2], M[i][3], M[i][4] ] );
   return C;
}

function quantize8( v )
{
   if ( v < 0 ) v = 0;
   else if ( v > 1 ) v = 1;

   var b = Math.round( v * 255 );
   if ( b < 0 ) b = 0;
   else if ( b > 255 ) b = 255;
   return b;
}

function computeC0( img, channel )
{
   var width  = img.width;
   var height = img.height;
   var nPixels = width * height;

   var bins = 256;
   var clipFraction = 0.01; // 1%
   var minCount = Math.max( 1, Math.floor( nPixels * clipFraction ) );

   var hist = new Array( bins );
   for ( var i = 0; i < bins; ++i )
      hist[i] = 0;

   for ( var y = 0; y < height; ++y )
      for ( var x = 0; x < width; ++x )
         ++hist[ quantize8( img.sample( x, y, channel ) ) ];

   var acc = 0;
   for ( var b = 0; b < bins; ++b )
   {
      acc += hist[b];
      if ( acc >= minCount )
         return b / 255.0;
   }

   return 0.0;
}

function getAutoClipMatrix( viewId )
{
   var w = ImageWindow.windowById( viewId );
   if ( w == null )
      throw new Error( "getAutoClipMatrix: view not found: " + viewId );

   var img = w.mainView.image;

   var P_H = ( g_lastPH != null ) ? cloneMatrix( g_lastPH )
                                  : makeNeutralMatrix();

   if ( img.numberOfChannels >= 3 )
   {
      // RGB image: update R, G, B rows only
      P_H[0][0] = computeC0( img, 0 );
      P_H[1][0] = computeC0( img, 1 );
      P_H[2][0] = computeC0( img, 2 );
      // Keep RGB/K + Alpha unchanged (HT-like)
   }
   else
   {
      // Grayscale: update RGB/K only
      P_H[3][0] = computeC0( img, 0 );
      // Keep R,G,B + Alpha unchanged (HT-like)
   }

   g_lastPH = cloneMatrix( P_H );
   return P_H;
}

function clipMask( imageId )
{
   var w = ImageWindow.windowById( imageId );
   if ( w == null )
      throw new Error( "clipMask: view not found: " + imageId );

   var H = getAutoClipMatrix( imageId );

   var P = new HistogramTransformation;
   P.H = H;

   if ( !P.executeOn( w.mainView ) )
      throw new Error( "clipMask: HistogramTransformation failed on " + imageId );
}

function applyMaskToWindow( targetId, maskId, invertMask )
{
   var tw = ImageWindow.windowById( targetId );
   if ( tw == null )
      throw new Error( "applyMask: target not found: " + targetId );

   var mw = ImageWindow.windowById( maskId );
   if ( mw == null )
      throw new Error( "applyMask: mask not found: " + maskId );

   tw.setMask( mw );
   tw.maskEnabled = true;
   tw.maskInverted = ( invertMask === true );
   tw.bringToFront();
   pumpEvents();
}

function applyUSM( imageId )
{
   var w = ImageWindow.windowById( imageId );
   if ( w == null )
      throw new Error( "applyUSM: view not found: " + imageId );

   var P = new UnsharpMask;
   P.sigma = 2.00;
   P.amount = 0.80;
   P.useLuminance = true;
   P.linear = false;
   P.deringing = false;
   P.deringingDark = 0.1000;
   P.deringingBright = 0.0000;
   P.outputDeringingMaps = false;
   P.rangeLow = 0.0000000;
   P.rangeHigh = 0.0000000;

   if ( !P.executeOn( w.mainView ) )
      throw new Error( "applyUSM: UnsharpMask failed on " + imageId );
}

function applyMLT( imageId )
{
   var w = ImageWindow.windowById( imageId );
   if ( w == null )
      throw new Error( "applyMLT: view not found: " + imageId );

   var P = new MultiscaleLinearTransform;
   P.layers = [ // enabled, biasEnabled, bias, noiseReductionEnabled, noiseReductionThreshold, noiseReductionAmount, noiseReductionIterations
      [true, true, 0.000, false, 3.000, 1.00, 1],
      [true, true, 0.300, false, 3.000, 1.00, 1],
      [true, true, 0.200, false, 3.000, 1.00, 1],
      [true, true, 0.000, false, 3.000, 1.00, 1],
      [true, true, 0.000, false, 3.000, 1.00, 1]
   ];
   P.transform = MultiscaleLinearTransform.prototype.StarletTransform;
   P.scaleDelta = 0;
   P.scalingFunctionData = [
      0.25,0.5,0.25,
      0.5,1,0.5,
      0.25,0.5,0.25
   ];
   P.scalingFunctionRowFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionColFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionNoiseSigma = [
      0.8003,0.2729,0.1198,
      0.0578,0.0287,0.0143,
      0.0072,0.0036,0.0019,
      0.001
   ];
   P.scalingFunctionName = "Linear Interpolation (3)";
   P.linearMask = false;
   P.linearMaskAmpFactor = 100;
   P.linearMaskSmoothness = 1.00;
   P.linearMaskInverted = true;
   P.linearMaskPreview = false;
   P.largeScaleFunction = MultiscaleLinearTransform.prototype.NoFunction;
   P.curveBreakPoint = 0.75;
   P.noiseThresholding = false;
   P.noiseThresholdingAmount = 1.00;
   P.noiseThreshold = 3.00;
   P.softThresholding = true;
   P.useMultiresolutionSupport = false;
   P.deringing = true;
   P.deringingDark = 0.0010;
   P.deringingBright = 0.0000;
   P.outputDeringingMaps = false;
   P.lowRange = 0.0000;
   P.highRange = 0.0000;
   P.previewMode = MultiscaleLinearTransform.prototype.Disabled;
   P.previewLayer = 0;
   P.toLuminance = true;
   P.toChrominance = true;
   P.linear = false;

   if ( !P.executeOn( w.mainView ) )
      throw new Error( "applyMLT: MultiscaleLinearTransform failed on " + imageId );
}

function createLumSharpener( L, LUSM, LMLT )
{
   if ( ImageWindow.windowById( L ) == null )
      throw new Error( "createLumSharpener: missing L: " + L );
   if ( ImageWindow.windowById( LUSM ) == null )
      throw new Error( "createLumSharpener: missing LUSM: " + LUSM );
   if ( ImageWindow.windowById( LMLT ) == null )
      throw new Error( "createLumSharpener: missing LMLT: " + LMLT );

   // Derive output id from the base luminance id.
   // Expected L = "<base>_Lum" -> outId = "<base>_Lum_Sharpener"
   var outId = L + "_Sharpener";

   // If an old output exists, close it to avoid PixelMath id collision.
   try
   {
      var wOld = ImageWindow.windowById( outId );
      if ( wOld != null && !wOld.isNull )
         wOld.forceClose();
   }
   catch ( __eOld ) {}

   var P = new PixelMath;
   P.expression = "0.35*" + L + " + 0.30*" + LUSM + " + 0.30*" + LMLT;
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = true;
   P.showNewImage = true;
   P.newImageId = outId;
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.prototype.Gray;
   P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

   // Execute on L by convention (expression references the other images by id).
   var w = ImageWindow.windowById( L );
   if ( w == null || w.isNull )
      throw new Error( "createLumSharpener: target window not found: " + L );

   if ( !P.executeOn( w.mainView ) )
      throw new Error( "createLumSharpener: PixelMath failed" );

   pumpEvents();
   return outId;
}













function applyLum( targetId, lumId )
{
   if ( !targetId || !lumId )
      throw new Error( "applyLum: targetId and lumId are required." );

   var tw = ImageWindow.windowById( targetId );
   if ( tw == null || tw.isNull )
      throw new Error( "applyLum: target not found: " + targetId );

   var lw = ImageWindow.windowById( lumId );
   if ( lw == null || lw.isNull )
      throw new Error( "applyLum: luminance image not found: " + lumId );

   var P = new LRGBCombination;
   P.channels = [ // enabled, id, k
      [false, "",    1.00000],
      [false, "",    1.00000],
      [false, "",    1.00000],
      [true,  lumId, 1.00000]
   ];
   P.mL = 0.500;
   P.mc = 0.500;
   P.clipHighlights = true;
   P.noiseReduction = false;
   P.layersRemoved = 4;
   P.layersProtected = 2;
   P.inheritAstrometricSolution = true;

   if ( !P.executeOn( tw.mainView ) )
      throw new Error( "applyLum: LRGBCombination failed on " + targetId );

   pumpEvents();
   return true;
}



function checkWCS( w )
{
   if ( w == null || w.isNull )
      return false;

   var v = null;
   try { v = w.mainView; } catch ( __eV ) { v = null; }
   if ( v == null )
      return false;

   // We consider a solution valid only if there is concrete WCS metadata
   // embedded in the image (XISF properties or FITS/WCS keywords).
   // Some PI builds expose "astrometricSolution" as a non-null object even
   // when there is no real solution; so we treat that as advisory only.

   function hasAstroProps()
   {
      var count = 0;

      var hasProp = function( id )
      {
         try { if ( typeof v.hasProperty === "function" ) return v.hasProperty( id ); } catch ( __eH ) {}
         try
         {
            if ( typeof v.propertyValue === "function" )
               return v.propertyValue( id ) !== undefined;
         }
         catch ( __ePV ) {}
         return false;
      };

      // Common PixInsight astrometric solution properties.
      if ( hasProp( "PCL:AstrometricSolution:ProjectionSystem" ) ) ++count;
      if ( hasProp( "PCL:AstrometricSolution:ReferenceCelestialCoordinates" ) ) ++count;
      if ( hasProp( "PCL:AstrometricSolution:ReferenceNativeCoordinates" ) ) ++count;
      if ( hasProp( "PCL:AstrometricSolution:LinearTransformation" ) ) ++count;
      if ( hasProp( "PCL:AstrometricSolution:DistortionModel" ) ) ++count;

      // Fallback scan (older PI builds expose a list)
      if ( count < 2 )
      {
         var props = null;
         try { props = ( typeof v.properties === "function" ) ? v.properties() : v.properties; } catch ( __eP0 ) { props = null; }

         if ( props && props.length > 0 )
         {
            for ( var i = 0; i < props.length; ++i )
            {
               var id = null;
               try { id = props[i].id ? props[i].id : props[i]; } catch ( __ePid ) { id = null; }
               if ( id && ( "" + id ).indexOf( "PCL:AstrometricSolution:" ) === 0 )
                  ++count;
               if ( count >= 2 )
                  break;
            }
         }
      }

      return count >= 2;
   }

   function hasWCSKeywords()
   {
      // Keywords are on the ImageWindow (w), not the View.
      try
      {
         var kw = null;
         try { kw = w.keywords; } catch ( __eK ) { kw = null; }
         if ( !kw || kw.length < 6 )
            return false;

         var need = { "CTYPE1":0, "CTYPE2":0, "CRVAL1":0, "CRVAL2":0, "CRPIX1":0, "CRPIX2":0 };
         for ( var i = 0; i < kw.length; ++i )
         {
            var n = null;
            try { n = kw[i].name ? kw[i].name : kw[i].keyword; } catch ( __eN ) { n = null; }
            if ( n && need.hasOwnProperty( n ) )
               need[n] = 1;
         }

         // Require a minimal WCS keyword set.
         return (need.CTYPE1 && need.CTYPE2 && need.CRVAL1 && need.CRVAL2 && need.CRPIX1 && need.CRPIX2);
      }
      catch ( __eKW )
      {
         return false;
      }
   }

   var propsOK = false;
   var kwOK    = false;

   try { propsOK = hasAstroProps(); } catch ( __e1 ) { propsOK = false; }
   if ( propsOK )
      return true;

   try { kwOK = hasWCSKeywords(); } catch ( __e2 ) { kwOK = false; }
   if ( kwOK )
      return true;

   return false;
}


function extractLum( viewId )
{
   var w = ImageWindow.windowById( viewId );
   if ( w == null )
      throw new Error( "extractLum: view not found: " + viewId );

   var v = w.mainView;

   // If the source is monochrome, "luminance" is the image itself.
   if ( v.image.numberOfChannels == 1 )
   {
      var w2 = new ImageWindow(
         v.image.width,
         v.image.height,
         1,
         w.bitsPerSample,
         w.isFloatSample,
         false,
         viewId + "_Lum"
      );
      w2.mainView.beginProcess();
      w2.mainView.image.assign( v.image );
      w2.mainView.endProcess();
      w2.show();
      pumpEvents();
      w2.bringToFront();
      return w2;
   }

   if ( v.image.numberOfChannels < 3 )
      throw new Error( "extractLum: image is not RGB" );

   var P = new ChannelExtraction;
   P.colorSpace = ChannelExtraction.prototype.CIELab;
   P.channels = [
      [ true,  "" ], // L*
      [ false, "" ], // a*
      [ false, "" ]  // b*
   ];
   P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
   P.inheritAstrometricSolution = true;

   if ( !P.executeOn( v ) )
      throw new Error( "extractLum: ChannelExtraction failed" );

   var lw = ImageWindow.activeWindow;
   if ( lw != null )
   {
      lw.mainView.id = viewId + "_Lum";
      lw.bringToFront();
      return lw;
   }
   return null;
}



function pad2( x ) { return ( x < 10 ? "0" : "" ) + x; }
function nowStamp()
{
   let d = new Date();
   return pad2( d.getHours() ) + ":" + pad2( d.getMinutes() ) + ":" + pad2( d.getSeconds() );
}

// ---------------------------
// Persistence (Step 2..N only, exclude Step 1 Masters tab)
// ---------------------------
var SBPP_SETTINGS_KEY = "/SkynetObservatory/SBPP/lastConfig";

function sbppUiLog( dlg, s )
{
   try
   {
      if ( dlg && typeof dlg.appendLog === "function" )
         dlg.appendLog( s );
      else
         Console.writeln( "[SBPP] " + s );
   }
   catch ( __e ) {}
}

function sbppCollectConfig( dlg )
{
   // Collect all configuration values EXCEPT Step 1 (Masters/files selection).
   // Best-effort: if a control does not exist in a given PI version, skip it.

   var cfg = {};

   // Mode, palette, output id
   try { cfg.mode = ( dlg && dlg.state ) ? dlg.state.mode : "Narrowband"; } catch ( __e0 ) {}
   try { cfg.palette = ( dlg && dlg.state ) ? dlg.state.palette : "SHO"; } catch ( __e2 ) {}
   try { cfg.useChannelCombination = ( dlg && dlg.state ) ? !!dlg.state.useChannelCombination : true; } catch ( __e3 ) {}

   // Step 2: GraXpert
   try { cfg.gxSmoothing = dlg.gxSmoothing ? dlg.gxSmoothing.value : 0.50; } catch ( __e4 ) {}

   // Step 3: LinearFit
   try { cfg.referenceChannel = ( dlg && dlg.state ) ? ( dlg.state.referenceChannel || "" ) : ""; } catch ( __e5 ) {}
   try { cfg.rejectLow  = dlg.rejectLow  ? dlg.rejectLow.value  : 0.00; } catch ( __e6 ) {}
   try { cfg.rejectHigh = dlg.rejectHigh ? dlg.rejectHigh.value : 0.92; } catch ( __e7 ) {}

   // Step 5: Combination UI
   try { cfg.paletteIndex = dlg.paletteCombo ? dlg.paletteCombo.currentItem : 0; } catch ( __e8 ) {}
   try { cfg.exprR = dlg.exprREdit ? dlg.exprREdit.text : ""; } catch ( __e9 ) {}
   try { cfg.exprG = dlg.exprGEdit ? dlg.exprGEdit.text : ""; } catch ( __e10 ) {}
   try { cfg.exprB = dlg.exprBEdit ? dlg.exprBEdit.text : ""; } catch ( __e11 ) {}

   // Linear tuning (Step 6..9 items exposed as "lt*")
   try { cfg.ltDenoise = dlg.ltDenoise ? dlg.ltDenoise.value : 0.50; } catch ( __e12 ) {}
   try { cfg.ltIterations = dlg.ltIterations ? dlg.ltIterations.value : 1; } catch ( __e13 ) {}
   try { cfg.ltSharpenStars = dlg.ltSharpenStars ? dlg.ltSharpenStars.text : "0.50"; } catch ( __e14 ) {}
   try { cfg.ltSharpenNonstellar = dlg.ltSharpenNonstellar ? dlg.ltSharpenNonstellar.text : "0.50"; } catch ( __e15 ) {}
   try { cfg.ltAdjustStarHalos = dlg.ltAdjustStarHalos ? dlg.ltAdjustStarHalos.text : "-0.10"; } catch ( __e16 ) {}
   try { cfg.ltGenStarImage = dlg.ltGenStarImage ? !!dlg.ltGenStarImage.checked : true; } catch ( __e17 ) {}
   try { cfg.ltUnscreenStars = dlg.ltUnscreenStars ? !!dlg.ltUnscreenStars.checked : true; } catch ( __e18 ) {}
   try { cfg.ltLargeOverlap = dlg.ltLargeOverlap ? !!dlg.ltLargeOverlap.checked : true; } catch ( __e19 ) {}

   // Step 10: Stretching (HT + MAS)
   try { cfg.htEnable = dlg.htEnable ? !!dlg.htEnable.checked : true; } catch ( __e20 ) {}
   try { cfg.htTbgnd  = dlg.htTbgnd  ? dlg.htTbgnd.text : "0.20"; } catch ( __e21 ) {}

   try { cfg.masEnable = dlg.masEnable ? !!dlg.masEnable.checked : true; } catch ( __e22 ) {}
   try { cfg.masAggressiveness = dlg.masAggressiveness ? dlg.masAggressiveness.value : 0.70; } catch ( __e23 ) {}
   try { cfg.masTargetBg = dlg.masTargetBg ? dlg.masTargetBg.value : 0.20; } catch ( __e24 ) {}
   try { cfg.masDRC = dlg.masDRC ? dlg.masDRC.value : 0.40; } catch ( __e25 ) {}
   try { cfg.masContrast = dlg.masContrast ? !!dlg.masContrast.checked : true; } catch ( __e26 ) {}
   try { cfg.masScaleSepIndex = dlg.masScaleSep ? dlg.masScaleSep.currentItem : 3; } catch ( __e27 ) {}
   try { cfg.masIntensity = dlg.masIntensity ? dlg.masIntensity.value : 1.00; } catch ( __e28 ) {}

   // MAS saturation helpers (if present)
   // NOTE: Controls may be NumericControl or Edit depending on UI revisions -> read defensively.
   try { cfg.masSaturationEnable = dlg.masSaturationEnable ? !!dlg.masSaturationEnable.checked : true; } catch ( __e29 ) {}

   try
   {
      if ( dlg.masSatBoost )
         cfg.masSatBoost = ( "value" in dlg.masSatBoost ) ? dlg.masSatBoost.value :
                           ( "text" in dlg.masSatBoost ) ? parseFloat( dlg.masSatBoost.text ) : 0.00;
      else
         cfg.masSatBoost = 0.00;
   }
   catch ( __e30 ) {}

   try
   {
      if ( dlg.masSatAmount )
         cfg.masSatAmount = ( "value" in dlg.masSatAmount ) ? dlg.masSatAmount.value :
                            ( "text" in dlg.masSatAmount ) ? parseFloat( dlg.masSatAmount.text ) : 0.75;
      else
         cfg.masSatAmount = 0.75;
   }
   catch ( __e31 ) {}

   try
   {
      // masSatMask is a checkbox (Lightness Mask) -> persist boolean only
      if ( dlg.masSatMask )
         cfg.masSatMask = !!dlg.masSatMask.checked;
      else
         cfg.masSatMask = true;
   }
   catch ( __e32 ) {}

   try { cfg.masPreviewLarge = dlg.masPreviewLarge ? !!dlg.masPreviewLarge.checked : false; } catch ( __e33 ) {}

   // Step 11: Nonlinear NXT
   try { cfg.nlNrEnable = dlg.nlNrEnable ? !!dlg.nlNrEnable.checked : true; } catch ( __e34 ) {}
   try { cfg.nlNrDenoise = dlg.nlNrDenoise ? dlg.nlNrDenoise.value : 0.30; } catch ( __e35 ) {}
   try { cfg.nlNrIterations = dlg.nlNrIterations ? dlg.nlNrIterations.value : 1; } catch ( __e36 ) {}

   // Step 12: Nonlinear BXT
   try { cfg.nlSharpEnable = dlg.nlSharpEnable ? !!dlg.nlSharpEnable.checked : true; } catch ( __e37 ) {}
   try { cfg.nlSharpenStars = dlg.nlSharpenStars ? dlg.nlSharpenStars.text : "0.00"; } catch ( __e38 ) {}
   try { cfg.nlAdjustStarHalos = dlg.nlAdjustStarHalos ? dlg.nlAdjustStarHalos.text : "0.00"; } catch ( __e39 ) {}
   try { cfg.nlSharpenNonstellar = dlg.nlSharpenNonstellar ? dlg.nlSharpenNonstellar.text : "0.25"; } catch ( __e40 ) {}
   // Step 13: Lum Sharpening
   try { cfg.lumSharpEnable = dlg.lumSharpEnable ? !!dlg.lumSharpEnable.checked : false; } catch ( __e41 ) {}


   return cfg;
}

function sbppApplyConfig( dlg, cfg )
{
   if ( !dlg || !cfg )
      return false;

   // Do not touch Step 1 (masters selection). Only apply config controls for Step 2..N.
   try
   {
      // Mode
      if ( cfg.mode )
      {
         try { dlg.state.mode = cfg.mode; } catch ( __e0 ) {}

         try { if ( dlg.modeNarrowband ) dlg.modeNarrowband.checked = ( cfg.mode === "Narrowband" ); } catch ( __e1 ) {}
         try { if ( dlg.modeBroadband )  dlg.modeBroadband.checked  = ( cfg.mode === "Broadband"  ); } catch ( __e2 ) {}
      }

      // Output id, palette, combination mode
      if ( cfg.palette )  { try { dlg.state.palette  = cfg.palette;  } catch ( __e4 ) {} }

      if ( typeof cfg.useChannelCombination === "boolean" )
      {
         try { dlg.state.useChannelCombination = cfg.useChannelCombination; } catch ( __e5 ) {}
         try { if ( dlg.ccModeRadio ) dlg.ccModeRadio.checked = !!cfg.useChannelCombination; } catch ( __e6 ) {}
         try { if ( dlg.pmModeRadio ) dlg.pmModeRadio.checked = !cfg.useChannelCombination; } catch ( __e7 ) {}
      }

      // Step 2
      if ( dlg.gxSmoothing && isFinite( cfg.gxSmoothing ) ) dlg.gxSmoothing.setValue( cfg.gxSmoothing );

      // Step 3
      if ( cfg.referenceChannel !== undefined ) { try { dlg.state.referenceChannel = "" + cfg.referenceChannel; } catch ( __e8 ) {} }
      if ( dlg.rejectLow && isFinite( cfg.rejectLow ) )   dlg.rejectLow.setValue( cfg.rejectLow );
      if ( dlg.rejectHigh && isFinite( cfg.rejectHigh ) ) dlg.rejectHigh.setValue( cfg.rejectHigh );

      // Step 5
      if ( dlg.paletteCombo && isFinite( cfg.paletteIndex ) ) dlg.paletteCombo.currentItem = cfg.paletteIndex;
      if ( dlg.exprREdit && typeof cfg.exprR === "string" ) dlg.exprREdit.text = cfg.exprR;
      if ( dlg.exprGEdit && typeof cfg.exprG === "string" ) dlg.exprGEdit.text = cfg.exprG;
      if ( dlg.exprBEdit && typeof cfg.exprB === "string" ) dlg.exprBEdit.text = cfg.exprB;

      // Linear tuning
      if ( dlg.ltDenoise && isFinite( cfg.ltDenoise ) ) dlg.ltDenoise.setValue( cfg.ltDenoise );
      if ( dlg.ltIterations && isFinite( cfg.ltIterations ) ) dlg.ltIterations.value = cfg.ltIterations;
      if ( dlg.ltSharpenStars && typeof cfg.ltSharpenStars === "string" ) dlg.ltSharpenStars.text = cfg.ltSharpenStars;
      if ( dlg.ltSharpenNonstellar && typeof cfg.ltSharpenNonstellar === "string" ) dlg.ltSharpenNonstellar.text = cfg.ltSharpenNonstellar;
      if ( dlg.ltAdjustStarHalos && typeof cfg.ltAdjustStarHalos === "string" ) dlg.ltAdjustStarHalos.text = cfg.ltAdjustStarHalos;
      if ( dlg.ltGenStarImage && typeof cfg.ltGenStarImage === "boolean" ) dlg.ltGenStarImage.checked = cfg.ltGenStarImage;
      if ( dlg.ltUnscreenStars && typeof cfg.ltUnscreenStars === "boolean" ) dlg.ltUnscreenStars.checked = cfg.ltUnscreenStars;
      if ( dlg.ltLargeOverlap && typeof cfg.ltLargeOverlap === "boolean" ) dlg.ltLargeOverlap.checked = cfg.ltLargeOverlap;

      // Stretching
      if ( dlg.htEnable && typeof cfg.htEnable === "boolean" ) dlg.htEnable.checked = cfg.htEnable;
      if ( dlg.htTbgnd && typeof cfg.htTbgnd === "string" ) dlg.htTbgnd.text = cfg.htTbgnd;

      if ( dlg.masEnable && typeof cfg.masEnable === "boolean" ) dlg.masEnable.checked = cfg.masEnable;
      if ( dlg.masAggressiveness && isFinite( cfg.masAggressiveness ) ) dlg.masAggressiveness.setValue( cfg.masAggressiveness );
      if ( dlg.masTargetBg && isFinite( cfg.masTargetBg ) ) dlg.masTargetBg.setValue( cfg.masTargetBg );
      if ( dlg.masDRC && isFinite( cfg.masDRC ) ) dlg.masDRC.setValue( cfg.masDRC );
      if ( dlg.masContrast && typeof cfg.masContrast === "boolean" ) dlg.masContrast.checked = cfg.masContrast;
      if ( dlg.masScaleSep && isFinite( cfg.masScaleSepIndex ) ) dlg.masScaleSep.currentItem = cfg.masScaleSepIndex;
      if ( dlg.masIntensity && isFinite( cfg.masIntensity ) ) dlg.masIntensity.setValue( cfg.masIntensity );

      if ( dlg.masSaturationEnable && typeof cfg.masSaturationEnable === "boolean" ) dlg.masSaturationEnable.checked = cfg.masSaturationEnable;
      if ( dlg.masSatBoost && ( "masSatBoost" in cfg ) && ( "masSatBoost" in cfg ) && isFinite( cfg.masSatBoost ) )
      {
         try { if ( typeof dlg.masSatBoost.setValue === "function" ) dlg.masSatBoost.setValue( cfg.masSatBoost );
               else if ( "value" in dlg.masSatBoost ) dlg.masSatBoost.value = cfg.masSatBoost;
               else if ( "text" in dlg.masSatBoost ) dlg.masSatBoost.text = "" + cfg.masSatBoost; } catch ( __eSB ) {}
      }
      if ( dlg.masSatAmount && ( "masSatAmount" in cfg ) && ( "masSatAmount" in cfg ) && isFinite( cfg.masSatAmount ) )
      {
         try { if ( typeof dlg.masSatAmount.setValue === "function" ) dlg.masSatAmount.setValue( cfg.masSatAmount );
               else if ( "value" in dlg.masSatAmount ) dlg.masSatAmount.value = cfg.masSatAmount;
               else if ( "text" in dlg.masSatAmount ) dlg.masSatAmount.text = "" + cfg.masSatAmount; } catch ( __eSA ) {}
      }
      if ( dlg.masSatMask && ( "masSatMask" in cfg ) && typeof cfg.masSatMask === "boolean" )
      {
         try { dlg.masSatMask.checked = !!cfg.masSatMask; } catch ( __eSM ) {}
      }
      if ( dlg.masPreviewLarge && typeof cfg.masPreviewLarge === "boolean" ) dlg.masPreviewLarge.checked = cfg.masPreviewLarge;

      // Nonlinear
      if ( dlg.nlNrEnable && typeof cfg.nlNrEnable === "boolean" ) dlg.nlNrEnable.checked = cfg.nlNrEnable;
      if ( dlg.nlNrDenoise && isFinite( cfg.nlNrDenoise ) ) dlg.nlNrDenoise.setValue( cfg.nlNrDenoise );
      if ( dlg.nlNrIterations && isFinite( cfg.nlNrIterations ) ) dlg.nlNrIterations.value = cfg.nlNrIterations;

      if ( dlg.nlSharpEnable && typeof cfg.nlSharpEnable === "boolean" ) dlg.nlSharpEnable.checked = cfg.nlSharpEnable;
      if ( dlg.nlSharpenStars && typeof cfg.nlSharpenStars === "string" ) dlg.nlSharpenStars.text = cfg.nlSharpenStars;
      if ( dlg.nlAdjustStarHalos && typeof cfg.nlAdjustStarHalos === "string" ) dlg.nlAdjustStarHalos.text = cfg.nlAdjustStarHalos;
      if ( dlg.nlSharpenNonstellar && typeof cfg.nlSharpenNonstellar === "string" ) dlg.nlSharpenNonstellar.text = cfg.nlSharpenNonstellar;
      if ( dlg.lumSharpEnable && ( "lumSharpEnable" in cfg ) && typeof cfg.lumSharpEnable === "boolean" ) dlg.lumSharpEnable.checked = !!cfg.lumSharpEnable;

      // Let existing UI helpers reconcile state (palette defaults, enablement guards, etc.)
      try { if ( dlg.applyPaletteDefaults ) dlg.applyPaletteDefaults(); } catch ( __eA ) {}
      try { if ( dlg.updateCombinationEnablement ) dlg.updateCombinationEnablement(); } catch ( __eB ) {}
      try { if ( dlg.__enforceStretchSelection ) dlg.__enforceStretchSelection(); } catch ( __eC ) {}
      try { if ( dlg.updateRunEnabled ) dlg.updateRunEnabled(); } catch ( __eD ) {}
      try { if ( dlg.updateHeader ) dlg.updateHeader(); } catch ( __eE ) {}
   

      return true;
}
   catch ( __eF )
   {
      return false;
   }

   try { if ( dlg && dlg.updateMASControlsEnablement ) dlg.updateMASControlsEnablement(); } catch ( __eMAS1 ) {}
   return true;
}

function sbppTrySaveCurrentConfiguration( dlg, logFn )
{
   var log = ( typeof logFn === "function" ) ? logFn : function( s ){ sbppUiLog( dlg, s ); };

   log( "Attempting to save current configuration" );

   try
   {
      if ( typeof Settings === "undefined" )
      {
         log( "Warning: Couldn't save current configuration" );
         return false;
      }

      var cfg = sbppCollectConfig( dlg );
      var json = JSON.stringify( cfg );
      Settings.write( SBPP_SETTINGS_KEY, DataType_String, json );

      log( "Current configuration successfully saved" );
      return true;
   }
   catch ( __e )
   {
      try { Console.writeln( "[SBPP] Save exception: " + __e ); } catch ( __e2 ) {}
      log( "Warning: Couldn't save current configuration" );
      return false;
   }
}

function sbppTryLoadLastConfiguration( dlg )
{
   sbppUiLog( dlg, "Attempting to retrieve last configuration" );

   try
   {
      if ( typeof Settings === "undefined" )
      {
         sbppUiLog( dlg, "Warning: Last configuration not found" );
         return false;
      }

      var json = Settings.read( SBPP_SETTINGS_KEY, DataType_String );
      if ( json === null || json === undefined || ("" + json).length === 0 )
      {
         sbppUiLog( dlg, "Warning: Last configuration not found" );
         return false;
      }

      sbppUiLog( dlg, "Last configuration found" );

      var cfg = JSON.parse( json );

      if ( !sbppApplyConfig( dlg, cfg ) )
      {
         sbppUiLog( dlg, "Warning: Last configuration couldn't be loaded" );
         return false;
      }

      // Output ID is runtime state. Always start from "RGB" to avoid runaway suffixes.
      try { if ( dlg && dlg.state ) dlg.state.outputId = "RGB"; } catch ( __eOID0 ) {}
      try { if ( dlg && dlg.updateHeader ) dlg.updateHeader(); } catch ( __eOID1 ) {}

      try { if ( dlg && dlg.updateMASControlsEnablement ) dlg.updateMASControlsEnablement(); } catch ( __eM0 ) {}
      sbppUiLog( dlg, "Last configuration loaded successfully" );
      return true;
   }
   catch ( __e )
   {
      try { Console.writeln( "[SBPP] Load exception: " + __e ); } catch ( __e2 ) {}
      sbppUiLog( dlg, "Warning: Last configuration couldn't be loaded" );
      return false;
   }
}




function copyAstrometricMetadata( srcWin, dstWin )
{
   if ( srcWin == null || srcWin.isNull || dstWin == null || dstWin.isNull )
      return false;

   if ( !srcWin.hasAstrometricSolution )
      return false;

   dstWin.copyAstrometricSolution( srcWin );
   return true;
}


function fmtHMS( ms )
{
   ms = Math.max( 0, Math.round( ms ) );
   let s = Math.floor( ms / 1000 );
   let h = Math.floor( s / 3600 ); s -= h * 3600;
   let m = Math.floor( s / 60 );   s -= m * 60;
   return pad2( h ) + ":" + pad2( m ) + ":" + pad2( s );
}


function fmtMSS( ms )
{
   ms = Math.max( 0, Math.round( ms ) );
   let s = Math.floor( ms / 1000 );
   let m = Math.floor( s / 60 ); s -= m * 60;
   return pad2( m ) + ":" + pad2( s );
}


function makeLabel( parent, text, minW )
{
   let L = new Label( parent );
   L.text = text;
   L.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   if ( minW ) L.minWidth = Math.max( 45, Math.round( minW * 0.8 ) );
   return L;
}

function makeLeftLabel( parent, text )
{
   let L = new Label( parent );
   L.text = text;
   L.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   return L;
}

function row2( leftCtrl, rightCtrl, spacing )
{
   let s = new HorizontalSizer;
   s.spacing = spacing ? spacing : 8;
   s.add( leftCtrl );
   s.add( rightCtrl, 100 );
   return s;
}

function slider01( parent, def, prec )
{
   let nc = new NumericControl( parent );
   nc.label.text = "";
   nc.setRange( 0.0, 1.0 );
   nc.slider.setRange( 0, 100 );
   nc.setPrecision( prec ? prec : 2 );
   nc.setValue( def );
   return nc;
}

function fmt6( x ) { return x.toFixed( 6 ); }

function sbppFindWindowByBaseId( baseId )
{
   // 1) Exact match
   var w = ImageWindow.windowById( baseId );
   if ( w != null && !w.isNull )
      return w;

   // 2) Scan for baseId_*, baseId_*_*, etc.
   var wins = ImageWindow.windows;
   var best = null;
   var bestScore = -1;

   function scoreId( id )
   {
      if ( id === baseId )
         return 1000000;

      if ( id.indexOf( baseId + "_" ) !== 0 )
         return -1;

      var tail = id.substring( baseId.length + 1 );
      var parts = tail.split( "_" );
      var s = 0;

      for ( var i = 0; i < parts.length; i++ )
      {
         var n = parseInt( parts[i], 10 );
         if ( isFinite( n ) )
            s = s * 1000 + n;
         else
            return -1;
      }

      return s;
   }

   for ( var i = 0; i < wins.length; i++ )
   {
      var ww = wins[i];
      if ( ww == null || ww.isNull )
         continue;

      var id = "";
      try { id = ww.mainView.id; } catch ( __e ) { id = ""; }
      if ( !id )
         continue;

      var sc = scoreId( id );
      if ( sc > bestScore )
      {
         bestScore = sc;
         best = ww;
      }
   }

   return best;
}


function __clamp( x, lo, hi )
{
   if ( x < lo ) return lo;
   if ( x > hi ) return hi;
   return x;
}

// Formatting for PixelMath coefficients (keep it readable).
function __fmt( x )
{
   // 3 decimals is usually plenty for blend factors like 0.123
   return x.toFixed( 3 );
}

function sbppPickAIFile( aiFile )
{
   // PixInsight uses different model file extensions depending on platform/build.
   // Windows/Linux often use .pb, macOS commonly uses .mlmodel.
   try
   {
      if ( typeof aiFile !== "string" || !aiFile.length )
         return aiFile;

      // If the given aiFile exists as-is, keep it.
      if ( File.exists( aiFile ) )
         return aiFile;

      // Try swapping extensions.
      if ( aiFile.endsWith( ".pb" ) )
      {
         let alt = aiFile.substring( 0, aiFile.length - 3 ) + ".mlmodel";
         if ( File.exists( alt ) )
            return alt;
      }
      else if ( aiFile.endsWith( ".mlmodel" ) )
      {
         let alt = aiFile.substring( 0, aiFile.length - 8 ) + ".pb";
         if ( File.exists( alt ) )
            return alt;
      }
   }
   catch ( __e ) {}

   return aiFile;
}



function detectChannelsFromFiles( fileNames )
{
   // Detect available channels based on filename tokens.
   // Supports both short and long identifiers:
   //   Broadband: R/Red, G/Green, B/Blue, L/Lum/Luminance
   //   Narrowband: Ha, Sii (S2), Oiii (O3)
   let d = { Ha:false, Sii:false, Oiii:false, R:false, G:false, B:false, L:false };

   function hasToken( s, re ) { return re.test( s ); }

   for ( let i = 0; i < fileNames.length; i++ )
   {
      let s = String( fileNames[i] ).toLowerCase();

      // Narrowband tokens
      if ( hasToken( s, /(^|[^a-z0-9])(ha|h[-_ ]?a)([^a-z0-9]|$)/ ) ) d.Ha = true;
      if ( hasToken( s, /(^|[^a-z0-9])(sii|s2|s[-_ ]?ii)([^a-z0-9]|$)/ ) ) d.Sii = true;
      if ( hasToken( s, /(^|[^a-z0-9])(oiii|o3|o[-_ ]?iii)([^a-z0-9]|$)/ ) ) d.Oiii = true;

      // Broadband tokens (token-based to reduce false positives)
      if ( hasToken( s, /(^|[^a-z0-9])(r|red)([^a-z0-9]|$)/ ) ) d.R = true;
      if ( hasToken( s, /(^|[^a-z0-9])(g|green)([^a-z0-9]|$)/ ) ) d.G = true;
      if ( hasToken( s, /(^|[^a-z0-9])(b|blue)([^a-z0-9]|$)/ ) ) d.B = true;

      // Optional luminance
      if ( hasToken( s, /(^|[^a-z0-9])(l|lum|luminance)([^a-z0-9]|$)/ ) ) d.L = true;
   }

   return d;
}

// ---- Workflow helpers (ported from Baseline UI.js) ----
function pumpEvents()
{
   for ( var i = 0; i < 5; ++i )
   {
      try { if ( typeof processEvents === "function" ) processEvents(); } catch ( __e ) {}
   }
}

function guessKeyFromFilename( path )
{
   var s = path.toLowerCase();
   function hasToken( re ) { return re.test( s ); }

   if ( hasToken( /(^|[^a-z0-9])(ha|h[-_ ]?a)([^a-z0-9]|$)/ ) ) return "Ha";
   if ( hasToken( /(^|[^a-z0-9])(sii|s2|s[-_ ]?ii)([^a-z0-9]|$)/ ) ) return "Sii";
   if ( hasToken( /(^|[^a-z0-9])(oiii|o3|o[-_ ]?iii)([^a-z0-9]|$)/ ) ) return "Oiii";

   if ( hasToken( /(^|[^a-z0-9])(r|red)([^a-z0-9]|$)/ ) ) return "R";
   if ( hasToken( /(^|[^a-z0-9])(g|green)([^a-z0-9]|$)/ ) ) return "G";
   if ( hasToken( /(^|[^a-z0-9])(b|blue)([^a-z0-9]|$)/ ) ) return "B";

   return "";
}

function openImage( filePath )
{
   var wins = ImageWindow.open( filePath );
   if ( !wins || wins.length < 1 )
      throw new Error( "Unable to open: " + filePath );

   var w = wins[0];

   // --- WCS Validation (SPCC prerequisite) ---
   if ( !checkWCS( w ) )
   {
      try { w.forceClose(); } catch ( __eFC ) { try { w.close(); } catch ( __eC ) {} }
      throw new Error( "Master file '" + filePath + "' has no valid astrometric solution usable by SPCC." );
   }

   pumpEvents();
   return w;
}

function renameMainViewTo( view, desiredId )
{
   if ( view == null || desiredId == null || !desiredId.length )
      return;


   // If already canonical, do nothing (avoids forced suffixing when PI returns different wrapper objects).
   try { if ( view.id === desiredId ) return; } catch ( __eRID ) {}
   var id = desiredId;
   var n = 1;

   for ( ;; )
   {
      var existing = ImageWindow.windowById( id );
      if ( existing == null || existing.isNull || existing === view.window )
         break;

      id = desiredId + "_" + n;
      ++n;
   }

   try
   {
      view.id = id;
      pumpEvents();
   }
   catch ( e )
   {
   }
}

function applyVisualSTF( view, shadowsClipping, targetBackground, rgbLinked )
{
   if ( view == null || view.isNull )
      return;

   if ( shadowsClipping == undefined ) shadowsClipping = DEFAULT_AUTOSTRETCH_SCLIP;
   if ( targetBackground == undefined ) targetBackground = DEFAULT_AUTOSTRETCH_TBGND;
   if ( rgbLinked == undefined ) rgbLinked = DEFAULT_AUTOSTRETCH_CLINK;

   var stf = new ScreenTransferFunction;
   var n = view.image.isColor ? 3 : 1;

   var median = view.computeOrFetchProperty( "Median" );
   var mad = view.computeOrFetchProperty( "MAD" );
   mad.mul( 1.4826 );

   if ( rgbLinked )
   {
      var invertedChannels = 0;
      for ( var c = 0; c < n; ++c )
         if ( median.at( c ) > 0.5 ) ++invertedChannels;

      if ( invertedChannels < n )
      {
         var c0 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            if ( 1 + mad.at( c ) != 1 )
               c0 += median.at( c ) + shadowsClipping * mad.at( c );
            m += median.at( c );
         }

         c0 = Math.range( c0/n, 0.0, 1.0 );
         m  = Math.mtf( targetBackground, m/n - c0 );

         stf.STF = [
            [c0, 1, m, 0, 1],
            [c0, 1, m, 0, 1],
            [c0, 1, m, 0, 1],
            [0, 1, 0.5, 0, 1]
         ];
      }
      else
      {
         var c1 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            m += median.at( c );
            if ( 1 + mad.at( c ) != 1 )
               c1 += median.at( c ) - shadowsClipping * mad.at( c );
            else
               c1 += 1;
         }

         c1 = Math.range( c1/n, 0.0, 1.0 );
         m  = Math.mtf( c1 - m/n, targetBackground );

         stf.STF = [
            [0, c1, m, 0, 1],
            [0, c1, m, 0, 1],
            [0, c1, m, 0, 1],
            [0, 1, 0.5, 0, 1]
         ];
      }
   }
   else
   {
      var A = [
         [0, 1, 0.5, 0, 1],
         [0, 1, 0.5, 0, 1],
         [0, 1, 0.5, 0, 1],
         [0, 1, 0.5, 0, 1]
      ];

      for ( var c = 0; c < n; ++c )
      {
         if ( median.at( c ) < 0.5 )
         {
            var c0 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) + shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 0.0;
            var m  = Math.mtf( targetBackground, median.at( c ) - c0 );
            A[c] = [c0, 1, m, 0, 1];
         }
         else
         {
            var c1 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) - shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 1.0;
            var m  = Math.mtf( c1 - median.at( c ), targetBackground );
            A[c] = [0, c1, m, 0, 1];
         }
      }

      stf.STF = A;
   }

   stf.executeOn( view, false );
   pumpEvents();
}


function findBackground( imageIdentifier, regionWidth, regionHeight )
{
   var view = View.viewById( imageIdentifier );
   if ( view === null )
      throw new Error( "findBackground: view not found: " + imageIdentifier );

   var img = view.image;
   var W = img.width;
   var H = img.height;

   if ( W < regionWidth || H < regionHeight )
      throw new Error( "findBackground: region larger than image." );

   // Tunables (internal)
   var marginFrac = 0.08; // ignore borders
   var step = Math.max( 25, Math.round( Math.min( regionWidth, regionHeight ) ) ); // coarse grid
   var stride = 2; // subsample inside ROI for speed (2 => 25x25 samples in a 50x50 ROI)

   var mx = Math.round( W * marginFrac );
   var my = Math.round( H * marginFrac );

   var x0 = mx;
   var y0 = my;
   var x1 = W - mx - regionWidth;
   var y1 = H - my - regionHeight;

   if ( x1 <= x0 || y1 <= y0 )
   {
      x0 = 0;
      y0 = 0;
      x1 = W - regionWidth;
      y1 = H - regionHeight;
   }

   function medianOfArray( a )
   {
      var b = a.slice( 0 );
      b.sort( function( p, q ) { return p - q; } );
      var n = b.length;
      if ( n < 1 ) return 0;
      var mid = Math.floor( n / 2 );
      return ( n & 1 ) ? b[mid] : 0.5*( b[mid-1] + b[mid] );
   }

   function madOfArray( a, med )
   {
      var d = new Array( a.length );
      for ( var i = 0; i < a.length; ++i )
         d[i] = Math.abs( a[i] - med );
      return medianOfArray( d );
   }

   function roiSamples( x, y, ww, hh )
   {
      var r = new Rect( x, y, x + ww, y + hh );

      // Pull channel 0 samples (starless + clean => good enough; fast).
      // getSamples fills the array with ww*hh values in row-major order.
      var raw = new Array( ww*hh );
      img.getSamples( raw, r, 0 );

      if ( stride <= 1 ) return raw;

      // Subsample to reduce work (every stride pixels in x and y)
      var out = [];
      for ( var yy = 0; yy < hh; yy += stride )
      {
         var rowBase = yy * ww;
         for ( var xx = 0; xx < ww; xx += stride )
            out.push( raw[rowBase + xx] );
      }
      return out;
   }

   var bestScore = 1e30;
   var bestX = x0;
   var bestY = y0;

   var k = 1.5; // structure penalty weight

   for ( var y = y0; y <= y1; y += step )
      for ( var x = x0; x <= x1; x += step )
      {
         var s = roiSamples( x, y, regionWidth, regionHeight );
         var med = medianOfArray( s );
         var mad = madOfArray( s, med );

         var score = med + k * mad;

         if ( score < bestScore )
         {
            bestScore = score;
            bestX = x;
            bestY = y;
         }
      }

   return { left: bestX, top: bestY };
}

function findBackgroundROI50( imageIdentifier )
{
   var p = findBackground( imageIdentifier, 50, 50 );
   return { left: p.left, top: p.top, width: 50, height: 50 };
}




function __safeStat( s, propNames, fallback )
{
   for ( var i = 0; i < propNames.length; ++i )
   {
      var p = propNames[i];
      try
      {
         var v = s[p];
         if ( v !== undefined && v !== null && isFinite( v ) )
            return v;
      }
      catch ( __e ) {}
   }
   return fallback;
}

function getRobustViewStats( view )
{
   var st = {};
   if ( view == null || view.isNull )
      return st;

   var S = new ImageStatistics( view.image );

   st.mean   = __safeStat( S, [ "mean" ], 0 );
   st.median = __safeStat( S, [ "median" ], 0 );

   st.stdDev = __safeStat( S, [ "standardDeviation", "stdDev", "sigma" ], 0 );

   var mad = __safeStat( S, [ "MAD", "mad" ], NaN );
   st.mad = isFinite( mad ) ? mad : NaN;
   st.madSigma = isFinite( st.mad ) ? (1.4826 * st.mad) : st.stdDev;

   st.strength = 0.80 * st.madSigma + 0.20 * st.stdDev;

   return st;
}


function SBPP_UI_Prototype_Dialog()
{
   this.__base__ = Dialog;
   this.__base__();
   this.windowTitle = "Skynet Batch Post-Processing v2";

   this.state =
   {
      mode: "Narrowband",
      outputId: "RGB",
      masters: [],
      activeStepIndex: 0,
      referenceChannel: "",
      channels: { Ha:false, Sii:false, Oiii:false, R:false, G:false, B:false, L:false },
      statsByChannel: {},
      isValidMastersSelection: false,

      palette: "SHO",
      useChannelCombination: true,

      mapR: "", mapG: "", mapB: "",
      exprR: "", exprG: "", exprB: "",
   };

   this.stepNames =
   [
      "1. Masters",
      "2. GraXpert",
      "3. Corrections",
      "4. Combination",
      "5. SPCC",
      "6. Tuning (Linear)",
      "7. Stretching",
      "8. Tuning (Non-Linear)",
      "9. Run"
   ];

   this.stepStatus = [ "not","not","not","not","not","not","not","not","not" ];

   this.statusSymbol = function( status )
   {
      switch ( status )
      {
      case "ready": return "●";
      case "done":  return "🟢";
      case "skip":  return "⤼";
      case "warn":  return "⚠";
      case "err":   return "🔴";
      default:      return "○";
      }
   };

   this.appendLog = function( msg )
   {
            if ( this.__logBuffer === undefined )
         this.__logBuffer = [];
      if ( !this.progressBox )
      {
         this.__logBuffer.push( "[" + nowStamp() + "] " + msg );
         return;
      }
      // Flush any buffered lines first
      if ( this.__logBuffer && this.__logBuffer.length )
      {
         for ( let i = 0; i < this.__logBuffer.length; i++ )
            this.progressBox.text += this.__logBuffer[i] + "\n";
         this.__logBuffer = [];
      }
      this.progressBox.text += "[" + nowStamp() + "] " + msg + "\n";
      this.progressBox.cursorPosition = this.progressBox.text.length;
   };

   this.updateHeader = function()
   {
      this.headerModeValue.text = this.state.mode;
      this.headerOutputValue.text = this.state.outputId;
      this.headerMastersValue.text = "" + this.state.masters.length;
      this.headerStepsValue.text = ( function() {
         try {
            var n = ( this.runSummaryTable ? this.runSummaryTable.numberOfChildren : 0 );
            // Pipeline table typically lists Steps 2..N, so add 1 for "Masters" (Step 1).
            if ( n > 0 ) return "" + ( n + 1 );
         } catch ( __e ) {}
         return "12";
      } ).call( this );
   };

   this.updateStepButtons = function()
   {
      for ( let i = 0; i < this.stepButtons.length; i++ )
      {
         this.stepButtons[i].text = this.statusSymbol( this.stepStatus[i] ) + "  " + this.stepNames[i];
         this.stepButtons[i].checked = ( i === this.state.activeStepIndex );
      }
   };

   this.activateStep = function( index )
   {
      if ( index < 0 || index >= this.tabs.numberOfPages )
         return;

      this.state.activeStepIndex = index;
      this.tabs.currentPageIndex = index;
      this.updateStepButtons();
   };

   this.updateRunEnabled = function()
   {
      let prereqOk = true;
      try { if ( this.refreshPrereqChecklist ) prereqOk = this.refreshPrereqChecklist(); } catch ( __e ) { prereqOk = true; }
      this.runButton.enabled = this.state.isValidMastersSelection && prereqOk;
   };

   
   // ---------------------------
   // Execution / cancel / reset helpers
   // ---------------------------
   this.__isRunning = false;
   this.__cancelRequested = false;
   this.__startupDefaults = null;

   this.setExecutionState = function( running )
   {
      this.__isRunning = !!running;

      // Startup/idle: Reset enabled, Cancel disabled, Close enabled.
      // Running: Reset disabled, Cancel enabled, Close disabled.
      try { if ( this.resetButton )  this.resetButton.enabled  = !this.__isRunning; } catch ( __e0 ) {}
      try { if ( this.cancelButton ) this.cancelButton.enabled =  this.__isRunning; } catch ( __e1 ) {}
      try { if ( this.closeButton )  this.closeButton.enabled  = !this.__isRunning; } catch ( __e2 ) {}

      // During run, prevent changing inputs.
      try { if ( this.selectMastersButton ) this.selectMastersButton.enabled = !this.__isRunning; } catch ( __e3 ) {}

      // Run button is special: when idle it depends on masters+prereqs; when running it must be disabled.
      try
      {
         if ( this.__isRunning )
         {
            if ( this.runButton ) this.runButton.enabled = false;
         }
         else
         {
            if ( this.updateRunEnabled ) this.updateRunEnabled();
         }
      }
      catch ( __e4 ) {}

      pumpEvents();
   };

   this.checkCancel = function()
   {
      if ( this.__cancelRequested )
         throw new Error( "SBPP_CANCELLED" );
   };

   
   this.closeAllImagesExcept = function( keepIds )
   {
      // keepIds: object map id->true
      try
      {
         var wins = ImageWindow.windows; // returns an array copy
         for ( var i = 0; i < wins.length; ++i )
         {
            var w = wins[i];
            if ( w == null || w.isNull )
               continue;

            var vid = "";
            try { vid = w.mainView.id; } catch ( __e0 ) { vid = ""; }

            if ( keepIds && keepIds[ vid ] )
               continue;

            try { if ( w && w.length !== undefined ) { if ( w.length>0 ) w[0].forceClose(); } else if ( w ) { w.forceClose(); } } catch ( __e1 ) {}
            pumpEvents();
         }
      }
      catch ( __e )
      {
         // Best-effort cleanup only.
      }
   };
this.captureStartupDefaults = function()
   {
      // Snapshot the initial UI state after construction (what the user sees at startup).
      this.__startupDefaults =
      {
         state: JSON.parse( JSON.stringify( this.state ) ),

         modeNarrowband: ( this.modeNarrowband ? this.modeNarrowband.checked : true ),
         modeBroadband:  ( this.modeBroadband  ? this.modeBroadband.checked  : false ),

         gxSmoothing: ( this.gxSmoothing ? this.gxSmoothing.value : 0.50 ),
         rejectLow:   ( this.rejectLow   ? this.rejectLow.value   : 0.00 ),
         rejectHigh:  ( this.rejectHigh  ? this.rejectHigh.value  : 0.92 ),

         paletteIndex: ( this.paletteCombo ? this.paletteCombo.currentItem : 0 ),
         useChannelCombination: ( this.ccModeRadio ? this.ccModeRadio.checked : true ),

         exprR: ( this.exprREdit ? this.exprREdit.text : "" ),
         exprG: ( this.exprGEdit ? this.exprGEdit.text : "" ),
         exprB: ( this.exprBEdit ? this.exprBEdit.text : "" ),

         ltDenoise:     ( this.ltDenoise     ? this.ltDenoise.value : 0.50 ),
         ltIterations:  ( this.ltIterations  ? this.ltIterations.value : 1 ),
         ltSharpenStars:      ( this.ltSharpenStars      ? this.ltSharpenStars.text      : "0.50" ),
         ltSharpenNonstellar: ( this.ltSharpenNonstellar ? this.ltSharpenNonstellar.text : "0.50" ),
         ltAdjustStarHalos:   ( this.ltAdjustStarHalos   ? this.ltAdjustStarHalos.text   : "-0.10" ),

         ltGenStarImage:  ( this.ltGenStarImage  ? this.ltGenStarImage.checked  : true ),
         ltUnscreenStars: ( this.ltUnscreenStars ? this.ltUnscreenStars.checked : true ),
         ltLargeOverlap:  ( this.ltLargeOverlap  ? this.ltLargeOverlap.checked  : true ),

         lumSharpEnable: ( this.lumSharpEnable ? this.lumSharpEnable.checked : false )
      };
   };

   this.resetToStartupDefaults = function()
   {
      if ( this.__isRunning )
         return;

      if ( !this.__startupDefaults )
         this.captureStartupDefaults();

      let D = this.__startupDefaults;

      // Restore state
      try { this.state = JSON.parse( JSON.stringify( D.state ) ); } catch ( __e0 ) {}

      // Restore mode UI
      try { if ( this.modeNarrowband ) this.modeNarrowband.checked = !!D.modeNarrowband; } catch ( __e1 ) {}
      try { if ( this.modeBroadband )  this.modeBroadband.checked  = !!D.modeBroadband;  } catch ( __e2 ) {}

      // Restore numeric controls
      try { if ( this.gxSmoothing ) this.gxSmoothing.setValue( D.gxSmoothing ); } catch ( __e3 ) {}
      try { if ( this.rejectLow )   this.rejectLow.setValue( D.rejectLow );     } catch ( __e4 ) {}
      try { if ( this.rejectHigh )  this.rejectHigh.setValue( D.rejectHigh );  } catch ( __e5 ) {}

      // Restore combination UI
      try { if ( this.paletteCombo ) this.paletteCombo.currentItem = D.paletteIndex; } catch ( __e6 ) {}
      try { if ( this.ccModeRadio ) this.ccModeRadio.checked = !!D.useChannelCombination; } catch ( __e7 ) {}
      try { if ( this.pmModeRadio ) this.pmModeRadio.checked = !D.useChannelCombination; } catch ( __e8 ) {}

      try { if ( this.exprREdit ) this.exprREdit.text = D.exprR; } catch ( __e9 ) {}
      try { if ( this.exprGEdit ) this.exprGEdit.text = D.exprG; } catch ( __e10 ) {}
      try { if ( this.exprBEdit ) this.exprBEdit.text = D.exprB; } catch ( __e11 ) {}

      // Restore linear tuning
      try { if ( this.ltDenoise ) this.ltDenoise.setValue( D.ltDenoise ); } catch ( __e12 ) {}
      try { if ( this.ltIterations ) this.ltIterations.value = D.ltIterations; } catch ( __e13 ) {}
      try { if ( this.ltSharpenStars ) this.ltSharpenStars.text = D.ltSharpenStars; } catch ( __e14 ) {}
      try { if ( this.ltSharpenNonstellar ) this.ltSharpenNonstellar.text = D.ltSharpenNonstellar; } catch ( __e15 ) {}
      try { if ( this.ltAdjustStarHalos ) this.ltAdjustStarHalos.text = D.ltAdjustStarHalos; } catch ( __e16 ) {}

      try { if ( this.ltGenStarImage ) this.ltGenStarImage.checked = !!D.ltGenStarImage; } catch ( __e17 ) {}
      try { if ( this.ltUnscreenStars ) this.ltUnscreenStars.checked = !!D.ltUnscreenStars; } catch ( __e18 ) {}
      try { if ( this.ltLargeOverlap ) this.ltLargeOverlap.checked = !!D.ltLargeOverlap; } catch ( __e19 ) {}
      try { if ( this.lumSharpEnable ) this.lumSharpEnable.checked = !!D.lumSharpEnable; } catch ( __e19b ) {}

      // Clear masters, stats, pipeline table, progress, elapsed label
      try { this.state.masters = []; } catch ( __e20 ) {}
      try { this.state.isValidMastersSelection = false; } catch ( __e21 ) {}

      try { if ( this.mastersList ) this.mastersList.clear(); } catch ( __e22 ) {}
      try { if ( this.detectedChannelsValue ) this.detectedChannelsValue.text = ( this.state.mode === "Narrowband" ) ? "Ha ○   Sii ○   Oiii ○" : "R ○   G ○   B ○"; } catch ( __e23 ) {}

      try { if ( this.hideCorrectionsStats ) this.hideCorrectionsStats(); } catch ( __e24 ) {}

      try
      {
         if ( this.runSummaryTable )
         {
            // TreeBox does not reliably expose firstChild/nextSibling across PI versions.
            // Use indexed access instead.
            for ( let i = 0; i < this.runSummaryTable.numberOfChildren; ++i )
            {
               let n = this.runSummaryTable.child( i );
               if ( !n ) continue;
               try { n.setText( 1, "" ); } catch ( __eA ) {}
               try { n.setText( 2, "" ); } catch ( __eB ) {}
               try { n.setText( 3, "" ); } catch ( __eC ) {}
            }
         }
      }
      catch ( __e25 ) {}

      try { if ( this.elapsedLabel ) this.elapsedLabel.text = "Elapsed Time: 00:00"; } catch ( __e26 ) {}

      try { if ( this.progressBox ) this.progressBox.text = ""; } catch ( __e27 ) {}

      // Refresh header and run enabled state
      try { if ( this.updateHeader ) this.updateHeader(); } catch ( __e28 ) {}
      this.setExecutionState( false );
      this.appendLog( "Reset to startup defaults." );
   };

// ---------------------------
   // Corrections helpers
   // ---------------------------
   this.hideCorrectionsStats = function()
   {
      this.statsGroup.visible = false;
      this.statsLegend.visible = false;
      this.statsTable.clear();
      this.state.referenceChannel = "";
   };

   this.setReferenceChannel = function( ch )
   {
      try { this.statsLegend.text = "Current Reference: " + ch; } catch ( __e ) {}

      this.state.referenceChannel = ch;
      this.appendLog( "Reference channel set to " + ch );
   };

   this.populateDummyStats = function()
   {
      let channels = ( this.state.mode === "Narrowband" ) ? [ "Ha", "Sii", "Oiii" ] : [ "R", "G", "B" ];
      let base = ( this.state.mode === "Narrowband" ) ? 0.123456 : 0.045678;

      this.statsTable.clear();

      let bestNode = null;
      let bestDelta = -1;

      for ( let i = 0; i < channels.length; i++ )
      {
         let mean = base + i * 0.010321;
         let median = mean - ( 0.001500 + i * 0.000200 );
         let delta = mean - median;

         let n = new TreeBoxNode( this.statsTable );
         n.setText( 0, channels[i] );
         n.setText( 1, fmt6( mean ) );
         n.setText( 2, fmt6( median ) );
         n.setText( 3, fmt6( delta ) );

         if ( delta > bestDelta )
         {
            bestDelta = delta;
            bestNode = n;
         }
      }

      this.statsGroup.visible = true;
      this.statsLegend.visible = true;


      // Update PixelMath expression suggestions regardless of combination mode.
      try { if ( this.applySuggestedPixelMathExpressions ) this.applySuggestedPixelMathExpressions(); } catch ( __eSugg ) {}
      // Default reference channel: row with the highest delta
      try
      {
         let bestNode = null;
         let bestDelta = -1;
         for ( let n = this.statsTable.firstChild; n; n = n.nextSibling )
         {
            let dlt = parseFloat( n.text( 3 ) );
            if ( isFinite( dlt ) && dlt > bestDelta )
            {
               bestDelta = dlt;
               bestNode = n;
            }
         }

         if ( bestNode )
         {
            // Let the UI settle (selection highlight can fail if the control has not been laid out yet).
            try { processEvents(); } catch ( __ePE0 ) {}
            try { this.statsTable.focus(); } catch ( __ePE1 ) {}
            try { processEvents(); } catch ( __ePE2 ) {}

            // Clear selection explicitly.
            for ( let n = this.statsTable.firstChild; n; n = n.nextSibling )
               n.selected = false;

            // Set current + selected.
            try { this.statsTable.setCurrentNode( bestNode ); } catch ( __e0 ) {}
            this.statsTable.currentNode = bestNode;
            bestNode.selected = true;

            // Ensure it is visible and the highlight is painted.
            try { this.statsTable.ensureNodeVisible( bestNode ); } catch ( __e1 ) {}
            try { processEvents(); } catch ( __e2 ) {}

            this.setReferenceChannel( bestNode.text( 0 ) );
         }
      }
      catch ( __eSel ) {}

      if ( bestNode )
      {
         this.statsTable.currentNode = bestNode;
         bestNode.selected = true;
         this.setReferenceChannel( bestNode.text( 0 ) );
      }
   };

   this.loadMastersAndPopulateStats = function()
   {
      // Close previously loaded windows (if any)
      if ( this.state.loadedWindows && this.state.loadedWindows.length )
      {
         for ( let i = 0; i < this.state.loadedWindows.length; i++ )
            try { if ( this.state.loadedWindows[i] && !this.state.loadedWindows[i].isNull ) this.state.loadedWindows[i].forceClose(); } catch ( __e0 ) {}
      }

      this.state.loadedWindows = [];

      // Stats cache for PixelMath suggestions
      this.state.statsByChannel = {};

// Snapshot currently open windows so we can close EVERYTHING opened during this load attempt
// (including extra XISF embedded views like crop masks).
var __preWinIds = {};
try
{
   var __wins0 = ImageWindow.windows;
   for ( var __w0 = 0; __w0 < __wins0.length; __w0++ )
      try { __preWinIds[ __wins0[__w0].mainView.id ] = true; } catch ( __ePW0 ) {}
}
catch ( __ePW ) {}

var __closeNewWindows = function( preIds )
{
   try
   {
      var __wins1 = ImageWindow.windows;
      for ( var __w1 = 0; __w1 < __wins1.length; __w1++ )
      {
         var __id1 = null;
         try { __id1 = __wins1[__w1].mainView.id; } catch ( __eID1 ) { __id1 = null; }
         if ( __id1 && preIds && preIds[ __id1 ] )
            continue;
         try { __wins1[__w1].forceClose(); } catch ( __eFCN ) { try { __wins1[__w1].close(); } catch ( __eCN ) {} }
      }
   }
   catch ( __eCNW ) {}
};


      // Load, rename to canonical ids, apply visual STF, compute stats
      this.statsTable.clear();

      let rows = [];
      for ( let i = 0; i < this.state.masters.length; i++ )
      {
         let filePath = this.state.masters[i];
         let key = guessKeyFromFilename( filePath );
         if ( !key )
            continue;

         try
         {
            let w = openImage( filePath );
            this.state.loadedWindows.push( w );

            // SPCC needs a real WCS. Some images expose a non-null astrometricSolution object that isn't actually valid,
            // so we validate strictly via embedded WCS properties/keywords.
            var __wcsOk = false;
            try { __wcsOk = checkWCS( w ); } catch ( __eWcs ) { __wcsOk = false; }

            if ( !__wcsOk )
            {
               // Log and hard abort: SPCC requires WCS on all masters
               try { this.appendLog( "Critical: '" + File.extractNameAndExtension( filePath ) + "' has no valid astrometric solution usable by SPCC." ); } catch ( __eLog ) {}
               try { new MessageBox( "One or more master files doesn't have a valid astrometric solution", "SBPP - Critical Error", StdIcon_Error, StdButton_Ok ).execute(); } catch ( __eMB ) {}

               // Close any windows opened during this selection attempt
               __closeNewWindows( __preWinIds );

               this.state.loadedWindows = [];

               // Clear selection + UI
               try { this.state.masters = []; } catch ( __eCM0 ) {}
               try { this.state.isValidMastersSelection = false; } catch ( __eCM1 ) {}
               try { if ( this.mastersList ) this.mastersList.clear(); } catch ( __eCM2 ) {}
               try { if ( this.detectedChannelsValue ) this.detectedChannelsValue.text = ( this.state.mode === "Narrowband" ) ? "Ha ○   Sii ○   Oiii ○" : "R ○   G ○   B ○"; } catch ( __eCM3 ) {}
               try { if ( this.statsTable ) this.statsTable.clear(); } catch ( __eCM4 ) {}
               try { if ( this.hideCorrectionsStats ) this.hideCorrectionsStats(); } catch ( __eCM5 ) {}

               return;
            }

            this.appendLog( "Master loaded (WCS OK): " + key + " (" + filePath + ")" );

            renameMainViewTo( w.mainView, key );
            applyVisualSTF( w.mainView, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, DEFAULT_AUTOSTRETCH_CLINK );

            let st = getRobustViewStats( w.mainView );
            try { this.state.statsByChannel[key] = st; } catch ( __eST ) {}

            let mean = ( st && isFinite( st.mean ) ) ? st.mean : 0;
            let median = ( st && isFinite( st.median ) ) ? st.median : 0;
            let delta = Math.abs( mean - median );

            rows.push( { ch:key, mean:mean, median:median, delta:delta } );
         }
         
catch ( __e )
         {
            // Abort: if any master fails to load or fails WCS validation, close everything and stop.
            try { this.appendLog( "Failed to load: " + filePath + " (" + __e + ")" ); } catch ( __eL ) {}

            // If this failure is due to missing/invalid WCS, show the required critical popup,
            // clear the masters list, and close any windows opened during this attempt.
            var __isWcsError = false;
            try
            {
               var __s = "" + __e;
               __isWcsError = ( __s.indexOf( "astrometric" ) >= 0 && __s.indexOf( "solution" ) >= 0 );
            }
            catch ( __eS ) { __isWcsError = false; }

            if ( __isWcsError )
            {
               try { new MessageBox( "One or more master files doesn't have a valid astrometric solution", "SBPP - Critical Error", StdIcon_Error, StdButton_Ok ).execute(); } catch ( __eMB2 ) {}

               // Close any windows opened during this selection attempt
               __closeNewWindows( __preWinIds );

               try { this.state.loadedWindows = []; } catch ( __eCLRw ) {}
               try { this.state.masters = []; } catch ( __eCLRm ) {}
               try { this.state.statsByChannel = {}; } catch ( __eCLRst ) {}
               try { this.state.isValidMastersSelection = false; } catch ( __eCLRv ) {}

               // Clear UI elements
               try { if ( this.mastersList ) this.mastersList.clear(); } catch ( __eUI0 ) {}
               try { if ( this.statsTable ) this.statsTable.clear(); } catch ( __eUI1 ) {}
               try { if ( this.detectedChannelsValue ) this.detectedChannelsValue.text = ( this.state.mode === "Narrowband" ) ? "Ha ○   Sii ○   Oiii ○" : "R ○   G ○   B ○"; } catch ( __eUI2 ) {}
               try { if ( this.hideCorrectionsStats ) this.hideCorrectionsStats(); } catch ( __eUI3 ) {}

               return;
            }

            // Non-WCS failure: close opened windows, clear state, then propagate.
            __closeNewWindows( __preWinIds );

            try { this.state.loadedWindows = []; } catch ( __eCLR ) {}
            try { this.state.masters = []; } catch ( __eCLR2 ) {}
            try { this.state.statsByChannel = {}; } catch ( __eCLR3 ) {}

            throw __e;
         }
      }

      // Populate table in canonical order
      let order = ( this.state.mode === "Narrowband" ) ? [ "Ha", "Sii", "Oiii" ] : [ "R", "G", "B" ];
      for ( let k = 0; k < order.length; k++ )
      {
         let r = null;
         for ( let j = 0; j < rows.length; j++ )
            if ( rows[j].ch === order[k] ) { r = rows[j]; break; }

         if ( r )
         {
            let n = new TreeBoxNode( this.statsTable );
            n.setText( 0, r.ch );
            n.setText( 1, fmt6( r.mean ) );
            n.setText( 2, fmt6( r.median ) );
            n.setText( 3, fmt6( r.delta ) );
         }
      }

      this.statsGroup.visible = true;
      this.statsLegend.visible = true;
   

      // Update PixelMath expression suggestions based on the actually loaded channels.
      try { if ( this.applySuggestedPixelMathExpressions ) this.applySuggestedPixelMathExpressions(); } catch ( __eSugg ) {}
};



   // ---- Workflow execution (step-by-step) ----
   this.runWorkflow = function()
   {
      this.__cancelRequested = false;
      this.setExecutionState( true );


      var __runCompleted = false;
      try
      {
         this.appendLog( "Run started." );

         // Elapsed time starts at 00:00 and accumulates as steps complete
         let runT0 = new Date().getTime();
         try { if ( this.elapsedTimeLabel ) this.elapsedTimeLabel.text = "Elapsed Time: 00:00"; } catch ( __eET0 ) {}
         let updateElapsed = function( ms )
         {
            try { if ( this.elapsedTimeLabel ) this.elapsedTimeLabel.text = "Elapsed Time: " + fmtMSS( ms ); } catch ( __eET1 ) {}
         };


         // Determine canonical channel ids to process (2 or 3 ids).
         let order = ( this.state.mode === "Narrowband" ) ? [ "Ha", "Sii", "Oiii" ] : [ "R", "G", "B" ];
         let ids = [];
         for ( let i = 0; i < order.length; i++ )
         {
            let id = order[i];
            let w = ImageWindow.windowById( id );
            if ( w && !w.isNull )
               ids.push( id );
         }

         if ( ids.length < 2 )
         {
            this.appendLog( "Run aborted: expected 2 or 3 loaded masters, found " + ids.length + "." );
            return;
         }

         let stampRow = function( idx, startStamp, finishStamp, durStamp )
         {
            let node = this.runSummaryTable.child( idx );
            if ( node )
            {
               if ( startStamp !== null && startStamp !== undefined ) node.setText( 1, startStamp );
               if ( finishStamp !== null && finishStamp !== undefined ) node.setText( 2, finishStamp );
               if ( durStamp !== null && durStamp !== undefined ) node.setText( 3, durStamp );
            }
         };

         // Step 2: GraXpert (Background Extraction)  (idx 0)
         let t0 = new Date().getTime();
         let s0 = nowStamp();
         stampRow.call( this, 0, s0, "", "" );
         pumpEvents();

         this.applyGraxpert( ids );

         this.checkCancel();

         let t1 = new Date().getTime();
         stampRow.call( this, 0, s0, nowStamp(), fmtHMS( t1 - t0 ) );
         updateElapsed.call( this, t1 - runT0 );
         pumpEvents();

         // Step 3: LinearFit  (idx 1)
         let refId = this.state.referenceChannel;
         if ( !refId || refId.length < 1 )
            refId = ids[0];

         let t2 = new Date().getTime();
         let s1 = nowStamp();
         stampRow.call( this, 1, s1, "", "" );
         pumpEvents();

         this.applyLinearFit( refId, ids );

         this.checkCancel();

         let t3 = new Date().getTime();
         stampRow.call( this, 1, s1, nowStamp(), fmtHMS( t3 - t2 ) );
         updateElapsed.call( this, t3 - runT0 );
         pumpEvents();

         // Step 4: PSF Correction (BlurXTerminator)  (idx 2)
         let t4_0 = new Date().getTime();
         let s2 = nowStamp();
         stampRow.call( this, 2, s2, "", "" );
         pumpEvents();

         this.applyPSFCorrection( ids );

         this.checkCancel();

         let t4_1 = new Date().getTime();
         stampRow.call( this, 2, s2, nowStamp(), fmtHMS( t4_1 - t4_0 ) );
         updateElapsed.call( this, t4_1 - runT0 );
         pumpEvents();

         // Step 5: Channel Combination  (idx 3)
         let t5_0 = new Date().getTime();
         let s3 = nowStamp();
         stampRow.call( this, 3, s3, "", "" );
         pumpEvents();

         this.applyChannelCombination( ids );

         this.checkCancel();

         let t5_1 = new Date().getTime();
         stampRow.call( this, 3, s3, nowStamp(), fmtHMS( t5_1 - t5_0 ) );
         updateElapsed.call( this, t5_1 - runT0 );
         pumpEvents();

         // Step 6: Color Correction (SPCC)  (idx 4)
         let t6_0 = new Date().getTime();
         let s4 = nowStamp();
         stampRow.call( this, 4, s4, "", "" );
         pumpEvents();

         this.applySPCC();

         this.checkCancel();

         let t6_1 = new Date().getTime();
         stampRow.call( this, 4, s4, nowStamp(), fmtHMS( t6_1 - t6_0 ) );
         updateElapsed.call( this, t6_1 - runT0 );
         pumpEvents();

         // Step 7: Noise Reduction (Linear) (NXT)  (idx 5)
         let t7_0 = new Date().getTime();
         let s5 = nowStamp();
         stampRow.call( this, 5, s5, "", "" );
         pumpEvents();

         this.applyNXT();

         this.checkCancel();

         let t7_1 = new Date().getTime();
         stampRow.call( this, 5, s5, nowStamp(), fmtHMS( t7_1 - t7_0 ) );
         updateElapsed.call( this, t7_1 - runT0 );
         pumpEvents();

         // Step 8: Sharpening (Linear) (BXT)  (idx 6)
         let t8_0 = new Date().getTime();
         let s6 = nowStamp();
         stampRow.call( this, 6, s6, "", "" );
         pumpEvents();

         this.applyBXT();

         this.checkCancel();

         let t8_1 = new Date().getTime();
         stampRow.call( this, 6, s6, nowStamp(), fmtHMS( t8_1 - t8_0 ) );
         updateElapsed.call( this, t8_1 - runT0 );
         pumpEvents();

         // Step 9: Star Extraction (SXT)  (idx 7)
         let t9_0 = new Date().getTime();
         let s7 = nowStamp();
         stampRow.call( this, 7, s7, "", "" );
         pumpEvents();

         this.applySXT();

         this.checkCancel();

         let t9_1 = new Date().getTime();
         stampRow.call( this, 7, s7, nowStamp(), fmtHMS( t9_1 - t9_0 ) );
         updateElapsed.call( this, t9_1 - runT0 );
         pumpEvents();

         
// Step 10: Stretch (HT / MAS)  (idx 8)
let doStretch = false;
try { doStretch = ( (this.htEnable && this.htEnable.checked) || (this.masEnable && this.masEnable.checked) ); } catch ( __eS0 ) { doStretch = false; }

if ( doStretch )
{
   let t10_0 = new Date().getTime();
   let s8 = nowStamp();
   stampRow.call( this, 8, s8, "", "" );
   pumpEvents();

   this.applyStretching();

   this.checkCancel();

   let t10_1 = new Date().getTime();
   stampRow.call( this, 8, s8, nowStamp(), fmtHMS( t10_1 - t10_0 ) );
   updateElapsed.call( this, t10_1 - runT0 );
   pumpEvents();
}
else
{
   this.appendLog( "Step 10 (Stretch) disabled (skipping)." );
}



// Step 11: Noise Reduction (Nonlinear) on stretched starless (idx 9)
let doNLNXT = false;
try { doNLNXT = !!( this.nlNrEnable && this.nlNrEnable.checked ); } catch ( __eNL0 ) { doNLNXT = false; }

if ( doNLNXT )
{
   let t11_0 = new Date().getTime();
   let s9 = nowStamp();
   stampRow.call( this, 9, s9, "", "" );
   pumpEvents();

   this.applyNXT_Stchd();

   this.checkCancel();

   let t11_1 = new Date().getTime();
   stampRow.call( this, 9, s9, nowStamp(), fmtHMS( t11_1 - t11_0 ) );
   updateElapsed.call( this, t11_1 - runT0 );
   pumpEvents();
}
else
{
   this.appendLog( "Step 11 (Nonlinear NXT) disabled (skipping)." );
}

// Step 12: Sharpening (Nonlinear) on stretched starless (idx 10)
let doNLBXT = false;
try { doNLBXT = !!( this.nlSharpEnable && this.nlSharpEnable.checked ); } catch ( __eNL1 ) { doNLBXT = false; }

if ( doNLBXT )
{
   let t12_0 = new Date().getTime();
   let s10 = nowStamp();
   stampRow.call( this, 10, s10, "", "" );
   pumpEvents();

   this.applyBXT_Stchd();

   this.checkCancel();

   let t12_1 = new Date().getTime();
   stampRow.call( this, 10, s10, nowStamp(), fmtHMS( t12_1 - t12_0 ) );
   updateElapsed.call( this, t12_1 - runT0 );
   pumpEvents();
}
else
{
   this.appendLog( "Step 12 (Nonlinear BXT) disabled (skipping)." );
}

// Step 13: Lum Sharpening (idx 11)
let doLumSharp = false;
try { doLumSharp = !!( this.lumSharpEnable && this.lumSharpEnable.checked ); } catch ( __eLS0 ) { doLumSharp = false; }

if ( doLumSharp )
{
   let t13_0 = new Date().getTime();
   let s11 = nowStamp();
   stampRow.call( this, 11, s11, "", "" );
   pumpEvents();

   this.appendLog( "Step 13 (Lum Sharpening) started." );
   this.applyLumSharpening();
   this.appendLog( "Step 13 (Lum Sharpening) finished." );

   this.checkCancel();

   let t13_1 = new Date().getTime();
   stampRow.call( this, 11, s11, nowStamp(), fmtHMS( t13_1 - t13_0 ) );
   updateElapsed.call( this, t13_1 - runT0 );
   pumpEvents();
}
else
{
   this.appendLog( "Step 13 (Lum Sharpening) disabled (skipping)." );
}

         // Final cleanup: close all intermediate images, keep only requested outputs.
         try
         {
            var keep = { "stars_linear":true, "starless_linear":true, "starless_HT":true, "starless_MAS":true, "starless_HT_Lum":true, "starless_MAS_Lum":true, "HT_starless_Lum":true, "MAS_starless_Lum":true };
            // Also keep any luminance extracts created during Step 13.
            try {
               var _ws = ImageWindow.windows;
               for ( var _i = 0; _i < _ws.length; ++_i )
               {
                  var _w = _ws[_i];
                  if ( _w == null || _w.isNull )
                     continue;
                  var _id = _w.mainView.id;
                  if ( typeof _id === "string" )
                  {
                     var _l = _id.toLowerCase();
                     if ( ( _l.length >= 4 && _l.substring( _l.length - 4 ) === "_lum" ) || ( _l.length >= 9 && _l.substring( _l.length - 9 ) === "_lum_mask" ) || ( _l.length >= 8 && _l.substring( _l.length - 8 ) === "_lum_usm" ) || ( _l.length >= 8 && _l.substring( _l.length - 8 ) === "_lum_mlt" ) || ( _l.length >= 14 && _l.substring( _l.length - 14 ) === "_lum_sharpener" ) || ( _l.length >= 5 && _l.substring( _l.length - 5 ) === "_mask" ) || ( _l.length >= 4 && _l.substring( _l.length - 4 ) === "_usm" ) || ( _l.length >= 4 && _l.substring( _l.length - 4 ) === "_mlt" ) )
                        keep[_id] = true;
                  }
               }
            } catch ( __eKeepLum ) {}
            // If a keep-id does not exist, it will simply be ignored.
            this.closeAllImagesExcept( keep );
            this.appendLog( "Closed intermediate images (kept: stars_linear, starless_linear, starless_HT, starless_MAS)." );
         }
         catch ( __eCL )
         {
            this.appendLog( "Warning: couldn't close intermediate images: " + __eCL );
         }

this.appendLog( "Run completed (GraXpert + LinearFit + PSF + Combination + SPCC + NXT + BXT + SXT + Stretch + NL NXT + NL BXT + Lum Sharpening)." );
         __runCompleted = true;
      }
      catch ( __e )
      {
         try
         {
            if ( __e && __e.message && __e.message.indexOf( "SBPP_CANCELLED" ) >= 0 )
            {
               this.appendLog( "Run cancelled." );
            }
            else
            {
               this.appendLog( "Run failed: " + __e );
            }
         }
         catch ( __eX )
         {
            this.appendLog( "Run failed: " + __e );
         }
      }
      finally
      {
         try
         {
            // Persist Step 2..N configuration only on successful completion, never on cancel.
            if ( __runCompleted && !this.__cancelRequested )
               sbppTrySaveCurrentConfiguration( this, function( s ){ try { this.appendLog( s ); } catch( __e ) {} }.bind( this ) );
         }
         catch ( __eS ) {}

         this.setExecutionState( false );
      }
   };

   // ---------------------------
   // Workflow step functions (called by runWorkflow)
   // ---------------------------

   this.applyGraxpert = function( ids )
   {
      // Apply GraXpert with replaceImage=true, using UI smoothing.
      let s = 0.5;
      try { s = this.gxSmoothing.value; } catch ( __e0 ) {}
      if ( !isFinite( s ) ) s = 0.5;
      s = Math.range( s, 0.0, 1.0 );

      this.appendLog( "GraXpert smoothing: " + s.toFixed( 2 ) );

      var gx = new GraXpert;
      gx.backgroundExtraction = true;
      gx.smoothing = s;
      gx.correction = "Subtraction";
      gx.createBackground = false;
      gx.backgroundExtractionAIModel = "";
      gx.denoising = false;
      gx.strength = 1.00;
      gx.batchSize = 4;
      gx.denoiseAIModel = "2.0.0";
      gx.disableGPU = false;
      gx.replaceImage = true;
      gx.showLogs = false;
      gx.appPath = "";
      gx.deconvolution = false;
      gx.deconvolutionMode = "Object-only";
      gx.deconvolutionObjectStrength = 0.5;
      gx.deconvolutionObjectPSFSize = 5.0;
      gx.deconvolutionObjectAIModel = "";
      gx.deconvolutionStarsAIModel = "";

      for ( let i = 0; i < ids.length; i++ )
      {
         let id = ids[i];
         let w = ImageWindow.windowById( id );
         if ( w == null || w.isNull )
         {
            this.appendLog( "GraXpert skipped (missing view): " + id );
            continue;
         }

         this.appendLog( "GraXpert applying to: " + id );
         gx.executeOn( w.mainView );

         pumpEvents();

         // Re-apply a visual STF for convenience (pixels are replaced).
         try { applyVisualSTF( w.mainView, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, DEFAULT_AUTOSTRETCH_CLINK ); } catch ( __e1 ) {}
      }

      this.appendLog( "GraXpert completed." );
   };



   this.applyLinearFit = function( referenceId, ids )
   {
      // Apply LinearFit using referenceId to all other ids.
      let wRef = ImageWindow.windowById( referenceId );
      if ( wRef == null || wRef.isNull )
      {
         this.appendLog( "LinearFit aborted: reference view not found: " + referenceId );
         return;
      }

      let rejectLow = 0.0;
      let rejectHigh = 0.92;
      try { rejectLow = this.rejectLow.value; } catch ( __e0 ) {}
      try { rejectHigh = this.rejectHigh.value; } catch ( __e1 ) {}
      if ( !isFinite( rejectLow ) ) rejectLow = 0.0;
      if ( !isFinite( rejectHigh ) ) rejectHigh = 0.92;

      this.appendLog( "LinearFit reference: " + referenceId + " (rejectLow=" + rejectLow.toFixed( 2 ) + ", rejectHigh=" + rejectHigh.toFixed( 2 ) + ")" );

      for ( let i = 0; i < ids.length; i++ )
      {
         let id = ids[i];
         if ( id === referenceId )
            continue;

         let w = ImageWindow.windowById( id );
         if ( w == null || w.isNull )
         {
            this.appendLog( "LinearFit skipped (missing view): " + id );
            continue;
         }

         let P = new LinearFit;
         P.referenceViewId = referenceId;
         P.rejectLow = rejectLow;
         P.rejectHigh = rejectHigh;

         this.appendLog( "LinearFit applying to: " + id );
         if ( !P.executeOn( w.mainView ) )
            this.appendLog( "LinearFit failed on: " + id );
         else
         {
            this.appendLog( "LinearFit applied to: " + id );
            // Re-apply visual STF immediately after pixel changes.
            try { applyVisualSTF( w.mainView, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, DEFAULT_AUTOSTRETCH_CLINK ); } catch ( __e2 ) {}
         }

         pumpEvents();
      }

      this.appendLog( "LinearFit completed." );
   };


   this.applyPSFCorrection = function( ids )
   {
      // BlurXTerminator PSF correction (Correct Only)
      var bxt = new BlurXTerminator;
      bxt.ai_file = sbppPickAIFile( "BlurXTerminator.4.pb" );
      bxt.correct_only = true;
      bxt.correct_first = false;
      bxt.nonstellar_then_stellar = false;
      bxt.lum_only = false;
      bxt.sharpen_stars = 0.00;
      bxt.adjust_halos = 0.00;
      bxt.nonstellar_psf_diameter = 0.00;
      bxt.auto_nonstellar_psf = true;
      bxt.sharpen_nonstellar = 0.50;

      for ( let i = 0; i < ids.length; i++ )
      {
         let id = ids[i];
         let w = ImageWindow.windowById( id );
         if ( w == null || w.isNull )
         {
            this.appendLog( "BXT skipped (missing view): " + id );
            continue;
         }

         this.appendLog( "BXT PSF (Correct Only) applying to: " + id );
         bxt.executeOn( w.mainView );

         pumpEvents();

         // Re-apply visual STF immediately after pixel changes.
         try { applyVisualSTF( w.mainView, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, DEFAULT_AUTOSTRETCH_CLINK ); } catch ( __e1 ) {}
      }

      this.appendLog( "BXT PSF completed." );
   };





   this.applyChannelCombination = function( ids )
   {
      // Create a new combined RGB image using either ChannelCombination or PixelMath, depending on UI selection.
      let palette = this.state.palette;
      let outId = this.state.outputId;
      if ( !outId || outId.length < 1 ) outId = "RGB";

      // Resolve source ids for R,G,B according to palette.
      let rId = "", gId = "", bId = "";

      if ( palette === "RGB" )
      {
         rId = "R"; gId = "G"; bId = "B";
      }
      else if ( palette === "SHO" )
      {
         rId = "Sii"; gId = "Ha"; bId = "Oiii";
      }
      else if ( palette === "HSO" )
      {
         rId = "Ha"; gId = "Sii"; bId = "Oiii";
      }
      else if ( palette === "HOO" )
      {
         rId = "Ha"; gId = "Oiii"; bId = "Oiii";
      }
      else
      {
         // Fallback: use first 3 ids in the provided list (or duplicates if only 2).
         rId = ( ids.length > 0 ) ? ids[0] : "";
         gId = ( ids.length > 1 ) ? ids[1] : rId;
         bId = ( ids.length > 2 ) ? ids[2] : gId;
      }

      // Validate existence for ChannelCombination mode; PixelMath may still work if expressions reference ids.
      let wr = ImageWindow.windowById( rId );
      let wg = ImageWindow.windowById( gId );
      let wb = ImageWindow.windowById( bId );

      this.appendLog( "Channel Combination (" + ( this.state.useChannelCombination ? "ChannelCombination" : "PixelMath" ) + "), Palette: " + palette );
      this.appendLog( "Mapping: R=" + rId + " G=" + gId + " B=" + bId + " -> " + outId );

      // Close any existing output window with same id to avoid confusion.
      try
      {
         let existing = ImageWindow.windowById( outId );
         if ( existing && !existing.isNull )
            existing.forceClose();
      }
      catch ( __e0 ) {}

      if ( this.state.useChannelCombination )
      {
         if ( ( !wr || wr.isNull ) || ( !wg || wg.isNull ) || ( !wb || wb.isNull ) )
            throw new Error( "ChannelCombination requires existing views for mapped channels." );

         var CC = new ChannelCombination;
         CC.colorSpace = ChannelCombination.prototype.RGB;
         CC.channels =
         [
            [ true, rId ],
            [ true, gId ],
            [ true, bId ]
         ];
         CC.createNewImage = true;
         CC.newImageId = outId;

         var before = ImageWindow.activeWindow;
         if ( !CC.executeGlobal() )
            throw new Error( "ChannelCombination failed." );

         pumpEvents();

         var outWin = ImageWindow.windowById( outId );
         if ( outWin == null || outWin.isNull )
            outWin = ImageWindow.activeWindow;

         if ( outWin == null || outWin.isNull )
            throw new Error( "ChannelCombination output image not found: " + outId );

         try { renameMainViewTo( outWin.mainView, outId ); } catch ( __e1 ) {}
         outWin.show();
         ImageWindow.activeWindow = outWin;

         pumpEvents();
         try { applyVisualSTF( outWin.mainView, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, DEFAULT_AUTOSTRETCH_CLINK ); } catch ( __e2 ) {}

         this.appendLog( "ChannelCombination created: " + outId );
         try { this.state.outputId = outWin.mainView.id; } catch ( __eOut0 ) {}
         return outWin.mainView;
      }
      else
      {
         // PixelMath mode. Use expressions from UI text boxes.
         let exprR = ( this.exprREdit ) ? this.exprREdit.text : "";
         let exprG = ( this.exprGEdit ) ? this.exprGEdit.text : "";
         let exprB = ( this.exprBEdit ) ? this.exprBEdit.text : "";

         if ( exprR.length < 1 || exprG.length < 1 || exprB.length < 1 )
            throw new Error( "PixelMath expressions are empty." );

         this.appendLog( "PixelMath Expr R: " + exprR );
         this.appendLog( "PixelMath Expr G: " + exprG );
         this.appendLog( "PixelMath Expr B: " + exprB );

         var P = new PixelMath;
         P.expression  = exprR;
         P.expression1 = exprG;
         P.expression2 = exprB;
         P.expression3 = "";
         P.useSingleExpression = false;
         P.symbols = "";
         P.clearImageCacheAndExit = false;
         P.cacheGeneratedImages = false;
         P.generateOutput = true;
         P.singleThreaded = false;
         P.optimization = true;
         P.use64BitWorkingImage = false;
         P.rescale = false;
         P.rescaleLower = 0;
         P.rescaleUpper = 1;
         P.truncate = true;
         P.truncateLower = 0;
         P.truncateUpper = 1;
         P.createNewImage = true;
         P.showNewImage = true;
         P.newImageId = outId;
         P.newImageWidth = 0;
         P.newImageHeight = 0;
         P.newImageAlpha = false;
         P.newImageColorSpace = PixelMath.prototype.RGB;
         P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

         // Anchor execution on an existing window (use G mapped channel when possible).
         let anchor = wg;
         if ( anchor == null || anchor.isNull ) anchor = wr;
         if ( anchor == null || anchor.isNull ) anchor = wb;
         if ( anchor == null || anchor.isNull )
            throw new Error( "No valid anchor view to execute PixelMath on." );

         if ( !P.executeOn( anchor.mainView ) )
            throw new Error( "PixelMath execution failed." );

         pumpEvents();

         var outWin = ImageWindow.windowById( outId );
         if ( outWin == null || outWin.isNull )
            outWin = ImageWindow.activeWindow;

         if ( outWin == null || outWin.isNull )
            throw new Error( "PixelMath output image not found: " + outId );

         try { renameMainViewTo( outWin.mainView, outId ); } catch ( __e3 ) {}
         outWin.show();
         ImageWindow.activeWindow = outWin;

         pumpEvents();
         try { applyVisualSTF( outWin.mainView, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, DEFAULT_AUTOSTRETCH_CLINK ); } catch ( __e4 ) {}

         this.appendLog( "PixelMath created: " + outId );
         try { this.state.outputId = outWin.mainView.id; } catch ( __eOut1 ) {}
         return outWin.mainView;
      }
   };



   this.applySPCC = function()
   {
      var finalId = ( this.state.outputId || "RGB" ).trim();

      // PixInsight may auto-suffix new image ids (e.g. RGB_1_1) if the base id already exists.
      // Resolve robustly instead of assuming only RGB / RGB_1.
      var combinedWin = sbppFindWindowByBaseId( finalId );

      // Fallback between RGB and RGB_1 depending on what PixInsight created.
      if ( combinedWin == null || combinedWin.isNull )
      {
         var altId = ( finalId === "RGB" ) ? "RGB_1" : "RGB";
         combinedWin = sbppFindWindowByBaseId( altId );
      }

      if ( combinedWin == null || combinedWin.isNull )
         throw new Error( "Combined image not found for SPCC: " + finalId );

      // Track the actual id we ended up with (could be RGB_1_1, etc.)
      try
      {
         finalId = combinedWin.mainView.id;
         this.state.outputId = finalId;
      }
      catch ( __eId ) {}

      var combinedView = combinedWin.mainView;

      // Ensure combined image has astrometric solution (needed by SPCC). Copy from any source channel if available.
      if ( !combinedWin.hasAstrometricSolution )
      {
         var candidates = [ "Ha", "Sii", "Oiii", "R", "G", "B" ];
         var anchorWin = null;
         for ( var i = 0; i < candidates.length; i++ )
         {
            var w = ImageWindow.windowById( candidates[i] );
            if ( w != null && !w.isNull && w.hasAstrometricSolution )
            {
               anchorWin = w;
               break;
            }
         }

         if ( anchorWin != null )
         {
            if ( copyAstrometricMetadata( anchorWin, combinedWin ) )
               this.appendLog( "Astrometry copied to " + combinedView.fullId + " from " + anchorWin.mainView.fullId );
            else
               this.appendLog( "Warning: Could not copy astrometric solution to " + combinedView.fullId );
         }
         else
         {
            this.appendLog( "Warning: No source image with astrometric solution found to copy to " + combinedView.fullId );
         }
      }

      var spcc = new SpectrophotometricColorCalibration;

      spcc.catalogId = "GaiaDR3SP";
      spcc.autoLimitMagnitude = true;
      spcc.targetSourceCount = 8000;
      spcc.saturationThreshold = 0.75;
      spcc.saturationRelative = true;
      spcc.neutralizeBackground = true;
      spcc.backgroundLow = -2.80;
      spcc.backgroundHigh = 2.00;

      // Background ROI for SPCC (50x50) (no previews). Coordinates are derived from a background patch finder.
      var bg = findBackgroundROI50( combinedView.fullId );
      // NOTE: PixInsight uses (x,y) naming but historical SBPP code maps X to rows (top) and Y to columns (left).
      // Keep the exact mapping used in the legacy script:
      //   backgroundROIX0 = top
      //   backgroundROIY0 = left
      //   backgroundROIX1 = top + height
      //   backgroundROIY1 = left + width
      spcc.backgroundROIX0 = bg.top;
      spcc.backgroundROIY0 = bg.left;
      spcc.backgroundROIX1 = bg.top + bg.height;
      spcc.backgroundROIY1 = bg.left + bg.width;
      this.appendLog(
         "SPCC background ROI: top=" + bg.top +
         ", left=" + bg.left +
         ", bottom=" + ( bg.top + bg.height ) +
         ", right=" + ( bg.left + bg.width )
      );





      spcc.deviceQECurve = "402,0.7219,404,0.7367,406,0.75,408,0.7618,410,0.7751,412,0.787,414,0.7944,416,0.8018,418,0.8112,420,0.8214,422,0.8343,424,0.8462,426,0.8536,428,0.8595,430,0.8639,432,0.8713,434,0.8757,436,0.8802,438,0.8861,440,0.8905,442,0.895,444,0.8994,446,0.9038,448,0.9068,450,0.9112,452,0.9142,454,0.9172,456,0.9168,458,0.9151,460,0.9134,462,0.9117,464,0.91,466,0.9083,468,0.9066,470,0.9049,472,0.9032,474,0.9015,476,0.8997,478,0.898,480,0.8963,482,0.8946,484,0.8929,486,0.8912,488,0.8876,490,0.8846,492,0.8877,494,0.8904,496,0.893,498,0.8964,500,0.8964,502,0.895,504,0.8945,506,0.8922,508,0.8899,510,0.8876,512,0.8853,514,0.883,516,0.8807,518,0.8784,520,0.8761,522,0.8743,524,0.8728,526,0.8698,528,0.8669,530,0.8624,532,0.858,534,0.855,536,0.8506,538,0.8476,540,0.8432,542,0.8402,544,0.8358,546,0.8328,548,0.8284,550,0.8254,552,0.821,554,0.8166,556,0.8136,558,0.8092,560,0.8062,562,0.8023,564,0.7983,566,0.7944,568,0.7899,570,0.787,572,0.7825,574,0.7781,576,0.7751,578,0.7707,580,0.7663,582,0.7618,584,0.7559,586,0.75,588,0.7441,590,0.7396,592,0.7337,594,0.7278,596,0.7219,598,0.716,600,0.7101,602,0.7056,604,0.6997,606,0.695,608,0.6905,610,0.6852,612,0.6808,614,0.6763,616,0.6719,618,0.6675,620,0.663,622,0.6583,624,0.6553,626,0.6509,628,0.6464,630,0.642,632,0.6376,634,0.6317,636,0.6272,638,0.6213,640,0.6154,642,0.6109,644,0.6036,646,0.5962,648,0.5902,650,0.5843,652,0.5799,654,0.574,656,0.5695,658,0.5636,660,0.5592,662,0.5545,664,0.5504,666,0.5462,668,0.542,670,0.5378,672,0.5328,674,0.5286,676,0.5244,678,0.5203,680,0.5163,682,0.5133,684,0.5089,686,0.5044,688,0.4985,690,0.4926,692,0.4867,694,0.4793,696,0.4719,698,0.4645,700,0.4586,702,0.4541,704,0.4497,706,0.4453,708,0.4408,710,0.4364,712,0.432,714,0.4275,716,0.4216,718,0.4186,720,0.4142,722,0.4127,724,0.4103,726,0.4078,728,0.4053,730,0.4024,732,0.3979,734,0.3935,736,0.3891,738,0.3831,740,0.3802,742,0.3772,744,0.3743,746,0.3713,748,0.3669,750,0.3624,752,0.3595,754,0.3559,756,0.3526,758,0.3494,760,0.3462,762,0.3429,764,0.3397,766,0.3364,768,0.3332,770,0.33,772,0.3267,774,0.3235,776,0.3203,778,0.317,780,0.3138,782,0.3106,784,0.3073,786,0.3041,788,0.3009,790,0.2976,792,0.2937,794,0.2905,796,0.2873,798,0.284,800,0.2808,802,0.2776,804,0.2743,806,0.2731,808,0.2703,810,0.2674,812,0.2646,814,0.2618,816,0.2589,818,0.2561,820,0.2533,822,0.2504,824,0.2476,826,0.2456,828,0.2439,830,0.2433,832,0.2427,834,0.2421,836,0.2416,838,0.2411,840,0.2382,842,0.2322,844,0.2278,846,0.2219,848,0.2175,850,0.2114,852,0.2069,854,0.2023,856,0.1978,858,0.1932,860,0.1918,862,0.1911,864,0.1904,866,0.1897,868,0.189,870,0.1883,872,0.1879,874,0.1834,876,0.179,878,0.1731,880,0.1672,882,0.1612,884,0.1568,886,0.1524,888,0.1479,890,0.1464,892,0.1464,894,0.1464,896,0.1464,898,0.1481,900,0.1494,902,0.1494,904,0.1494,906,0.1464,908,0.1435,910,0.1391,912,0.1346,914,0.1302,916,0.1257,918,0.1228,920,0.1183,922,0.1139,924,0.1109,926,0.1093,928,0.1085,930,0.108,932,0.108,934,0.108,936,0.108,938,0.108,940,0.1058,942,0.1039,944,0.1021,946,0.0998,948,0.0958,950,0.0918,952,0.0888,954,0.0828,956,0.0769,958,0.074,960,0.0714,962,0.0695,964,0.0677,966,0.0658,968,0.0651,970,0.0636,972,0.0626,974,0.0616,976,0.0606,978,0.0596,980,0.0586,982,0.0576,984,0.0567,986,0.0557,988,0.0547,990,0.0537,992,0.0527,994,0.0517,996,0.0507";

      if ( this.state.mode === "Narrowband" )
      {
         this.appendLog( "Mode: SHO (Narrowband Settings)" );
         spcc.narrowbandMode = true;
         spcc.narrowbandOptimizeStars = true;
         spcc.generateGraphs = false;

         spcc.whiteReferenceSpectrum = "1,1.0,500,1.0,1000,1.0,1500,1.0,2000,1.0,2500,1.0";
         spcc.whiteReferenceName = "Photon Flux";

         spcc.redFilterWavelength = 673.1;
         spcc.redFilterBandwidth = 3.0;
         spcc.greenFilterWavelength = 656.3;
         spcc.greenFilterBandwidth = 3.0;
         spcc.blueFilterWavelength = 500.7;
         spcc.blueFilterBandwidth = 3.0;
      }
      else
      {
         this.appendLog( "Mode: RGB (Broadband Settings)" );
         spcc.narrowbandMode = false;
         spcc.narrowbandOptimizeStars = false;
         spcc.generateGraphs = false;

         spcc.whiteReferenceSpectrum = "200.5,0.0715066,201.5,0.0689827,202.5,0.0720216,203.5,0.0685511,204.5,0.0712370,205.5,0.0680646,206.5,0.0683024,207.4,0.0729174,207.8,0.0702124,208.5,0.0727025,209.5,0.0688880,210.5,0.0690528,211.5,0.0697566,212.5,0.0705508,213.5,0.0654581,214.5,0.0676317,215.5,0.0699038,216.5,0.0674922,217.5,0.0668344,218.5,0.0661763,219.5,0.0690803,220.5,0.0670864,221.5,0.0635644,222.5,0.0619833,223.5,0.0668687,224.5,0.0640725,225.5,0.0614358,226.5,0.0628698,227.5,0.0649014,228.5,0.0673391,229.5,0.0638038,230.5,0.0643234,231.5,0.0614849,232.5,0.0493110,233.5,0.0574873,234.5,0.0555616,235.5,0.0609369,236.5,0.0557384,237.5,0.0578991,238.5,0.0536321,239.5,0.0575370,240.5,0.0555389,241.5,0.0571506,242.5,0.0615309,243.5,0.0595363,244.5,0.0634798,245.5,0.0628886,246.5,0.0622975,247.5,0.0600475,248.5,0.0608933,249.5,0.0580972,250.5,0.0653082,251.3,0.0576207,251.8,0.0588533,252.5,0.0566401,253.5,0.0582714,254.5,0.0575809,255.5,0.0633762,256.5,0.0610093,257.5,0.0652874,258.5,0.0642648,259.5,0.0632596,260.5,0.0609384,261.5,0.0600490,262.5,0.0636409,263.5,0.0682040,264.5,0.0754600,265.5,0.0806341,266.5,0.0699754,267.5,0.0739405,268.5,0.0755243,269.5,0.0697483,270.5,0.0736132,271.5,0.0678854,272.5,0.0663086,273.5,0.0709825,274.5,0.0602999,275.5,0.0630128,276.5,0.0669431,277.5,0.0701399,278.5,0.0641577,279.5,0.0511231,280.5,0.0550197,281.5,0.0692974,282.5,0.0753517,283.5,0.0723537,284.5,0.0679725,285.5,0.0634174,286.5,0.0742486,287.5,0.0783316,288.5,0.0771108,289.5,0.0801337,291,0.0914252,293,0.0862422,295,0.0838485,297,0.0858467,299,0.0865643,301,0.0875161,303,0.0893837,305,0.0905257,307,0.0935800,309,0.0934870,311,0.0982195,313,0.0953176,315,0.0961554,317,0.0995933,319,0.0924967,321,0.0978345,323,0.0907337,325,0.1054383,327,0.1143168,329,0.1135342,331,0.1106139,333,0.1119505,335,0.1099062,337,0.0967928,339,0.1022504,341,0.1039447,343,0.1063681,345,0.1091599,347,0.1109753,349,0.1181664,351,0.1232860,353,0.1163073,355,0.1267769,357,0.1035215,359,0.1042786,361,0.1176823,363,0.1219479,364,0.1250342,365,0.1363934,367,0.1407033,369,0.1288466,371,0.1379791,373,0.1127623,375,0.1318217,377,0.1528880,379,0.1670432,381,0.1727864,383,0.1243124,385,0.1639393,387,0.1724457,389,0.1520460,391,0.2043430,393,0.1427526,395,0.1870668,397,0.1244026,399,0.2329267,401,0.2556144,403,0.2542109,405,0.2491356,407,0.2379803,409,0.2541684,411,0.2279309,413,0.2533629,415,0.2557223,417,0.2584198,419,0.2560216,421,0.2587210,423,0.2498130,425,0.2609755,427,0.2495886,429,0.2412927,431,0.2182856,433,0.2579985,435,0.2483036,437,0.2928112,439,0.2713431,441,0.2828921,443,0.2975108,445,0.3012513,447,0.3161393,449,0.3221464,451,0.3585586,453,0.3219299,455,0.3334392,457,0.3568741,459,0.3412296,461,0.3498501,463,0.3424920,465,0.3478877,467,0.3611478,469,0.3560448,471,0.3456585,473,0.3587672,475,0.3690553,477,0.3657369,479,0.3671625,481,0.3666357,483,0.3761265,485,0.3466382,487,0.3121751,489,0.3651561,491,0.3688824,493,0.3627420,495,0.3786295,497,0.3733906,499,0.3510300,501,0.3338136,503,0.3540298,505,0.3527861,507,0.3680833,509,0.3507047,511,0.3597249,513,0.3486136,515,0.3372089,517,0.3152444,519,0.3257755,521,0.3499922,523,0.3744245,525,0.3907778,527,0.3490228,529,0.3972061,531,0.4203442,533,0.3740999,535,0.4084084,537,0.4070036,539,0.3993480,541,0.3942389,543,0.4010466,545,0.4128880,547,0.4055525,549,0.4094232,551,0.4053814,553,0.4201633,555,0.4269231,557,0.4193749,559,0.4105311,561,0.4257824,563,0.4239540,565,0.4310873,567,0.4218358,569,0.4360353,571,0.4229342,573,0.4583894,575,0.4425389,577,0.4481210,579,0.4320856,581,0.4507180,583,0.4645862,585,0.4513373,587,0.4516404,589,0.4033701,591,0.4466167,593,0.4513267,595,0.4524209,597,0.4613319,599,0.4546841,601,0.4499895,603,0.4631190,605,0.4724762,607,0.4724962,609,0.4569794,611,0.4599737,613,0.4363290,615,0.4488329,617,0.4267759,619,0.4545143,621,0.4514890,623,0.4384229,625,0.4256613,627,0.4470943,629,0.4565981,631,0.4458333,633,0.4533333,635,0.4546457,637,0.4535446,639,0.4638791,641,0.4561002,643,0.4617287,645,0.4594083,647,0.4597119,649,0.4517238,651,0.4686735,653,0.4686423,655,0.4544898,657,0.4255737,659,0.4640177,661,0.4711876,663,0.4679153,665,0.4689913,667,0.4592265,669,0.4668144,671,0.4498947,673,0.4629239,675,0.4559567,677,0.4596584,679,0.4549789,681,0.4586439,683,0.4653622,685,0.4543475,687,0.4632128,689,0.4711164,691,0.4709973,693,0.4685415,695,0.4696455,697,0.4769241,699,0.4760169,701,0.4701294,703,0.4815669,705,0.4850302,707,0.4707895,709,0.4570604,711,0.4465777,713,0.4382957,715,0.4379654,717,0.4446168,719,0.4350767,721,0.4466714,723,0.4579113,725,0.4625222,727,0.4669903,729,0.4615551,731,0.4763299,733,0.4793147,735,0.4857778,737,0.4997366,739,0.4915129,741,0.4926212,743,0.5062475,745,0.5072637,747,0.5170334,749,0.5173594,751,0.5244106,753,0.5344788,755,0.5397524,757,0.5387203,759,0.5280215,761,0.5191969,763,0.5085395,765,0.4984095,767,0.4749347,769,0.4878839,771,0.4798119,773,0.4821991,775,0.4799906,777,0.4870453,779,0.4928744,781,0.4934236,783,0.4904677,785,0.4849491,787,0.4947343,789,0.4890020,791,0.4789132,793,0.4822390,795,0.4795733,797,0.4973323,799,0.4988779,801,0.5054210,803,0.5087054,805,0.5103235,807,0.5187602,809,0.5151330,811,0.5223530,813,0.5396030,815,0.5475528,817,0.5543915,819,0.5380259,821,0.5321401,823,0.5366753,825,0.5372011,827,0.5440262,829,0.5390591,831,0.5212784,833,0.5187033,835,0.5197124,837,0.5241092,839,0.5070799,841,0.5253056,843,0.5003658,845,0.4896143,847,0.4910508,849,0.4964088,851,0.4753377,853,0.4986498,855,0.4604553,857,0.5174022,859,0.5105171,861,0.5175606,863,0.5322153,865,0.5335880,867,0.4811849,869,0.5241390,871,0.5458069,873,0.5508025,875,0.5423946,877,0.5580108,879,0.5677047,881,0.5580099,883,0.5649928,885,0.5629494,887,0.5384574,889,0.5523318,891,0.5614248,893,0.5521309,895,0.5550786,897,0.5583751,899,0.5597844,901,0.5394855,903,0.5638478,905,0.5862635,907,0.5877920,909,0.5774965,911,0.5866240,913,0.5989106,915,0.5958623,917,0.5964975,919,0.6041389,921,0.5797449,923,0.5607401,925,0.5640816,927,0.5704267,929,0.5642119,931,0.5694372,933,0.5716141,935,0.5705180,937,0.5618458,939,0.5736730,941,0.5630236,943,0.5796418,945,0.5720721,947,0.5873186,949,0.5896322,951,0.5794164,953,0.5828271,955,0.5692468,957,0.5808756,959,0.5949017,961,0.5875516,963,0.5923656,965,0.5824188,967,0.5838008,969,0.5948942,971,0.5865689,973,0.5818128,975,0.5807992,977,0.5851036,979,0.5775164,981,0.5938626,983,0.5885816,985,0.5943664,987,0.5911885,989,0.5916490,991,0.5868101,993,0.5919505,995,0.5945270,997,0.5960248,999,0.5950870,1003,0.5948938,1007,0.5888742,1013,0.6006343,1017,0.5958836,1022,0.6004154,1028,0.6050616,1032,0.5995678,1038,0.5984462,1043,0.6035475,1048,0.5973678,1052,0.5940806,1058,0.5854267,1063,0.5827191,1068,0.5788137,1072,0.5843356,1078,0.5830553,1082,0.5762549,1087,0.5766769,1092,0.5759526,1098,0.5726978,1102,0.5718654,1108,0.5658845,1113,0.5661672,1117,0.5637793,1122,0.5660178,1128,0.5608876,1133,0.5622964,1138,0.5603359,1143,0.5563605,1147,0.5652205,1153,0.5656560,1157,0.5607483,1162,0.5540304,1167,0.5556068,1173,0.5604768,1177,0.5492890,1183,0.5464411,1187,0.5385652,1192,0.5489344,1198,0.5331419,1203,0.5451093,1207,0.5419047,1212,0.5443417,1218,0.5477119,1223,0.5460783,1227,0.5435469,1232,0.5413216,1237,0.5419156,1243,0.5360791,1248,0.5363784,1253,0.5330056,1258,0.5330475,1262,0.5312735,1267,0.5282075,1272,0.5301258,1278,0.5318302,1283,0.5143390,1288,0.5259125,1292,0.5214670,1298,0.5287547,1302,0.5231621,1308,0.5267800,1313,0.5167545,1318,0.5170787,1323,0.5186867,1328,0.5111090,1332,0.5122823,1338,0.5085013,1343,0.5118057,1347,0.5086671,1352,0.5063367,1357,0.5007655,1363,0.5001648,1367,0.5036531,1373,0.5066053,1377,0.5064235,1382,0.5083958,1388,0.5053201,1393,0.4855558,1397,0.4835752,1402,0.4799809,1408,0.4854351,1412,0.4802711,1418,0.4867642,1423,0.4831264,1428,0.4768633,1433,0.4864127,1438,0.4916220,1442,0.4807589,1448,0.4908799,1452,0.4878666,1457,0.4919060,1462,0.4832121,1467,0.4817380,1472,0.4788120,1477,0.4832511,1483,0.4873623,1488,0.4833546,1492,0.4970729,1498,0.4941945,1503,0.4882672,1507,0.4906435,1512,0.5011545,1517,0.5042579,1522,0.5053326,1528,0.5103188,1533,0.5104235,1537,0.5109443,1543,0.5088747,1548,0.5114602,1552,0.5078479,1557,0.4955375,1562,0.5020681,1567,0.5009384,1572,0.5130484,1578,0.4843262,1583,0.4878957,1587,0.4869790,1593,0.5039261,1598,0.4961504,1605,0.5016433,1615,0.5109383,1625,0.5010374,1635,0.5166810,1645,0.4997573,1655,0.5132085,1665,0.5045445,1675,0.5038381,1685,0.4979366,1695,0.5024966,1705,0.4946397,1715,0.4900714,1725,0.4820987,1735,0.4704836,1745,0.4675962,1755,0.4610580,1765,0.4542064,1775,0.4442880,1785,0.4394009,1795,0.4305704,1805,0.4214249,1815,0.4154385,1825,0.4121445,1835,0.4087068,1845,0.4004347,1855,0.3981439,1865,0.3898276,1875,0.3819086,1885,0.3837946,1895,0.3719080,1905,0.3783857,1915,0.3734775,1925,0.3706359,1935,0.3625896,1945,0.3552610,1955,0.3559292,1965,0.3516581,1975,0.3442642,1985,0.3424439,1995,0.3401458,2005,0.3400624,2015,0.3370426,2025,0.3310865,2035,0.3294150,2045,0.3300824,2055,0.3263510,2065,0.3238343,2075,0.3226433,2085,0.3196882,2095,0.3156795,2105,0.3170735,2115,0.3129192,2125,0.3107151,2135,0.3111934,2145,0.3083829,2155,0.3053164,2165,0.3011248,2175,0.2987932,2185,0.2973707,2195,0.2953015,2205,0.2894185,2215,0.2910636,2225,0.2855524,2235,0.2835412,2245,0.2813240,2255,0.2794243,2265,0.2746838,2275,0.2752567,2285,0.2700351,2295,0.2315953,2305,0.2464873,2315,0.2460988,2325,0.2138361,2335,0.2290047,2345,0.2216595,2355,0.1997312,2365,0.2151513,2375,0.2079374,2385,0.1903472,2395,0.2020694,2405,0.1988067,2415,0.1834113,2425,0.1912983,2435,0.1873909,2445,0.1783537,2455,0.1759682,2465,0.1784857,2475,0.1715942,2485,0.1573562,2495,0.1568707,2505,0.1598265";
         spcc.whiteReferenceName = "Average Spiral Galaxy";

         spcc.redFilterWavelength = 656.3;
         spcc.redFilterBandwidth = 3.0;
         spcc.greenFilterWavelength = 500.7;
         spcc.greenFilterBandwidth = 3.0;
         spcc.blueFilterWavelength = 500.7;
         spcc.blueFilterBandwidth = 3.0;

         spcc.broadbandIntegrationStepSize = 0.50;
      }

      spcc.redFilterTrCurve = "400,0.088,402,0.084,404,0.080,406,0.076,408,0.072,410,0.068,412,0.065,414,0.061,416,0.058,418,0.055,420,0.052,422,0.049,424,0.046,426,0.044,428,0.041,430,0.039,432,0.037,434,0.035,436,0.033,438,0.031,440,0.030,442,0.028,444,0.027,446,0.026,448,0.025,450,0.024,452,0.023,454,0.022,456,0.021,458,0.021,460,0.021,462,0.020,464,0.020,466,0.020,468,0.020,470,0.020,472,0.021,474,0.021,476,0.022,478,0.022,480,0.023,482,0.024,484,0.025,486,0.026,488,0.027,490,0.028,492,0.029,494,0.031,496,0.032,498,0.034,500,0.036,502,0.037,504,0.039,506,0.041,508,0.043,510,0.045,512,0.048,514,0.050,516,0.052,518,0.055,520,0.057,522,0.060,524,0.063,526,0.071,528,0.072,530,0.070,532,0.067,534,0.064,536,0.059,538,0.054,540,0.050,542,0.045,544,0.041,546,0.037,548,0.034,550,0.032,552,0.031,554,0.031,556,0.032,558,0.035,560,0.038,562,0.043,564,0.048,566,0.055,568,0.062,570,0.070,572,0.122,574,0.187,576,0.262,578,0.346,580,0.433,582,0.521,584,0.606,586,0.686,588,0.755,590,0.812,592,0.851,594,0.871,596,0.876,598,0.885,600,0.892,602,0.896,604,0.897,606,0.897,608,0.895,610,0.891,612,0.887,614,0.882,616,0.878,618,0.873,620,0.870,622,0.867,624,0.863,626,0.860,628,0.858,630,0.856,632,0.854,634,0.852,636,0.850,638,0.848,640,0.846,642,0.844,644,0.841,646,0.837,648,0.834,650,0.829,652,0.824,654,0.819,656,0.813,658,0.806,660,0.799,662,0.791,664,0.783,666,0.774,668,0.765,670,0.755,672,0.745,674,0.735,676,0.725,678,0.715,680,0.704,682,0.695,684,0.685,686,0.676,688,0.668,690,0.660,692,0.654,694,0.649,696,0.648,698,0.649,700,0.649";
      spcc.greenFilterTrCurve = "400,0.089,402,0.086,404,0.082,406,0.079,408,0.075,410,0.071,412,0.066,414,0.062,416,0.058,418,0.053,420,0.049,422,0.045,424,0.042,426,0.041,428,0.042,430,0.043,432,0.044,434,0.046,436,0.047,438,0.049,440,0.051,442,0.053,444,0.055,446,0.057,448,0.059,450,0.061,452,0.064,454,0.067,456,0.069,458,0.072,460,0.075,462,0.098,464,0.130,466,0.169,468,0.215,470,0.267,472,0.323,474,0.382,476,0.443,478,0.505,480,0.566,482,0.627,484,0.684,486,0.739,488,0.788,490,0.832,492,0.868,494,0.896,496,0.915,498,0.924,500,0.921,502,0.939,504,0.947,506,0.954,508,0.961,510,0.967,512,0.973,514,0.978,516,0.982,518,0.986,520,0.989,522,0.992,524,0.994,526,0.996,528,0.997,530,0.997,532,0.995,534,0.990,536,0.986,538,0.981,540,0.977,542,0.973,544,0.969,546,0.965,548,0.960,550,0.955,552,0.949,554,0.943,556,0.936,558,0.928,560,0.919,562,0.909,564,0.898,566,0.887,568,0.874,570,0.860,572,0.845,574,0.829,576,0.812,578,0.794,580,0.775,582,0.754,584,0.733,586,0.711,588,0.688,590,0.665,592,0.640,594,0.615,596,0.589,598,0.563,600,0.537,602,0.510,604,0.483,606,0.456,608,0.430,610,0.403,612,0.377,614,0.352,616,0.328,618,0.304,620,0.282,622,0.261,624,0.242,626,0.224,628,0.225,630,0.216,632,0.207,634,0.199,636,0.192,638,0.185,640,0.179,642,0.174,644,0.169,646,0.165,648,0.161,650,0.158,652,0.156,654,0.155,656,0.154,658,0.154,660,0.155,662,0.156,664,0.158,666,0.162,668,0.165,670,0.170,672,0.176,674,0.182,676,0.189,678,0.198,680,0.207,682,0.217,684,0.228,686,0.240,688,0.240,690,0.248,692,0.257,694,0.265,696,0.274,698,0.282,700,0.289";
      spcc.blueFilterTrCurve = "400,0.438,402,0.469,404,0.496,406,0.519,408,0.539,410,0.557,412,0.572,414,0.586,416,0.599,418,0.614,420,0.631,422,0.637,424,0.647,426,0.658,428,0.670,430,0.682,432,0.695,434,0.708,436,0.720,438,0.732,440,0.743,442,0.753,444,0.762,446,0.770,448,0.777,450,0.783,452,0.788,454,0.791,456,0.794,458,0.796,460,0.797,462,0.798,464,0.798,466,0.799,468,0.800,470,0.801,472,0.800,474,0.798,476,0.793,478,0.785,480,0.774,482,0.760,484,0.742,486,0.707,488,0.669,490,0.633,492,0.598,494,0.565,496,0.533,498,0.502,500,0.473,502,0.446,504,0.419,506,0.394,508,0.370,510,0.348,512,0.326,514,0.306,516,0.287,518,0.268,520,0.251,522,0.235,524,0.220,526,0.205,528,0.192,530,0.179,532,0.167,534,0.156,536,0.145,538,0.136,540,0.126,542,0.118,544,0.110,546,0.102,548,0.095,550,0.089,552,0.083,554,0.077,556,0.071,558,0.066,560,0.061,562,0.057,564,0.052,566,0.048,568,0.044,570,0.039,572,0.041,574,0.039,576,0.037,578,0.035,580,0.033,582,0.032,584,0.030,586,0.029,588,0.027,590,0.026,592,0.025,594,0.024,596,0.023,598,0.022,600,0.022,602,0.021,604,0.021,606,0.020,608,0.020,610,0.020,612,0.020,614,0.020,616,0.020,618,0.021,620,0.021,622,0.022,624,0.022,626,0.023,628,0.024,630,0.025,632,0.026,634,0.027,636,0.028,638,0.030,640,0.031,642,0.033,644,0.035,646,0.036,648,0.038,650,0.040,652,0.042,654,0.045,656,0.048,658,0.051,660,0.054,662,0.057,664,0.059,666,0.061,668,0.063,670,0.065,672,0.066,674,0.068,676,0.069,678,0.070,680,0.071,682,0.072,684,0.072,686,0.073,688,0.073,690,0.073,692,0.073,694,0.073,696,0.073,698,0.073,700,0.073";

      this.appendLog( "Executing SPCC on " + combinedView.fullId );
      if ( !spcc.executeOn( combinedView ) )
         throw new Error( "SPCC failed." );

      pumpEvents();

      try { applyVisualSTF( combinedView, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, true ); } catch ( __e1 ) {}

      try { combinedWin.show(); ImageWindow.activeWindow = combinedWin; combinedWin.bringToFront(); } catch ( __e1b ) {}
   }

   // ---- Linear tuning processes (ported from Baseline UI.js) ----
   // These are intended to run immediately after SPCC on the just color-corrected image.
   this.applyNXT = function()
   {
      // Operate on the currently active (post-SPCC) image.
      var w = ImageWindow.activeWindow;
      if ( w == null || w.isNull )
         throw new Error( "NXT: No active image window." );

      var v = w.mainView;

      // Read tuning controls
      var den = 0.50;
      var it  = 1;
      try { den = Number( this.ltDenoise.value ); } catch ( __e0 ) {}
      try { it  = Math.round( Number( this.ltIterations.value ) ); } catch ( __e1 ) {}

      if ( !isFinite( den ) ) den = 0.50;
      den = Math.range( den, 0.0, 1.0 );

      if ( !isFinite( it ) ) it = 1;
      it = Math.range( it, 1, 5 );

      var nxt = new NoiseXTerminator;
      nxt.ai_file = sbppPickAIFile( "NoiseXTerminator.3.pb" );
      nxt.enable_color_separation = false;
      nxt.enable_frequency_separation = false;
      nxt.denoise = den;
      nxt.iterations = it;

      this.appendLog( "Applying NXT (linear) to: " + v.fullId + " (denoise=" + den.toFixed( 2 ) + ", iterations=" + it + ")" );
      if ( !nxt.executeOn( v ) )
         throw new Error( "NXT failed." );

      pumpEvents();

      // Rename for deterministic downstream steps
      var baseId = w.mainView.id;
      var outId = baseId + "_NXT";
      try { renameMainViewTo( v, outId ); } catch ( __e2 ) {}

      try { applyVisualSTF( v, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, true ); } catch ( __e3 ) {}
      this.appendLog( "NXT completed. Current view: " + v.fullId );
   };


   this.applyBXT = function()
   {
      var w = ImageWindow.activeWindow;
      if ( w == null || w.isNull )
         throw new Error( "BXT: No active image window." );

      var v = w.mainView;

      var ss = 0.50;
      var sn = 0.50;
      var ah = -0.10;

      try { ss = Number( this.ltSharpenStars.text ); } catch ( __e0 ) {}
      try { sn = Number( this.ltSharpenNonstellar.text ); } catch ( __e1 ) {}
      try { ah = Number( this.ltAdjustStarHalos.text ); } catch ( __e2 ) {}

      if ( !isFinite( ss ) ) ss = 0.50;
      if ( !isFinite( sn ) ) sn = 0.50;
      if ( !isFinite( ah ) ) ah = -0.10;

      ss = Math.range( ss, 0.0, 0.7 );
      sn = Math.range( sn, 0.0, 1.0 );
      ah = Math.range( ah, -0.5, 0.5 );

      var bxt = new BlurXTerminator;
      bxt.ai_file = sbppPickAIFile( "BlurXTerminator.4.pb" );
      bxt.correct_only = false;
      bxt.correct_first = false;
      bxt.nonstellar_then_stellar = false;
      bxt.lum_only = false;

      bxt.sharpen_stars = ss;
      bxt.adjust_halos = ah;

      bxt.nonstellar_psf_diameter = 0.00;
      bxt.auto_nonstellar_psf = true;
      bxt.sharpen_nonstellar = sn;

      this.appendLog(
         "Applying BXT (linear) to: " + v.fullId +
         " (stars=" + ss.toFixed( 2 ) +
         ", halos=" + ah.toFixed( 2 ) +
         ", nonstellar=" + sn.toFixed( 2 ) + ")"
      );

      if ( !bxt.executeOn( v ) )
         throw new Error( "BXT failed." );

      pumpEvents();

      var baseId = w.mainView.id;
      var outId = baseId + "_BXT";
      try { renameMainViewTo( v, outId ); } catch ( __e3 ) {}

      try { applyVisualSTF( v, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, true ); } catch ( __e4 ) {}
      this.appendLog( "BXT completed. Current view: " + v.fullId );
   };


   this.applySXT = function()
   {
      var w = ImageWindow.activeWindow;
      if ( w == null || w.isNull )
         throw new Error( "SXT: No active image window." );

      var v = w.mainView;

      var genStars = true;
      var unscreen = true;
      var overlap = 0.50;

      try { genStars = !!this.ltGenStarImage.checked; } catch ( __e0 ) {}
      try { unscreen = !!this.ltUnscreenStars.checked; } catch ( __e1 ) {}
      try { overlap = ( this.ltLargeOverlap && this.ltLargeOverlap.checked ) ? 0.50 : 0.20; } catch ( __e2 ) { overlap = 0.50; }

      var sxt = new StarXTerminator;
      sxt.ai_file = sbppPickAIFile( "StarXTerminator.lite.nonoise.11.pb" );
      sxt.stars = genStars;
      sxt.unscreen = unscreen;
      sxt.overlap = overlap;

      this.appendLog( "Separating stars (linear) from: " + v.fullId + " (stars=" + genStars + ", unscreen=" + unscreen + ", overlap=" + overlap.toFixed( 2 ) + ")" );

      if ( !sxt.executeOn( v ) )
         throw new Error( "SXT failed." );

      pumpEvents();

      // Starless is the modified target view
      var starlessId = "starless_linear";
      try { renameMainViewTo( v, starlessId ); } catch ( __e3 ) {}

      // Stars window can be "Stars" or similar. Use legacy discovery logic.
      if ( genStars )
      {
         var starsWin = ImageWindow.windowById( "Stars" );
         if ( starsWin == null || starsWin.isNull )
         {
            var allWins = ImageWindow.windows;
            for ( var i = 0; i < allWins.length; ++i )
            {
               var wid = allWins[i].mainView.id;
               var low = wid.toLowerCase();
               if ( low.indexOf( "stars" ) >= 0 && low.indexOf( "starless_linear" ) < 0 )
               {
                  starsWin = allWins[i];
                  break;
               }
            }
         }

         if ( starsWin != null && !starsWin.isNull )
         {
            try { renameMainViewTo( starsWin.mainView, "stars_linear" ); } catch ( __e4 ) {}
            // IMPORTANT: Do NOT apply a visual STF to the extracted stars image.
            // The stars view must remain without a visual stretch (by design).
            this.appendLog( "SXT: leaving stars_linear without visual STF." );
         }
         else
         {
            this.appendLog( "Warning: SXT stars image not found to rename." );
         }
      }

      try { applyVisualSTF( v, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, true ); } catch ( __e6 ) {}
      this.appendLog( "SXT completed. Current views: " + starlessId + ( genStars ? " + stars_linear" : "" ) );
   };


this.applyStretching = function()
{
      // Track stretched starless outputs produced in this run
      this.__stretchedTargets = [];

   // Creates new stretched images from starless_linear (non-destructive).
   var srcWin = ImageWindow.windowById( "starless_linear" );
   if ( srcWin == null || srcWin.isNull )
      throw new Error( "Stretching: starless_linear not found. (Did Star Extraction run?)" );

   var srcView = srcWin.mainView;

   function closeIfExists( id )
   {
      try
      {
         var w0 = ImageWindow.windowById( id );
         if ( w0 != null && !w0.isNull )
            w0.forceClose();
      }
      catch ( __e0 ) {}
   }

   // Ensure deterministic output ids (avoid PixInsight auto-suffix like *_1)
   closeIfExists( "starless_HT" );
   closeIfExists( "starless_MAS" );


   function neutralizeSTF( v )
   {
      try
      {
         v.stf = [
            [0.5, 0, 1, 0, 1],
            [0.5, 0, 1, 0, 1],
            [0.5, 0, 1, 0, 1],
            [0.5, 0, 1, 0, 1]
         ];
      }
      catch ( __e0 ) {}
   }

   function cloneWindowFrom( src, newId )
   {
      var w = new ImageWindow(
         src.image.width,
         src.image.height,
         src.image.numberOfChannels,
         src.window.bitsPerSample,
         src.window.isFloatSample,
         src.image.isColor,
         newId
      );

      w.mainView.beginProcess();
      w.mainView.image.assign( src.image );
      w.mainView.endProcess();
      w.show();
      pumpEvents();
      return w.mainView;
   }

   var didAny = false;

   // 10.1 HistogramTransformation (STF-like to HT)
   if ( this.htEnable && this.htEnable.checked )
   {
      didAny = true;

      var htId = "starless_HT";
      var htView = cloneWindowFrom( srcView, htId );
      try { this.__stretchedTargets.push( htId ); } catch ( __eT ) {}

      var median = htView.computeOrFetchProperty( "Median" );
      var mad = htView.computeOrFetchProperty( "MAD" );
      mad.mul( 1.4826 );

      var n = htView.image.isColor ? 3 : 1;
      var ht = new HistogramTransformation;

      var avgC0 = 0, avgM = 0;
      for ( var c = 0; c < n; ++c )
      {
         if ( 1 + mad.at( c ) != 1 )
            avgC0 += median.at( c ) + DEFAULT_AUTOSTRETCH_SCLIP * mad.at( c );
         avgM += median.at( c );
      }

      avgC0 = Math.range( avgC0/n, 0.0, 1.0 );

      var htTbgnd = DEFAULT_AUTOSTRETCH_TBGND;
      try
      {
         htTbgnd = Number( this.htTbgnd ? this.htTbgnd.text : DEFAULT_AUTOSTRETCH_TBGND );
         if ( !isFinite( htTbgnd ) ) htTbgnd = DEFAULT_AUTOSTRETCH_TBGND;
         htTbgnd = Math.range( htTbgnd, 0.0, 1.0 );
      }
      catch ( __eHT ) { htTbgnd = DEFAULT_AUTOSTRETCH_TBGND; }

      avgM  = Math.mtf( htTbgnd, avgM/n - avgC0 );

      ht.H = [
         [avgC0, avgM, 1.0, 0.0, 1.0],
         [avgC0, avgM, 1.0, 0.0, 1.0],
         [avgC0, avgM, 1.0, 0.0, 1.0],
         [0, 0.5, 1, 0, 1]
      ];

      this.appendLog( "Stretch (HT) executing on: " + htView.id + " (TBGND=" + format( "%.2f", htTbgnd ) + ")" );

      if ( !ht.executeOn( htView ) )
         throw new Error( "HT stretch failed." );

      neutralizeSTF( htView );
      this.appendLog( "Stretch (HT) completed: " + htView.id );
   }
   else
   {
      this.appendLog( "Stretch (HT) disabled (skipping)." );
   }

   // 10.2 MultiscaleAdaptiveStretch (MAS)
   if ( this.masEnable && this.masEnable.checked )
   {
      didAny = true;

      var masId = "starless_MAS";
      var masView = cloneWindowFrom( srcView, masId );
      try { this.__stretchedTargets.push( masId ); } catch ( __eT2 ) {}
      var P = new MultiscaleAdaptiveStretch;

      // Locate background ROI (50x50) if supported.
      try
      {
         var __bg = findBackground( masView.fullId, 50, 50 );
         P.backgroundROIEnabled = true;
         P.backgroundROIX0 = __bg.left;
         P.backgroundROIY0 = __bg.top;
         P.backgroundROIWidth = 50;
         P.backgroundROIHeight = 50;

         this.appendLog( "MAS background ROI: Left=" + __bg.left + " Top=" + __bg.top + " (50x50)" );
      }
      catch ( __eBG )
      {
         try { P.backgroundROIEnabled = false; } catch ( __eB2 ) {}
         this.appendLog( "Warning: MAS background ROI search failed. Proceeding without ROI. (" + __eBG + ")" );
      }

      // Pull parameters from Stretching tab controls.
      try { P.aggressiveness = Math.range( Number( this.masAggressiveness.value ), 0.0, 1.0 ); } catch ( __eA ) { P.aggressiveness = 0.70; }
      try { P.targetBackground = Math.range( Number( this.masTargetBg.value ), 0.0, 1.0 ); } catch ( __eT ) { P.targetBackground = 0.15; }
      try { P.dynamicRangeCompression = Math.range( Number( this.masDRC.value ), 0.0, 1.0 ); } catch ( __eD ) { P.dynamicRangeCompression = 0.40; }
      try { P.contrastRecovery = !!this.masContrast.checked; } catch ( __eC ) { P.contrastRecovery = true; }

      try
      {
         var msText = String( this.masScaleSep.itemText( this.masScaleSep.currentItem ) );
         var msVal = Number( msText );
         if ( isFinite( msVal ) ) P.scaleSeparation = msVal;
      }
      catch ( __eS ) { P.scaleSeparation = 1024; }

      // MAS v1.1 parameter (0..1)
      try { P.contrastRecoveryIntensity = Math.range( Number( this.masIntensity.value ), 0.0, 1.0 ); } catch ( __eI ) { P.contrastRecoveryIntensity = 0.75; }

      try { P.previewLargeScale = !!this.masPreviewLarge.checked; } catch ( __eP ) { P.previewLargeScale = false; }

      try { P.saturationEnabled = !!this.masSaturationEnable.checked; } catch ( __eSE ) { P.saturationEnabled = false; }
      try { P.saturationAmount = Math.range( Number( this.masSatAmount.value ), 0.0, 1.0 ); } catch ( __eSA ) { P.saturationAmount = 0.70; }
      try { P.saturationBoost = Math.range( Number( this.masSatBoost.value ), 0.0, 1.0 ); } catch ( __eSB ) { P.saturationBoost = 0.50; }
      try { P.saturationLightnessMask = !!this.masSatMask.checked; } catch ( __eSL ) { P.saturationLightnessMask = true; }

      this.appendLog(
         "Stretch (MAS) executing on: " + masView.id +
         " (agg=" + format( "%.2f", P.aggressiveness ) +
         ", tbg=" + format( "%.2f", P.targetBackground ) +
         ", drc=" + format( "%.2f", P.dynamicRangeCompression ) +
         ", scale=" + P.scaleSeparation +
         ", intensity=" + format( "%.2f", P.contrastRecoveryIntensity ) + ")"
      );

      if ( !P.executeOn( masView ) )
         throw new Error( "MAS stretch failed." );

      neutralizeSTF( masView );
      this.appendLog( "Stretch (MAS) completed: " + masView.id );
   }
   else
   {
      this.appendLog( "Stretch (MAS) disabled (skipping)." );
   }

   if ( !didAny )
      this.appendLog( "Stretching skipped (neither HT nor MAS enabled)." );
};

   this.applyNXT_Stchd = function()
   {
      if ( !this.nlNrEnable || !this.nlNrEnable.checked )
      {
         this.appendLog( "Nonlinear NXT disabled (skipping)." );
         return;
      }

      // Determine targets produced in the Stretch step (fallback to existing windows).
      var targets = [];
      try
      {
         if ( this.__stretchedTargets && this.__stretchedTargets.length )
            targets = this.__stretchedTargets.slice( 0 );
      }
      catch ( __eT ) {}

      if ( targets.length < 1 )
      {
         if ( ImageWindow.windowById( "starless_HT" ) ) targets.push( "starless_HT" );
         if ( ImageWindow.windowById( "starless_MAS" ) ) targets.push( "starless_MAS" );
      }

      if ( targets.length < 1 )
      {
         this.appendLog( "Nonlinear NXT: no stretched starless targets found." );
         return;
      }

      var den = 0.30;
      var it  = 1;
      try { den = Number( this.nlNrDenoise.value ); } catch ( __e0 ) {}
      try { it  = Math.round( Number( this.nlNrIterations.value ) ); } catch ( __e1 ) {}

      if ( !isFinite( den ) ) den = 0.30;
      den = Math.range( den, 0.0, 1.0 );

      if ( !isFinite( it ) ) it = 1;
      it = Math.range( it, 1, 5 );

      var nxt = new NoiseXTerminator;
      nxt.ai_file = sbppPickAIFile( "NoiseXTerminator.3.pb" );
      nxt.enable_color_separation = false;
      nxt.enable_frequency_separation = false;
      nxt.denoise = den;
      nxt.iterations = it;

      for ( var i = 0; i < targets.length; ++i )
      {
         this.checkCancel();

         var id = targets[i];
         var w = ImageWindow.windowById( id );
         if ( w == null || w.isNull )
         {
            this.appendLog( "Nonlinear NXT skipped (missing view): " + id );
            continue;
         }

         this.appendLog( "Applying Nonlinear NXT to: " + id + " (denoise=" + den.toFixed( 2 ) + ", it=" + it + ")" );
         if ( !nxt.executeOn( w.mainView ) )
            throw new Error( "Nonlinear NXT failed on: " + id );

         pumpEvents();
      }

      this.appendLog( "Nonlinear NXT completed." );
   };

   this.applyBXT_Stchd = function()
   {
      if ( !this.nlSharpEnable || !this.nlSharpEnable.checked )
      {
         this.appendLog( "Nonlinear BXT disabled (skipping)." );
         return;
      }

      // Determine targets produced in the Stretch step (fallback to existing windows).
      var targets = [];
      try
      {
         if ( this.__stretchedTargets && this.__stretchedTargets.length )
            targets = this.__stretchedTargets.slice( 0 );
      }
      catch ( __eT ) {}

      if ( targets.length < 1 )
      {
         if ( ImageWindow.windowById( "starless_HT" ) ) targets.push( "starless_HT" );
         if ( ImageWindow.windowById( "starless_MAS" ) ) targets.push( "starless_MAS" );
      }

      if ( targets.length < 1 )
      {
         this.appendLog( "Nonlinear BXT: no stretched starless targets found." );
         return;
      }

      var ss = 0.00;
      var ah = 0.00;
      var sn = 0.25;

      try { ss = Number( this.nlSharpenStars.text ); } catch ( __e0 ) {}
      try { ah = Number( this.nlAdjustStarHalos.text ); } catch ( __e1 ) {}
      try { sn = Number( this.nlSharpenNonstellar.text ); } catch ( __e2 ) {}

      if ( !isFinite( ss ) ) ss = 0.00;
      if ( !isFinite( ah ) ) ah = 0.00;
      if ( !isFinite( sn ) ) sn = 0.25;

      ss = Math.range( ss, 0.0, 0.7 );
      ah = Math.range( ah, -0.5, 0.5 );
      sn = Math.range( sn, 0.0, 1.0 );

      var bxt = new BlurXTerminator;
      bxt.ai_file = sbppPickAIFile( "BlurXTerminator.4.pb" );
      bxt.correct_only = false;
      bxt.correct_first = false;
      bxt.nonstellar_then_stellar = false;
      bxt.lum_only = false;

      bxt.sharpen_stars = ss;
      bxt.adjust_halos = ah;

      bxt.nonstellar_psf_diameter = 0.00;
      bxt.auto_nonstellar_psf = true;

      bxt.sharpen_nonstellar = sn;

      for ( var i = 0; i < targets.length; ++i )
      {
         this.checkCancel();

         var id = targets[i];
         var w = ImageWindow.windowById( id );
         if ( w == null || w.isNull )
         {
            this.appendLog( "Nonlinear BXT skipped (missing view): " + id );
            continue;
         }

         this.appendLog( "Applying Nonlinear BXT to: " + id +
                         " (stars=" + ss.toFixed( 2 ) +
                         ", halos=" + ah.toFixed( 2 ) +
                         ", nonstellar=" + sn.toFixed( 2 ) + ")" );

         if ( !bxt.executeOn( w.mainView ) )
            throw new Error( "Nonlinear BXT failed on: " + id );

         pumpEvents();
      }

      this.appendLog( "Nonlinear BXT completed." );
   };



   
   this.applyLumSharpening = function()
   {
                  try { this.appendLog( "applyLumSharpening: entered" ); } catch ( __e0 ) {}

      // Step 13: Lum Sharpening
      // Single-pass iteration over current open images.
      //
      // For each starless (stretched) image:
      //   1) Extract luminance -> <id>_Lum
      //   2) Create working copies from luminance:
      //        <id>_Lum_mask, <id>_Lum_USM, <id>_Lum_MLT
      //
      // Skip:
      //   - starless_linear
      //   - any already-derived products to avoid recursion:
      //       *_Lum, *_Lum_mask, *_Lum_USM, *_Lum_MLT (case-insensitive)

      var wins = [];
      try { wins = ImageWindow.windows; } catch ( __eW0 ) { wins = []; }

      // Snapshot ids first so we don't accidentally iterate over newly created windows.
      var ids = [];
      for ( var i0 = 0; i0 < wins.length; ++i0 )
      {
         try
         {
            var w0 = wins[i0];
            if ( w0 == null || w0.isNull )
               continue;
            var id0 = w0.mainView.id;
            if ( typeof id0 === "string" )
               ids.push( id0 );
         }
         catch ( __eSnap ) {}
      }

      function endsWithCI( s, suf )
      {
         var sl = ( typeof s === "string" ) ? s.toLowerCase() : "";
         var su = suf.toLowerCase();
         return sl.length >= su.length && sl.substring( sl.length - su.length ) === su;
      }

      function existsId( id )
      {
         try
         {
            var w = ImageWindow.windowById( id );
            if ( w == null || w.isNull )
               return false;
            // Strict sanity check
            return ( w.mainView != null && w.mainView.id === id );
         }
         catch ( __eX )
         {
            return false;
         }
      }

      function cloneWindowFrom( srcView, newId )
      {
         var w = new ImageWindow(
            srcView.image.width,
            srcView.image.height,
            srcView.image.numberOfChannels,
            srcView.window.bitsPerSample,
            srcView.window.isFloatSample,
            srcView.image.isColor,
            newId
         );

         w.mainView.beginProcess();
         w.mainView.image.assign( srcView.image );
         w.mainView.endProcess();
         w.show();
         pumpEvents();
         return w;
      }

      var nTargets = 0;

      var __lumSharpen_toClose = [];
      function __ls_pushClose( id )
      {
         try { if ( typeof id === "string" && id.length ) __lumSharpen_toClose.push( id ); } catch ( __e ) {}
      }


      for ( var i = 0; i < ids.length; ++i )
      {
         var id = ids[i];
         try
         {
            if ( typeof id !== "string" )
               continue;

            var idLower = id.toLowerCase();

            if ( idLower.indexOf( "starless" ) < 0 )
               continue;

            if ( idLower === "starless_linear" )
               continue;

            // Skip derived products
            if ( endsWithCI( id, "_Lum" ) || endsWithCI( id, "_Lum_mask" ) || endsWithCI( id, "_Lum_USM" ) || endsWithCI( id, "_Lum_MLT" ) || endsWithCI( id, "_Lum_Sharpener" ) )
               continue;

            ++nTargets;
            try { this.appendLog( "Lum Sharpening: target " + id ); } catch ( __eT0 ) {}

            var lumId = id + "_Lum";
            var maskId = lumId + "_mask";
            var usmId  = lumId + "_USM";
            var mltId  = lumId + "_MLT";


            // 1) Extract luminance (if needed)
            var wLum = ImageWindow.windowById( lumId );
            if ( !existsId( lumId ) )
            {
               try { this.appendLog( "Lum Sharpening: extracting L from " + id ); } catch ( __eL0 ) {}
               var created = null;
               try { created = extractLum( id ); } catch ( __eEx ) { created = null; try { this.appendLog( "Lum Sharpening: extractLum failed for " + id + ": " + __eEx ); } catch ( __eEx2 ) {} }
               pumpEvents();

               // Prefer returned window; fallback to lookup by id
               if ( created != null )
                  wLum = created;
               if ( wLum == null )
                  wLum = ImageWindow.windowById( lumId );
            }
            else
            {
               try { this.appendLog( "Lum Sharpening: " + lumId + " already exists (skipping extraction)." ); } catch ( __eL0b ) {}
               try { wLum = ImageWindow.windowById( lumId ); } catch ( __eL0d ) {}
               try {
                  var _wChk = ImageWindow.windowById( lumId );
                  if ( _wChk != null ) this.appendLog( "Lum Sharpening: existsId check -> " + lumId + " resolves to window mainView.id=" + _wChk.mainView.id );
               } catch ( __eL0c ) {}
            }

            if ( wLum == null )
            {
               try { this.appendLog( "Lum Sharpening: could not resolve " + lumId + " (skipping copies)." ); } catch ( __eL1 ) {}
               continue;
            }

            var vLum = wLum.mainView;

            // 2) Create copies
            if ( !existsId( maskId ) )
            {
               cloneWindowFrom( vLum, maskId );
               try { this.appendLog( "Lum Sharpening: created " + maskId ); } catch ( __eC0 ) {}
               try { clipMask( maskId ); } catch ( __eCM0 ) { try { this.appendLog( "Lum Sharpening: clipMask failed for " + maskId + ": " + __eCM0 ); } catch ( __eCM0b ) {} }
            }

            if ( !existsId( usmId ) )
            {
               cloneWindowFrom( vLum, usmId );
               try { this.appendLog( "Lum Sharpening: created " + usmId ); } catch ( __eC1 ) {}
               try { applyMaskToWindow( usmId, maskId, false );
               try { applyUSM( usmId ); } catch ( __eUSM1 ) { try { this.appendLog( "Lum Sharpening: applyUSM failed for " + usmId + ": " + __eUSM1 ); } catch ( __eUSM1b ) {} } } catch ( __eAM1 ) { try { this.appendLog( "Lum Sharpening: applyMask failed for " + usmId + " using " + maskId + ": " + __eAM1 ); } catch ( __eAM1b ) {} }
            }

            if ( !existsId( mltId ) )
            {
               cloneWindowFrom( vLum, mltId );
               try { this.appendLog( "Lum Sharpening: created " + mltId ); } catch ( __eC2 ) {}
               try { applyMaskToWindow( mltId, maskId, false );
               try { applyMLT( mltId ); } catch ( __eMLT1 ) { try { this.appendLog( "Lum Sharpening: applyMLT failed for " + mltId + ": " + __eMLT1 ); } catch ( __eMLT1b ) {} }
               try {
                  var outId = createLumSharpener( lumId, usmId, mltId );
                  this.appendLog( "Lum Sharpening: created " + outId );

                  // Apply the sharpener as luminance to the target image.
                  try
                  {
                     applyLum( id, outId );
                     this.appendLog( "Lum Sharpening: applied " + outId + " as L to " + id );
                  }
                  catch ( __eAL )
                  {
                     try { this.appendLog( "Lum Sharpening: applyLum failed for " + id + " using " + outId + ": " + __eAL ); } catch ( __eALb ) {}
                  }

                  // Queue intermediates for cleanup after the loop.
                  __ls_pushClose( lumId );
                  __ls_pushClose( maskId );
                  __ls_pushClose( usmId );
                  __ls_pushClose( mltId );
                  __ls_pushClose( outId );

                  pumpEvents();
               } catch ( __ePM ) { try { this.appendLog( "Lum Sharpening: createLumSharpener failed for " + lumId + ": " + __ePM ); } catch ( __ePMb ) {} }
 } catch ( __eAM2 ) { try { this.appendLog( "Lum Sharpening: applyMask failed for " + mltId + " using " + maskId + ": " + __eAM2 ); } catch ( __eAM2b ) {} }
            }
         }
         catch ( __eOne )
         {
            try { this.appendLog( "Lum Sharpening: skipped one target: " + __eOne ); } catch ( __eLx ) {}
         }
      }
      // Cleanup after processing all targets
      try
      {
         for ( var ci = 0; ci < __lumSharpen_toClose.length; ++ci )
         {
            var cid = __lumSharpen_toClose[ci];
            try
            {
               var cw = ImageWindow.windowById( cid );
               if ( cw != null && !cw.isNull )
                  cw.forceClose();
            }
            catch ( __eCw ) {}
            pumpEvents();
         }
      }
      catch ( __eCAll ) {}

      if ( nTargets <= 0 )
         try { this.appendLog( "Lum Sharpening: no eligible starless images found (skipping)." ); } catch ( __eL2 ) {}
   };

// Apply NoiseXTerminator to stretched starless images (in place).

   // Apply BlurXTerminator to stretched starless images (in place).

;

   // ---------------------------
   // Combination: palette + mapping
   // ---------------------------
   this.getPalettesForCurrentState = function()
   {
      if ( this.state.mode === "Broadband" )
         return [ "RGB" ];

      if ( this.state.masters.length === 2 )
         return [ "HOO" ];

      return [ "SHO", "HSO" ];
   };

   this.mappingForPalette = function( palette )
   {
      if ( this.state.mode === "Broadband" )
         return { R:"R", G:"G", B:"B" };

      if ( palette === "SHO" )
         return { R:"Sii", G:"Ha",  B:"Oiii" };
      if ( palette === "HSO" )
         return { R:"Ha",  G:"Sii", B:"Oiii" };

      return { R:"Ha",  G:"Oiii", B:"Oiii" }; // HOO
   };


   // ---------------------------
   // PixelMath expression suggestions (stats-driven)
   // ---------------------------
   this.suggestPixelMathExpressionsFromStats = function( paletteOrMapping, statsByChannel )
   {
      let mapping = null;

      if ( typeof paletteOrMapping === "string" )
         mapping = this.mappingForPalette( paletteOrMapping );
      else
         mapping = paletteOrMapping;

      if ( !mapping || !mapping.R || !mapping.G || !mapping.B )
         mapping = this.mappingForPalette( "RGB" );

      // Special case: Narrowband two-channel dataset (Ha + Oiii only) -> recommend HOO-style expressions.
      // This function is stats-driven, so we detect availability via statsByChannel keys.
      let hasHa = false, hasSii = false, hasOiii = false;
      try
      {
         if ( statsByChannel && typeof statsByChannel === "object" )
         {
            hasHa   = Object.prototype.hasOwnProperty.call( statsByChannel, "Ha" );
            hasSii  = Object.prototype.hasOwnProperty.call( statsByChannel, "Sii" );
            hasOiii = Object.prototype.hasOwnProperty.call( statsByChannel, "Oiii" );
         }
      }
      catch ( __eHas ) {}

      function medOf( id )
      {
         try
         {
            if ( !statsByChannel || typeof statsByChannel !== "object" ) return NaN;
            if ( !id || !Object.prototype.hasOwnProperty.call( statsByChannel, id ) ) return NaN;
            let s = statsByChannel[id];
            if ( s && isFinite( s.median ) ) return s.median;
            if ( s && isFinite( s.mean ) ) return s.mean;
         }
         catch ( __e ) {}
         return NaN;
      }

      if ( hasHa && hasOiii && !hasSii )
      {
         // Use medians to scale Oiii into Ha's ballpark, then build a conservative HOO blend.
         let h = medOf( "Ha" );
         let o = medOf( "Oiii" );

         let eps = 1.0e-12;
         let scaleO = 1.0;

         if ( isFinite( h ) && isFinite( o ) && Math.abs( o ) > eps )
            scaleO = __clamp( h / o, 0.25, 4.00 );

         var scaled = function( id, s )
         {
            if ( !isFinite( s ) || Math.abs( s - 1.0 ) < 0.05 )
               return id;
            return "(" + id + " * " + __fmt( s ) + ")";
         };

         let O = scaled( "Oiii", scaleO );

         // Suggested HOO:
         //   R = Ha
         //   G = mostly Oiii (scaled) with a touch of Ha to keep structure and avoid harsh cyan dominance
         //   B = Oiii (scaled)
         let wH = 0.20;
         let wO = 0.80;

         return {
            R: "Ha",
            G: "(" + "Ha" + " * " + __fmt( wH ) + ") + (" + O + " * " + __fmt( wO ) + ")",
            B: O
         };
      }

      let anchor = mapping.G;
      let redCh  = mapping.R;
      let bluCh  = mapping.B;

      function strengthOf( id )
      {
         try
         {
            if ( !statsByChannel || typeof statsByChannel !== "object" )
               return NaN;

            if ( !id || !Object.prototype.hasOwnProperty.call( statsByChannel, id ) )
               return NaN;

            let s = statsByChannel[id];
            if ( s && isFinite( s.strength ) && s.strength > 0 )
               return s.strength;
         }
         catch ( __e ) {}
         return NaN;
      }

      let a = strengthOf( anchor );
      let r = strengthOf( redCh );
      let b = strengthOf( bluCh );

      // Fallback: no stats or bad stats → identity mapping
      if ( !isFinite( a ) || a <= 0 || !isFinite( r ) || !isFinite( b ) )
      {
         return { R: redCh, G: anchor, B: bluCh };
      }

      let rRatio = r / a;
      let bRatio = b / a;

      // Tunables (conservative by default)
      let trigger = 0.85; // below this ratio, we help the channel
      let maxMix  = 0.35; // maximum amount of anchor injected

      function mixAlpha( ratio )
      {
         if ( ratio >= trigger )
            return 0.0;

         let alpha = ( trigger - ratio ) / trigger * maxMix;
         return __clamp( alpha, 0.0, maxMix );
      }

      let aR = mixAlpha( rRatio );
      let aB = mixAlpha( bRatio );

      let expr = { R: "", G: anchor, B: "" };

      if ( aR > 0 )
         expr.R = "(" + redCh + " * " + __fmt( 1.0 - aR ) + ") + (" + anchor + " * " + __fmt( aR ) + ")";
      else
         expr.R = redCh;

      if ( aB > 0 )
         expr.B = "(" + bluCh + " * " + __fmt( 1.0 - aB ) + ") + (" + anchor + " * " + __fmt( aB ) + ")";
      else
         expr.B = bluCh;

      return expr;
   };

   this.applySuggestedPixelMathExpressions = function()
   {
      try
      {
let expr = this.suggestPixelMathExpressionsFromStats( this.state.palette, this.state.statsByChannel );

         if ( expr && expr.R && expr.G && expr.B )
         {
            this.state.exprR = expr.R;
            this.state.exprG = expr.G;
            this.state.exprB = expr.B;

            if ( this.exprREdit ) this.exprREdit.text = expr.R;
            if ( this.exprGEdit ) this.exprGEdit.text = expr.G;
            if ( this.exprBEdit ) this.exprBEdit.text = expr.B;

            this.appendLog( "PixelMath Expr suggestions updated from stats." );
         }
      }
      catch ( __e )
      {
         // Best effort only.
      }
   };


   this.applyPaletteDefaults = function()
   {
      let m = this.mappingForPalette( this.state.palette );

      this.state.mapR = m.R;
      this.state.mapG = m.G;
      this.state.mapB = m.B;

      this.state.exprR = m.R;
      this.state.exprG = m.G;
      this.state.exprB = m.B;

      if ( this.exprREdit ) this.exprREdit.text = this.state.exprR;
      if ( this.exprGEdit ) this.exprGEdit.text = this.state.exprG;
      if ( this.exprBEdit ) this.exprBEdit.text = this.state.exprB;

      // If PixelMath is selected, refine defaults using loaded statistics.
      this.applySuggestedPixelMathExpressions();

      this.updateCombinationPreview();
   };

   this.refreshPaletteCombo = function()
   {
      let items = this.getPalettesForCurrentState();

      this.paletteCombo.clear();
      for ( let i = 0; i < items.length; i++ )
         this.paletteCombo.addItem( items[i] );

      let preferred = items[0];
      if ( this.state.mode === "Narrowband" && this.state.masters.length === 3 ) preferred = "SHO";
      if ( this.state.mode === "Narrowband" && this.state.masters.length === 2 ) preferred = "HOO";
      if ( this.state.mode === "Broadband" ) preferred = "RGB";

      this.state.palette = preferred;

      for ( let i = 0; i < this.paletteCombo.numberOfItems; i++ )
         if ( this.paletteCombo.itemText( i ) === preferred )
            this.paletteCombo.currentItem = i;

      this.paletteCombo.enabled = ( this.state.mode !== "Broadband" );

      this.applyPaletteDefaults();
   };

   this.updateCombinationEnablement = function()
   {
      let useCC = this.state.useChannelCombination;
      this.channelCombinationGroup.enabled = useCC;
      this.pixelMathGroup.enabled = !useCC;
      this.appendLog( "Combination method set to " + ( useCC ? "ChannelCombination" : "PixelMath" ) );
      this.applySuggestedPixelMathExpressions();
   }
   this.updateMASControlsEnablement = function()
   {
      // Master switch: Apply Multiscale Adaptive Stretch governs all MAS controls below it.
      let masOn = true;
      try { masOn = ( this.masEnable ? !!this.masEnable.checked : true ); } catch ( __eM ) { masOn = true; }

      // Base MAS controls (Aggressiveness, Target Background, DRC, Contrast Recovery)
      try
      {
         if ( this.masAggressiveness ) this.masAggressiveness.enabled = masOn;
         if ( this.masTargetBg )       this.masTargetBg.enabled       = masOn;
         if ( this.masDRC )            this.masDRC.enabled            = masOn;
         if ( this.masContrast )       this.masContrast.enabled       = masOn;
      }
      catch ( __eBase ) {}

      // Contrast Recovery governs its subordinate controls (but only if MAS itself is enabled)
      try
      {
         let crOn = masOn && ( this.masContrast ? !!this.masContrast.checked : false );
         if ( this.masScaleSep )     this.masScaleSep.enabled     = crOn;
         if ( this.masIntensity )    this.masIntensity.enabled    = crOn;
         if ( this.masPreviewLarge ) this.masPreviewLarge.enabled = crOn;
      }
      catch ( __eCR ) {}

      // Enable Saturation governs its subordinate controls (but only if MAS itself is enabled)
      try
      {
         if ( this.masSaturationEnable ) this.masSaturationEnable.enabled = masOn;

         let satOn = masOn && ( this.masSaturationEnable ? !!this.masSaturationEnable.checked : false );
         if ( this.masSatAmount ) this.masSatAmount.enabled = satOn;
         if ( this.masSatBoost )  this.masSatBoost.enabled  = satOn;
         if ( this.masSatMask )   this.masSatMask.enabled   = satOn;
      }
      catch ( __eSAT ) {}
   };
;

   this.updateCombinationPreview = function()
   {
      let title = ( this.state.useChannelCombination ? "ChannelCombination mapping" : "PixelMath defaults" );
      this.combinationPreview.text =
         title + " (prototype)\n" +
         "Palette: " + this.state.palette + "\n" +
         "R ← " + this.state.mapR + "\n" +
         "G ← " + this.state.mapG + "\n" +
         "B ← " + this.state.mapB;
   };

   // ---------------------------
   // Masters validation + accept
   // ---------------------------
   this.validateSelection = function( fileNames, mode, ch )
   {
      if ( mode === "Narrowband" )
      {
         if ( fileNames.length < 2 || fileNames.length > 3 )
            return { ok:false, msg:"Narrowband mode requires selecting 2 or 3 master files.\n\nIf 2 files: Ha + Oiii.\nIf 3 files: Ha + Sii + Oiii." };

         if ( fileNames.length === 2 )
         {
            if ( !( ch.Ha && ch.Oiii ) )
               return { ok:false, msg:"Narrowband mode with 2 files requires Ha and Oiii.\n\nMake sure filenames include 'Ha' and 'Oiii' (or 'O3')." };
         }
         else
         {
            if ( !( ch.Ha && ch.Sii && ch.Oiii ) )
               return { ok:false, msg:"Narrowband mode with 3 files requires Ha, Sii and Oiii.\n\nMake sure filenames include 'Ha', 'Sii', and 'Oiii' (or 'O3')." };
         }
         return { ok:true, msg:"" };
      }
      else
      {
         if ( fileNames.length !== 3 )
            return { ok:false, msg:"Broadband mode requires exactly 3 master files (R, G, B)." };

         if ( !( ch.R && ch.G && ch.B ) )
            return { ok:false, msg:"Broadband mode requires all three channels to be detected: R, G and B.\n\nMake sure filenames contain markers like '_R', '_G', '_B' (or 'Red', 'Green', 'Blue'). Luminance is also accepted as 'L', 'Lum', or 'Luminance'." };

         return { ok:true, msg:"" };
      }
   };

   this.applyAcceptedMasters = function( fileNames, ch )
   {
      this.state.masters = fileNames;
      this.state.channels = ch;
      this.state.isValidMastersSelection = true;

      this.mastersList.clear();
      for ( let i = 0; i < this.state.masters.length; i++ )
      {
         let n = new TreeBoxNode( this.mastersList );
         n.setText( 0, this.state.masters[i] );
      }

      if ( this.state.mode === "Narrowband" )
         this.detectedChannelsValue.text = "Ha " + ( ch.Ha ? "🟢" : "○" ) + "   " + "Sii " + ( ch.Sii ? "🟢" : "○" ) + "   " + "Oiii " + ( ch.Oiii ? "🟢" : "○" );
      else
         this.detectedChannelsValue.text = "R " + ( ch.R ? "🟢" : "○" ) + "   " + "G " + ( ch.G ? "🟢" : "○" ) + "   " + "B " + ( ch.B ? "🟢" : "○" );

      for ( let i = 0; i < this.stepStatus.length; i++ )
         this.stepStatus[i] = "ready";

      this.updateHeader();
      this.updateStepButtons();
      this.updateRunEnabled();

      this.appendLog( "Accepted masters: " + this.state.masters.length + " file(s)." );

      this.loadMastersAndPopulateStats();
      this.refreshPaletteCombo();

   // Restore last configuration (Step 2..N only). Does not touch selected masters.
   try { sbppTryLoadLastConfiguration( this ); } catch ( __eLC ) {}
   try { this.updateMASControlsEnablement(); } catch ( __eMAS2 ) {}

};

   // ---------------------------
   // Header (compact)
   // ---------------------------
   this.headerModeLabel = makeLabel( this, "Mode:", 55 );
   this.headerModeValue = new Label( this );
   this.headerModeValue.text = this.state.mode;
   this.headerModeValue.minWidth = 90;
   this.headerModeValue.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.headerOutputLabel = makeLabel( this, "Output:", 60 );
   this.headerOutputValue = new Label( this );
   this.headerOutputValue.text = this.state.outputId;
   this.headerOutputValue.minWidth = 90;
   this.headerOutputValue.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.headerMastersLabel = makeLabel( this, "Masters:", 70 );
   this.headerMastersValue = new Label( this );
   this.headerMastersValue.text = "0";
   this.headerMastersValue.minWidth = 35;
   this.headerMastersValue.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.headerStepsLabel = makeLabel( this, "Steps:", 50 );
   this.headerStepsValue = new Label( this );
   this.headerStepsValue.text = "9"; 
   this.headerStepsValue.minWidth = 30;
   this.headerStepsValue.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.headerHelpButton = new ToolButton( this );
   this.headerHelpButton.icon = this.scaledResource( ":/icons/help.png" );
   this.headerHelpButton.setScaledFixedSize( 20, 20 );
   this.headerHelpButton.toolTip = "Help (prototype)";
   this.headerHelpButton.onClick = function()
   {
      new MessageBox(
         "Skynet Batch Post-Processing Script v2.0 \n\nSkynet Observatory\n\nwww.skynetobservatory.space",
         "SBPP",
         StdIcon_Information,
         StdButton_Ok
      ).execute();
   };

   this.headerSizer = new HorizontalSizer;
   this.headerSizer.spacing = 6;
   this.headerSizer.add( this.headerModeLabel );
   this.headerSizer.add( this.headerModeValue );
   this.headerSizer.add( this.headerOutputLabel );
   this.headerSizer.add( this.headerOutputValue );
   this.headerSizer.add( this.headerMastersLabel );
   this.headerSizer.add( this.headerMastersValue );
   this.headerSizer.add( this.headerStepsLabel );
   this.headerSizer.add( this.headerStepsValue );
   this.headerSizer.addStretch();
   this.headerSizer.add( this.headerHelpButton );

   // ---------------------------
   // Steps navigator
   // ---------------------------
   this.stepButtons = [];
   this.stepsGroup = new GroupBox( this );
   this.stepsGroup.title = "Steps";
   // Keep the left rail compact
   this.stepsGroup.minWidth = 220;
   this.stepsGroup.maxWidth = 220;
   this.stepsGroup.sizer = new VerticalSizer;
   this.stepsGroup.sizer.margin = 6;
   this.stepsGroup.sizer.spacing = 6;

   for ( let i = 0; i < this.stepNames.length; i++ )
   {
      let b = new RadioButton( this.stepsGroup );
      b.text = this.statusSymbol( this.stepStatus[i] ) + "  " + this.stepNames[i];
      b.checked = ( i === 0 );
      b.onCheck = (function( idx ){
         return function( checked )
         {
            if ( checked )
               this.dialog.activateStep( idx );
         };
      })( i );

      this.stepButtons.push( b );
      this.stepsGroup.sizer.add( b );
   }
   this.stepsGroup.sizer.addStretch();
   // ---------------------------
   // Prerequisites checklist
   // ---------------------------
   this.prereq =
   {
      graxpert: { ok:false, msg:"" },
      bxt:      { ok:false, msg:"" },
      nxt:      { ok:false, msg:"" },
      sxt:      { ok:false, msg:"" },
      mas:      { ok:false, msg:"" }
   };

   this.prereqGroup = new GroupBox( this );
   this.prereqGroup.title = "Prerequisites";
   // Keep the left rail compact
   this.prereqGroup.minWidth = 220;
   this.prereqGroup.maxWidth = 220;
   this.prereqGroup.sizer = new VerticalSizer;
   this.prereqGroup.sizer.margin = 6;
   this.prereqGroup.sizer.spacing = 4;

   this.prereqTree = new TreeBox( this.prereqGroup );
   this.prereqTree.alternateRowColor = true;
   this.prereqTree.numberOfColumns = 2;
   this.prereqTree.headerVisible = false;
   this.prereqTree.setHeaderText( 0, "Component" );
   this.prereqTree.setHeaderText( 1, "Status" );
   this.prereqTree.setColumnWidth( 0, 98 );
   this.prereqTree.setColumnWidth( 1, 26 );
   this.prereqTree.minHeight = 140;

   this.prereqGroup.sizer.add( this.prereqTree, 100 );

   this.__setPrereqRow = function( label, ok, detail )
   {
      let n = new TreeBoxNode( this.prereqTree );
      n.setText( 0, label );
      n.setText( 1, ok ? "🟢" : "⚠" );
      if ( detail && detail.length )
         n.toolTip = detail;
   };

   this.checkPrerequisites = function()
   {
      function hasCtor( name )
      {
         try { return ( typeof globalThis[name] === "function" ); }
         catch ( __e ) { try { return ( typeof this[name] === "function" ); } catch ( __e2 ) {} }
         return false;
      }

      // GraXpert
      if ( hasCtor( "GraXpert" ) )
         this.prereq.graxpert = { ok:true, msg:"GraXpert detected." };
      else
         this.prereq.graxpert = { ok:false, msg:"GraXpert process not found. Install GraXpert and restart PixInsight." };

      // BlurXTerminator
      if ( hasCtor( "BlurXTerminator" ) )
         this.prereq.bxt = { ok:true, msg:"BlurXTerminator detected." };
      else
         this.prereq.bxt = { ok:false, msg:"BlurXTerminator not found. Install BlurXTerminator and restart PixInsight." };

      // NoiseXTerminator
      if ( hasCtor( "NoiseXTerminator" ) )
         this.prereq.nxt = { ok:true, msg:"NoiseXTerminator detected." };
      else
         this.prereq.nxt = { ok:false, msg:"NoiseXTerminator not found. Install NoiseXTerminator and restart PixInsight." };

      // StarXTerminator
      if ( hasCtor( "StarXTerminator" ) )
         this.prereq.sxt = { ok:true, msg:"StarXTerminator detected." };
      else
         this.prereq.sxt = { ok:false, msg:"StarXTerminator not found. Install StarXTerminator and restart PixInsight." };

      // MAS v1.1 (capability based)
      if ( hasCtor( "MultiscaleAdaptiveStretch" ) )
      {
         let ok = false;
         let why = "";
         try
         {
            let P = new MultiscaleAdaptiveStretch;
            // v1.1 capabilities used by SBPP (scaleSeparation combo + contrastRecoveryIntensity slider)
            let hasScale = ( "scaleSeparation" in P );
            let hasCRI   = ( "contrastRecoveryIntensity" in P ) || ( "contrastRecovery" in P );
            ok = hasScale && hasCRI;

            if ( !ok )
               why = "MultiscaleAdaptiveStretch is present but does not expose expected v1.1 parameters (scaleSeparation and contrastRecoveryIntensity).";
         }
         catch ( __eMAS )
         {
            ok = false;
            why = "MultiscaleAdaptiveStretch constructor failed: " + __eMAS;
         }

         this.prereq.mas = ok
            ? { ok:true, msg:"MAS detected (v1.1 capabilities present)." }
            : { ok:false, msg:( why.length ? why : "MAS detected but incompatible. Update to MAS v1.1." ) };
      }
      else
         this.prereq.mas = { ok:false, msg:"MultiscaleAdaptiveStretch not found. Install MAS v1.1 and restart PixInsight." };

      return this.prereq;
   };

   this.refreshPrereqChecklist = function()
   {
      this.prereqTree.clear();

      let p = this.checkPrerequisites();

      this.__setPrereqRow( "GraXpert", p.graxpert.ok, p.graxpert.msg );
      this.__setPrereqRow( "BlurX",    p.bxt.ok,      p.bxt.msg );
      this.__setPrereqRow( "NoiseX",   p.nxt.ok,      p.nxt.msg );
      this.__setPrereqRow( "StarX",    p.sxt.ok,      p.sxt.msg );
      this.__setPrereqRow( "MAS v1.1", p.mas.ok,      p.mas.msg );

      let allOk = p.graxpert.ok && p.bxt.ok && p.nxt.ok && p.sxt.ok && p.mas.ok;
      return allOk;
   };

   this.enforcePrerequisitesForRun = function()
   {
      let ok = this.refreshPrereqChecklist();

      // Run button should never be enabled if prereqs are missing
      try { this.runButton.enabled = ok && this.state.isValidMastersSelection; } catch ( __e0 ) {}

      if ( ok )
         this.appendLog( "Pre requisites verification completed. GraXpert, BXT, NXT, SXT and MAS detected. Script can proceed." );
      else
      {
         // Build a short report for the MessageBox
         let msg = "SBPP pre requisites check failed.\n\n";
         if ( !this.prereq.graxpert.ok ) msg += "GraXpert: " + this.prereq.graxpert.msg + "\n\n";
         if ( !this.prereq.bxt.ok )      msg += "BlurX: "   + this.prereq.bxt.msg + "\n\n";
         if ( !this.prereq.nxt.ok )      msg += "NoiseX: "  + this.prereq.nxt.msg + "\n\n";
         if ( !this.prereq.sxt.ok )      msg += "StarX: "   + this.prereq.sxt.msg + "\n\n";
         if ( !this.prereq.mas.ok )      msg += "MAS v1.1: "+ this.prereq.mas.msg + "\n\n";

         new MessageBox( msg, "SBPP", StdIcon_Warning, StdButton_Ok ).execute();
      }

      return ok;
   };


   // ---------------------------
   // Tabs container
   // ---------------------------
   this.tabs = new TabBox( this );

   // ---------------------------
   // Tab 1: Masters
   // ---------------------------
   this.tabMasters = new Control( this.tabs );

   this.modeNarrowband = new RadioButton( this.tabMasters );
   this.modeNarrowband.text = "Narrowband";
   this.modeNarrowband.checked = true;
   this.modeNarrowband.onCheck = function( checked )
   {
      if ( !checked ) return;
      let d = this.dialog;
      d.state.mode = "Narrowband";
      d.headerModeValue.text = "Narrowband";
      if ( d.state.masters.length === 0 )
         d.detectedChannelsValue.text = "Ha ○   Sii ○   Oiii ○";
      d.refreshPaletteCombo();
      d.appendLog( "Mode set to Narrowband" );
   };

   this.modeBroadband = new RadioButton( this.tabMasters );
   this.modeBroadband.text = "Broadband";
   this.modeBroadband.onCheck = function( checked )
   {
      if ( !checked ) return;
      let d = this.dialog;
      d.state.mode = "Broadband";
      d.headerModeValue.text = "Broadband";
      if ( d.state.masters.length === 0 )
         d.detectedChannelsValue.text = "R ○   G ○   B ○";
      d.refreshPaletteCombo();
      d.appendLog( "Mode set to Broadband" );
   };

   let modeRow = new HorizontalSizer;
   modeRow.spacing = 6;
   modeRow.add( makeLeftLabel( this.tabMasters, "Mode:" ) );
   modeRow.add( this.modeNarrowband );
   modeRow.add( this.modeBroadband );
   modeRow.addStretch();

   this.mastersList = new TreeBox( this.tabMasters );
   this.mastersList.headerVisible = false;
   this.mastersList.numberOfColumns = 1;
   this.mastersList.alternateRowColor = true;
   this.mastersList.minHeight = 160;

   this.selectMastersButton = new PushButton( this.tabMasters );
   this.selectMastersButton.text = "Select Masters…";
   this.selectMastersButton.onClick = function()
   {
      let d = this.dialog;

      let fd = new OpenFileDialog;
      fd.multipleSelections = true;
      fd.caption = "Select Master Files (UI only)";


// Mode-specific file filters (ported from Baseline UI.js)
let filters = [];
if ( d.state.mode === "Narrowband" )
{
   filters.push( [ "Narrowband Masters (Ha, Sii/S2, Oiii/O3)", "*Ha*.* *HA*.* *Sii*.* *SII*.* *S2*.* *Oiii*.* *OIII*.* *O3*.*" ] );
   filters.push( [ "Ha Masters", "*Ha*.* *HA*.*" ] );
   filters.push( [ "Sii / S2 Masters", "*Sii*.* *SII*.* *S2*.*" ] );
   filters.push( [ "Oiii / O3 Masters", "*Oiii*.* *OIII*.* *O3*.*" ] );
}
else
{
   filters.push( [ "Broadband Masters (R, G, B, L)", "*_R*.* *_G*.* *_B*.* *_L*.* *Red*.* *Green*.* *Blue*.* *Lum*.*" ] );
   filters.push( [ "Red / R Masters", "*_R*.* *Red*.*" ] );
   filters.push( [ "Green / G Masters", "*_G*.* *Green*.*" ] );
   filters.push( [ "Blue / B Masters", "*_B*.* *Blue*.*" ] );
   filters.push( [ "L / Lum Masters", "*_L*.* *Lum*.*" ] );
}

filters.push( [ "All Files", "*" ] );
fd.filters = filters;
      if ( !fd.execute() )
         return;

      let files = fd.fileNames;
      let ch = detectChannelsFromFiles( files );

      let v = d.validateSelection( files, d.state.mode, ch );
      if ( !v.ok )
      {
         new MessageBox( v.msg, "Invalid Masters Selection", StdIcon_Error, StdButton_Ok ).execute();
         d.appendLog( "Rejected masters selection (validation failed)." );
         return;
      }

      d.applyAcceptedMasters( files, ch );
   };

   this.detectedChannelsLabel = makeLeftLabel( this.tabMasters, "Detected Channels:" );
   this.detectedChannelsValue = makeLeftLabel( this.tabMasters, "Ha ○   Sii ○   Oiii ○" );

   // Marquee wrapper: Step 1
   this.mastersBox = new GroupBox( this.tabMasters );
   this.mastersBox.title = "Step 1: Select files";
   this.mastersBox.sizer = new VerticalSizer;
   this.mastersBox.sizer.margin = 6;
   this.mastersBox.sizer.spacing = 6;

   this.mastersBox.sizer.add( modeRow );
   this.mastersBox.sizer.add( makeLeftLabel( this.tabMasters, "Selected Master Files" ) );
   this.mastersBox.sizer.add( this.mastersList );
   this.mastersBox.sizer.add( this.selectMastersButton );
   this.mastersBox.sizer.add( this.detectedChannelsLabel );
   this.mastersBox.sizer.add( this.detectedChannelsValue );
   this.mastersBox.sizer.addStretch();

   this.tabMasters.sizer = new VerticalSizer;
   this.tabMasters.sizer.margin = 8;
   this.tabMasters.sizer.spacing = 6;
   this.tabMasters.sizer.add( this.mastersBox, 100 );
   this.tabMasters.sizer.addStretch();

   // ---------------------------
   // Tab 2: GraXpert
   // ---------------------------
   this.tabGraXpert = new Control( this.tabs );

   this.gxSmoothing = slider01( this.tabGraXpert, 0.50, 2 );
   this.gxSmoothing.onValueUpdated = function( v )
   {
      this.dialog.appendLog( "GraXpert smoothing set to " + v.toFixed(2) );
   };

   this.gxBox = new GroupBox( this.tabGraXpert );
   this.gxBox.title = "Step 2: Background Extraction";
   this.gxBox.sizer = new VerticalSizer;
   this.gxBox.sizer.margin = 6;
   this.gxBox.sizer.spacing = 6;

   this.gxBox.sizer.add( makeLeftLabel( this.tabGraXpert, "GraXpert Background Extraction" ) );
   this.gxBox.sizer.add( makeLeftLabel( this.tabGraXpert, "Mandatory. Replaces images. AI model: Latest." ) );
   this.gxBox.sizer.addSpacing( 6 );
   this.gxBox.sizer.add( row2( makeLabel( this.tabGraXpert, "Smoothing:", 150 ), this.gxSmoothing ) );
   this.gxBox.sizer.addStretch();

   this.tabGraXpert.sizer = new VerticalSizer;
   this.tabGraXpert.sizer.margin = 8;
   this.tabGraXpert.sizer.spacing = 6;
   this.tabGraXpert.sizer.add( this.gxBox, 100 );
   this.tabGraXpert.sizer.addStretch();

   // ---------------------------
   // Tab 3: Corrections
   // ---------------------------
   this.tabCorrections = new Control( this.tabs );

   this.statsGroup = new GroupBox( this.tabCorrections );
   this.statsGroup.title = "Step 3: Linear Fit";
   this.statsGroup.sizer = new VerticalSizer;
   this.statsGroup.sizer.margin = 6;
   this.statsGroup.sizer.spacing = 6;

   this.statsTable = new TreeBox( this.statsGroup );
   this.statsTable.alternateRowColor = true;
   this.statsTable.headerVisible = true;
   this.statsTable.numberOfColumns = 4;
   this.statsTable.setHeaderText( 0, "Channel" );
   this.statsTable.setHeaderText( 1, "Mean" );
   this.statsTable.setHeaderText( 2, "Median" );
   this.statsTable.setHeaderText( 3, "Delta" );
   this.statsTable.minHeight = 110;
   this.statsTable.multipleSelection = false;

   this.statsLegend = new Label( this.statsGroup );
   this.statsLegend.useRichText = false;
   this.statsLegend.text = "Current Reference:";
   this.statsLegend.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.statsGroup.sizer.add( this.statsTable );
   this.statsGroup.sizer.add( this.statsLegend );
   this.statsTable.onCurrentNodeUpdated = function()
   {
      let d = this.dialog;
      let n = d.statsTable.currentNode;
      if ( n ) d.setReferenceChannel( n.text(0) );
   };
   this.statsTable.onNodeSelectionUpdated = function()
   {
      let d = this.dialog;
      let n = d.statsTable.currentNode;
      if ( n ) d.setReferenceChannel( n.text(0) );
   };

   this.rejectLow = slider01( this.tabCorrections, 0.00, 2 );
   this.rejectHigh = slider01( this.tabCorrections, 0.92, 2 );

   this.bxtGroup = new GroupBox( this.tabCorrections );
   this.bxtGroup.title = "Step 4: PSF Correction";
   this.bxtGroup.sizer = new VerticalSizer;
   this.bxtGroup.sizer.margin = 6;
   this.bxtGroup.sizer.spacing = 6;

   this.bxtGroup.sizer.add( makeLeftLabel( this.bxtGroup, "Mandatory. Mode: Correct Only." ) );

   let corrSizer = new VerticalSizer;
   corrSizer.margin = 8;
   corrSizer.spacing = 6;
   corrSizer.add( this.statsGroup );
   corrSizer.addSpacing( 6 );
   corrSizer.add( row2( makeLabel( this.tabCorrections, "Reject Low:", 150 ), this.rejectLow ) );
   corrSizer.add( row2( makeLabel( this.tabCorrections, "Reject High:", 150 ), this.rejectHigh ) );
   corrSizer.addSpacing( 6 );
   corrSizer.add( this.bxtGroup );
   corrSizer.addStretch();
   this.tabCorrections.sizer = corrSizer;

   this.statsGroup.visible = false;
   this.statsLegend.visible = false;

   // ---------------------------
   // Tab 4: Combination
   // ---------------------------
   this.tabCombination = new Control( this.tabs );

   this.paletteCombo = new ComboBox( this.tabCombination );
   this.paletteCombo.onItemSelected = function()
   {
      let d = this.dialog;
      d.state.palette = d.paletteCombo.itemText( d.paletteCombo.currentItem );
      d.applyPaletteDefaults();
      d.updateCombinationPreview();
   };

   let paletteRow = new HorizontalSizer;
   paletteRow.spacing = 8;
   paletteRow.add( makeLabel( this.tabCombination, "Palette:", 80 ) );
   paletteRow.add( this.paletteCombo, 100 );

   this.ccRadio = new RadioButton( this.tabCombination );
   this.ccRadio.text = "ChannelCombination";
   this.ccRadio.checked = true;
   this.ccRadio.onCheck = function( checked )
   {
      if ( !checked ) return;
      let d = this.dialog;
      d.state.useChannelCombination = true;
      d.updateCombinationEnablement();
      d.updateCombinationPreview();
   };

   this.pmRadio = new RadioButton( this.tabCombination );
   this.pmRadio.text = "PixelMath";
   this.pmRadio.checked = false;
   this.pmRadio.onCheck = function( checked )
   {
      if ( !checked ) return;
      let d = this.dialog;
      d.state.useChannelCombination = false;
      d.applyPaletteDefaults();
      d.updateCombinationEnablement();
      d.updateCombinationPreview();
   };

   // Backward-compatible aliases (older persistence code expects ccModeRadio/pmModeRadio)
   // Keep these references in sync with the actual UI radio buttons.
   this.ccModeRadio = this.ccRadio;
   this.pmModeRadio = this.pmRadio;

   let methodRow = new HorizontalSizer;
   methodRow.spacing = 14;
   methodRow.add( makeLeftLabel( this.tabCombination, "Method:" ) );
   methodRow.add( this.ccRadio );
   methodRow.add( this.pmRadio );
   methodRow.addStretch();

   this.channelCombinationGroup = new GroupBox( this.tabCombination );
   this.channelCombinationGroup.title = "ChannelCombination";
   this.channelCombinationGroup.sizer = new VerticalSizer;
   this.channelCombinationGroup.sizer.margin = 6;
   this.channelCombinationGroup.sizer.spacing = 8;
   this.channelCombinationGroup.sizer.add( makeLeftLabel( this.channelCombinationGroup, "Mapping follows Palette. No manual mapping in this mode." ) );

   this.pixelMathGroup = new GroupBox( this.tabCombination );
   this.pixelMathGroup.title = "PixelMath Expressions (per channel)";
   this.pixelMathGroup.sizer = new VerticalSizer;
   this.pixelMathGroup.sizer.margin = 6;
   this.pixelMathGroup.sizer.spacing = 8;

   this.exprREdit = new Edit( this.pixelMathGroup );
   this.exprGEdit = new Edit( this.pixelMathGroup );
   this.exprBEdit = new Edit( this.pixelMathGroup );

   this.pixelMathGroup.sizer.add( row2( makeLabel( this.pixelMathGroup, "R expr:", 80 ), this.exprREdit ) );
   this.pixelMathGroup.sizer.add( row2( makeLabel( this.pixelMathGroup, "G expr:", 80 ), this.exprGEdit ) );
   this.pixelMathGroup.sizer.add( row2( makeLabel( this.pixelMathGroup, "B expr:", 80 ), this.exprBEdit ) );

   this.combinationPreview = new Label( this.tabCombination );
   this.combinationPreview.useRichText = false;
   this.combinationPreview.textAlignment = TextAlign_Left | TextAlign_Top;
   this.combinationPreview.minHeight = 90;

   // Marquee wrapper: Step 5
   this.combBox = new GroupBox( this.tabCombination );
   this.combBox.title = "Step 5: Channel Combination";
   this.combBox.sizer = new VerticalSizer;
   this.combBox.sizer.margin = 6;
   this.combBox.sizer.spacing = 6;

   this.combBox.sizer.add( paletteRow );
   this.combBox.sizer.add( methodRow );
   this.combBox.sizer.add( this.channelCombinationGroup );
   this.combBox.sizer.add( this.pixelMathGroup );
   this.combBox.sizer.add( makeLeftLabel( this.tabCombination, "Preview:" ) );
   this.combBox.sizer.add( this.combinationPreview );
   this.combBox.sizer.addStretch();

   let combSizer = new VerticalSizer;
   combSizer.margin = 8;
   combSizer.spacing = 6;
   combSizer.add( this.combBox, 100 );
   combSizer.addStretch();
   this.tabCombination.sizer = combSizer;

   // ---------------------------
   // Tab 5: SPCC
   // ---------------------------
   this.tabSPCC = new Control( this.tabs );

   let spccMsg = new Label( this.tabSPCC );
   spccMsg.useRichText = false;
   spccMsg.text = "SPCC settings applied according to mode.\nBackground reference region searched automatically";
   spccMsg.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.spccBox = new GroupBox( this.tabSPCC );
   this.spccBox.title = "Step 6: Color Correction";
   this.spccBox.sizer = new VerticalSizer;
   this.spccBox.sizer.margin = 6;
   this.spccBox.sizer.spacing = 6;
   this.spccBox.sizer.add( spccMsg );
   this.spccBox.sizer.addStretch();

   let spccSizer = new VerticalSizer;
   spccSizer.margin = 8;
   spccSizer.spacing = 6;
   spccSizer.add( this.spccBox, 100 );
   spccSizer.addStretch();
   this.tabSPCC.sizer = spccSizer;

   // ---------------------------
   // Tab 6: Tuning (Linear)
   // ---------------------------
   this.tabLinearTuning = new Control( this.tabs );

   this.ltNRGroup = new GroupBox( this.tabLinearTuning );
   this.ltNRGroup.title = "Step 7: Noise Reduction (Linear)";
   this.ltNRGroup.sizer = new VerticalSizer;
   this.ltNRGroup.sizer.margin = 6;
   this.ltNRGroup.sizer.spacing = 8;

   this.ltDenoise = slider01( this.ltNRGroup, 0.50, 2 );

   this.ltIterations = new SpinBox( this.ltNRGroup );
   this.ltIterations.minValue = 1;
   this.ltIterations.maxValue = 5;
   this.ltIterations.value = 1;
   this.ltIterations.minWidth = 70;

   let nrRow = new HorizontalSizer;
   nrRow.spacing = 6;
   nrRow.add( makeLabel( this.ltNRGroup, "Denoise:", 110 ) );
   nrRow.add( this.ltDenoise, 100 );
   nrRow.add( makeLabel( this.ltNRGroup, "Iterations:", 80 ) );
   nrRow.add( this.ltIterations );
   nrRow.addStretch();

   this.ltNRGroup.sizer.add( nrRow );
   this.ltNRGroup.sizer.add( makeLeftLabel( this.ltNRGroup, "Tip: use 2 iterations only if the background is clearly noisy" ) );

   this.ltSharpGroup = new GroupBox( this.tabLinearTuning );
   this.ltSharpGroup.title = "Step 8: Sharpening (Linear)";
   this.ltSharpGroup.sizer = new VerticalSizer;
   this.ltSharpGroup.sizer.margin = 6;
   this.ltSharpGroup.sizer.spacing = 8;

   function smallEdit( parent, txt )
   {
      let e = new Edit( parent );
      e.text = txt;
      e.minWidth = 80;
      return e;
   }

   this.ltSharpenStars = smallEdit( this.ltSharpGroup, "0.50" );
   this.ltSharpenNonstellar = smallEdit( this.ltSharpGroup, "0.50" );
   this.ltAdjustStarHalos = smallEdit( this.ltSharpGroup, "-0.10" );

   let sharpRow1 = new HorizontalSizer;
   sharpRow1.spacing = 6;
   sharpRow1.add( makeLabel( this.ltSharpGroup, "Sharpen Stars:", 130 ) );
   sharpRow1.add( this.ltSharpenStars );
   sharpRow1.addStretch();
   sharpRow1.add( makeLabel( this.ltSharpGroup, "Adjust Star Halos:", 140 ) );
   sharpRow1.add( this.ltAdjustStarHalos );

   let sharpRow2 = new HorizontalSizer;
   sharpRow2.spacing = 6;
   sharpRow2.add( makeLabel( this.ltSharpGroup, "Sharpen Nonstellar:", 130 ) );
   sharpRow2.add( this.ltSharpenNonstellar );
   sharpRow2.addStretch();

   this.ltSharpGroup.sizer.add( sharpRow1 );
   this.ltSharpGroup.sizer.add( sharpRow2 );
   this.ltSharpGroup.sizer.add( makeLeftLabel( this.ltSharpGroup, "Tip: negative halos reduces star bloat; keep star sharpening modest" ) );

   this.ltStarGroup = new GroupBox( this.tabLinearTuning );
   this.ltStarGroup.title = "Step 9: Star Extraction";
   this.ltStarGroup.sizer = new VerticalSizer;
   this.ltStarGroup.sizer.margin = 6;
   this.ltStarGroup.sizer.spacing = 8;

   this.ltGenStarImage = new CheckBox( this.ltStarGroup );
   this.ltGenStarImage.text = "Generate Star Image";
   this.ltGenStarImage.checked = true;

   this.ltUnscreenStars = new CheckBox( this.ltStarGroup );
   this.ltUnscreenStars.text = "Unscreen Stars";
   this.ltUnscreenStars.checked = true;

   this.ltLargeOverlap = new CheckBox( this.ltStarGroup );
   this.ltLargeOverlap.text = "Large Overlap";
   this.ltLargeOverlap.checked = true;

   // Internal state for dependent enable toggling
   this.__starExtractionPrevGen = true;


   // Star Extraction UI validation: if Generate Star Image is unchecked,
   // force dependent options off and disable them.
   this.__updateStarExtractionUI = function()
   {
      var gen = false;
      try { gen = !!this.ltGenStarImage.checked; } catch ( __e0 ) { gen = false; }

      var prev = true;
      try { prev = !!this.__starExtractionPrevGen; } catch ( __eP ) { prev = true; }

      if ( !gen )
      {
         try { this.ltUnscreenStars.checked = false; } catch ( __e1 ) {}
         try { this.ltLargeOverlap.checked = false; } catch ( __e2 ) {}
      }
      else
      {
         // When enabling dependent options, default them to ON.
         if ( !prev )
         {
            try { this.ltUnscreenStars.checked = true; } catch ( __e3a ) {}
            try { this.ltLargeOverlap.checked = true; } catch ( __e4a ) {}
         }
      }

      try { this.ltUnscreenStars.enabled = gen; } catch ( __e3 ) {}
      try { this.ltLargeOverlap.enabled = gen; } catch ( __e4 ) {}

      try { this.__starExtractionPrevGen = gen; } catch ( __eS ) {}
   };

   this.ltGenStarImage.onCheck = function( checked )
   {
      var dlg = this.dialog;
      if ( dlg )
         dlg.__updateStarExtractionUI();
   };

   try { this.__updateStarExtractionUI(); } catch ( __e5 ) {}

   let starRow = new HorizontalSizer;
   starRow.spacing = 16;
   starRow.add( this.ltGenStarImage );
   starRow.add( this.ltUnscreenStars );
   starRow.add( this.ltLargeOverlap );
   starRow.addStretch();

   this.ltStarGroup.sizer.add( starRow );
   this.ltStarGroup.sizer.add( makeLeftLabel( this.ltStarGroup, "Large Overlap uses 0.50 (unchecked uses 0.20)" ) );

   let ltSizer = new VerticalSizer;
   ltSizer.margin = 8;
   ltSizer.spacing = 6;
   ltSizer.add( this.ltNRGroup );
   ltSizer.add( this.ltSharpGroup );
   ltSizer.add( this.ltStarGroup );
   ltSizer.addStretch();
   this.tabLinearTuning.sizer = ltSizer;

   // ---------------------------
   // Tab 7: Stretching
   // ---------------------------
   this.tabStretch = new Control( this.tabs );

   let htGroup = new GroupBox( this.tabStretch );
   htGroup.title = "10.1 Histogram Transformation";
   htGroup.sizer = new VerticalSizer;
   htGroup.sizer.margin = 6;
   htGroup.sizer.spacing = 8;

   this.htEnable = new CheckBox( htGroup );
   this.htEnable.text = "Apply a HistogramTransformation stretch (STF to HT style)";
   this.htEnable.checked = true;

   this.htTbgnd = new Edit( htGroup );
   this.htTbgnd.text = "0.20";
   this.htTbgnd.minWidth = 80;

   let htRow = new HorizontalSizer;
   htRow.spacing = 6;
   htRow.add( this.htEnable );
   htRow.addStretch();
   htRow.add( makeLabel( htGroup, "TBGND:", 70 ) );
   htRow.add( this.htTbgnd );

   htGroup.sizer.add( htRow );

   let masGroup = new GroupBox( this.tabStretch );
   masGroup.title = "10.2 Multiscale Adaptive Stretch";
   masGroup.sizer = new VerticalSizer;
   masGroup.sizer.margin = 6;
   masGroup.sizer.spacing = 8;

   this.masEnable = new CheckBox( masGroup );
   this.masEnable.text = "Apply Multiscale Adaptive Stretch";
   this.masEnable.checked = true;
   // Stretching validation: at least one of HT or MAS must be selected.
   // If both are unchecked, we force MAS back on (safe default).
   this.__stretchGuard = false;
   this.__enforceStretchSelection = function()
   {
      if ( this.__stretchGuard )
         return;

      if ( !this.htEnable.checked && !this.masEnable.checked )
      {
         this.__stretchGuard = true;
         this.masEnable.checked = true;
         this.__stretchGuard = false;
      }
   };

   this.htEnable.onCheck = function( checked )
   {
      var dlg = this.dialog;
      if ( dlg )
      {
         dlg.__enforceStretchSelection();
         try { if ( dlg.updateMASControlsEnablement ) dlg.updateMASControlsEnablement(); } catch ( __eHEv ) {}
      }
   };

   this.masEnable.onClick = function( checked )
   {
      var dlg = this.dialog;
      if ( dlg )
      {
         dlg.__enforceStretchSelection();
         try { if ( dlg.updateMASControlsEnablement ) dlg.updateMASControlsEnablement(); } catch ( __eMEv ) {}
      }
   };



   this.masAggressiveness = slider01( masGroup, 0.70, 2 );
   this.masTargetBg = slider01( masGroup, 0.20, 2 );
   this.masDRC = slider01( masGroup, 0.40, 2 );

   masGroup.sizer.add( this.masEnable );
   masGroup.sizer.add( row2( makeLabel( masGroup, "Aggressiveness:", 140 ), this.masAggressiveness ) );
   masGroup.sizer.add( row2( makeLabel( masGroup, "Target Background:", 140 ), this.masTargetBg ) );
   masGroup.sizer.add( row2( makeLabel( masGroup, "Dynamic Range Compression:", 140 ), this.masDRC ) );

   this.masContrast = new CheckBox( masGroup );
   this.masContrast.text = "Contrast Recovery";
   this.masContrast.checked = true;
   this.masContrast.onClick = function( checked )
   {
      let d = this.dialog;
      try { d.state.masContrastRecovery = !!checked; } catch ( __e0 ) {}
      try { d.updateMASControlsEnablement(); } catch ( __e1 ) {}
   };

   this.masScaleSep = new ComboBox( masGroup );
   this.masScaleSep.addItem( "128" );
   this.masScaleSep.addItem( "256" );
   this.masScaleSep.addItem( "512" );
   this.masScaleSep.addItem( "1024" );
   this.masScaleSep.currentItem = 3;

   this.masIntensity = slider01( masGroup, 1.00, 2 );

   let crRow = new HorizontalSizer;
   crRow.spacing = 6;
   crRow.add( this.masContrast );
   crRow.addStretch();
   crRow.add( makeLabel( masGroup, "Scale Separation:", 120 ) );
   crRow.add( this.masScaleSep );
   crRow.add( makeLabel( masGroup, "Intensity:", 80 ) );
   crRow.add( this.masIntensity );
   masGroup.sizer.addSpacing( 8 );

   masGroup.sizer.add( crRow );

   this.masPreviewLarge = new CheckBox( masGroup );
   this.masPreviewLarge.text = "Preview Large Scale";
   this.masPreviewLarge.checked = false;
   masGroup.sizer.add( this.masPreviewLarge );

   this.masSaturationEnable = new CheckBox( masGroup );
   this.masSaturationEnable.text = "Enable Saturation";
   this.masSaturationEnable.checked = true;
   this.masSaturationEnable.onClick = function( checked )
   {
      let d = this.dialog;
      try { d.state.masSaturationEnabled = !!checked; } catch ( __e0 ) {}
      try { d.updateMASControlsEnablement(); } catch ( __e1 ) {}
   };

   this.masSatAmount = slider01( masGroup, 0.75, 2 );
   this.masSatBoost = slider01( masGroup, 0.50, 2 );
   masGroup.sizer.addSpacing( 8 );

   masGroup.sizer.add( this.masSaturationEnable );
   masGroup.sizer.add( row2( makeLabel( masGroup, "Saturation Amount:", 140 ), this.masSatAmount ) );
   masGroup.sizer.add( row2( makeLabel( masGroup, "Saturation Boost:", 140 ), this.masSatBoost ) );

   this.masSatMask = new CheckBox( masGroup );
   this.masSatMask.text = "Lightness Mask";
   this.masSatMask.checked = true;
   masGroup.sizer.add( this.masSatMask );

   let stretchSizer = new VerticalSizer;
   stretchSizer.margin = 8;
   stretchSizer.spacing = 6;
   stretchSizer.add( htGroup );
   stretchSizer.add( masGroup );
   stretchSizer.addStretch();
   this.tabStretch.sizer = stretchSizer;

   // ---------------------------
   // Tab 8: Tuning (Non-Linear)
   // ---------------------------
   this.tabNonLinearTuning = new Control( this.tabs );

   let nlNRGroup = new GroupBox( this.tabNonLinearTuning );
   nlNRGroup.title = "Step 11: Noise Reduction (Nonlinear)";
   nlNRGroup.sizer = new VerticalSizer;
   nlNRGroup.sizer.margin = 6;
   nlNRGroup.sizer.spacing = 8;

   this.nlNrEnable = new CheckBox( nlNRGroup );
   this.nlNrEnable.text = "Apply Noise Reduction (Nonlinear)";
   this.nlNrEnable.checked = true;

   this.nlNrDenoise = slider01( nlNRGroup, 0.30, 2 );

   this.nlNrIterations = new SpinBox( nlNRGroup );
   this.nlNrIterations.minValue = 1;
   this.nlNrIterations.maxValue = 5;
   this.nlNrIterations.value = 1;
   this.nlNrIterations.minWidth = 70;

   let nlNrRow = new HorizontalSizer;
   nlNrRow.spacing = 6;
   nlNrRow.add( this.nlNrEnable );
   nlNrRow.addStretch();
   nlNrRow.add( makeLabel( nlNRGroup, "Denoise:", 80 ) );
   nlNrRow.add( this.nlNrDenoise, 100 );
   nlNrRow.add( makeLabel( nlNRGroup, "Iterations:", 80 ) );
   nlNrRow.add( this.nlNrIterations );

   nlNRGroup.sizer.add( nlNrRow );
   nlNRGroup.sizer.add( makeLeftLabel( nlNRGroup, "Tip: keep nonlinear denoise modest to avoid smearing dust" ) );

   let nlSharpGroup = new GroupBox( this.tabNonLinearTuning );
   nlSharpGroup.title = "Step 12: Sharpening (Nonlinear)";
   nlSharpGroup.sizer = new VerticalSizer;
   nlSharpGroup.sizer.margin = 6;
   nlSharpGroup.sizer.spacing = 8;

   this.nlSharpEnable = new CheckBox( nlSharpGroup );
   this.nlSharpEnable.text = "Apply Sharpening (Nonlinear)";
   this.nlSharpEnable.checked = true;

   this.nlSharpenStars = smallEdit( nlSharpGroup, "0.00" );
   this.nlAdjustStarHalos = smallEdit( nlSharpGroup, "0.00" );
   this.nlSharpenNonstellar = smallEdit( nlSharpGroup, "0.25" );

   let nlRow1 = new HorizontalSizer;
   nlRow1.spacing = 6;
   nlRow1.add( this.nlSharpEnable );
   nlRow1.addStretch();
   nlRow1.add( makeLabel( nlSharpGroup, "Sharpen Stars:", 120 ) );
   nlRow1.add( this.nlSharpenStars );
   nlRow1.add( makeLabel( nlSharpGroup, "Adjust Star Halos:", 140 ) );
   nlRow1.add( this.nlAdjustStarHalos );

   let nlRow2 = new HorizontalSizer;
   nlRow2.spacing = 6;
   nlRow2.addStretch();
   nlRow2.add( makeLabel( nlSharpGroup, "Sharpen Nonstellar:", 120 ) );
   nlRow2.add( this.nlSharpenNonstellar );
   nlRow2.addStretch();

   nlSharpGroup.sizer.add( nlRow1 );
   nlSharpGroup.sizer.add( nlRow2 );
   nlSharpGroup.sizer.add( makeLeftLabel( nlSharpGroup, "Tip: keep nonlinear sharpening conservative to avoid artifacts" ) );

   let nlLumGroup = new GroupBox( this.tabNonLinearTuning );
   nlLumGroup.title = "Step 13: Lum Sharpening";
   nlLumGroup.sizer = new VerticalSizer;
   nlLumGroup.sizer.margin = 6;
   nlLumGroup.sizer.spacing = 8;

   this.lumSharpEnable = new CheckBox( nlLumGroup );
   this.lumSharpEnable.text = "Apply Luminance Sharpening";
   this.lumSharpEnable.checked = false;

   nlLumGroup.sizer.add( this.lumSharpEnable );

   function bindEnableToggle( cb, controls )
   {
      cb.onCheck = function( checked )
      {
         for ( let i = 0; i < controls.length; i++ )
            controls[i].enabled = checked;
      };
      cb.onCheck( cb.checked );
   }
   bindEnableToggle( this.nlNrEnable, [ this.nlNrDenoise, this.nlNrIterations ] );
   bindEnableToggle( this.nlSharpEnable, [ this.nlSharpenStars, this.nlSharpenNonstellar, this.nlAdjustStarHalos ] );

   let nlSizer = new VerticalSizer;
   nlSizer.margin = 8;
   nlSizer.spacing = 6;
   nlSizer.add( nlNRGroup );
   nlSizer.add( nlSharpGroup );
   nlSizer.add( nlLumGroup );
   nlSizer.addStretch();
   this.tabNonLinearTuning.sizer = nlSizer;

   // ---------------------------
   // Tab 9: Run
   // ---------------------------
   this.tabRun = new Control( this.tabs );
   this.runSummaryGroup = new GroupBox( this.tabRun );
   this.runSummaryGroup.title = "Workflow Pipeline";
   this.runSummaryGroup.sizer = new VerticalSizer;
   this.runSummaryGroup.sizer.margin = 6;
   this.runSummaryGroup.sizer.spacing = 6;

   this.runSummaryTable = new TreeBox( this.runSummaryGroup );
   this.runSummaryTable.alternateRowColor = true;
   this.runSummaryTable.headerVisible = true;
   this.runSummaryTable.numberOfColumns = 4;
   this.runSummaryTable.setHeaderText( 0, "Step" );
   this.runSummaryTable.setHeaderText( 1, "Start" );
   this.runSummaryTable.setHeaderText( 2, "Finish" );
   this.runSummaryTable.setHeaderText( 3, "Duration" );
   // Column widths (make Step column ~3x wider for readability)
   this.runSummaryTable.setColumnWidth( 0, 420 );
   this.runSummaryTable.setColumnWidth( 1, 90 );
   this.runSummaryTable.setColumnWidth( 2, 90 );
   this.runSummaryTable.setColumnWidth( 3, 110 );
   this.runSummaryTable.minHeight = 160;

   // Populate rows for steps 2..12 using actual step names
   // Mapping:
   // 2 Background Extraction
   // 3 Linear Fit
   // 4 PSF Correction
   // 5 Channel Combination
   // 6 Color Correction
   // 7 Noise Reduction (Linear)
   // 8 Sharpening (Linear)
   // 9 Star Extraction
   // 10 Histogram Transformation / MAS
   // 11 Noise Reduction (Nonlinear)
   // 12 Sharpening (Nonlinear)

   let runSteps =
   [
      "Step 2: Background Extraction",
      "Step 3: Linear Fit",
      "Step 4: PSF Correction",
      "Step 5: Channel Combination",
      "Step 6: Color Correction",
      "Step 7: Noise Reduction (Linear)",
      "Step 8: Sharpening (Linear)",
      "Step 9: Star Extraction",
      "Step 10: Stretching",
      "Step 11: Noise Reduction (Nonlinear)",
      "Step 12: Sharpening (Nonlinear)",
      "Step 13: Lum Sharpening"
   ];

   for ( let si = 0; si < runSteps.length; si++ )
   {
      let n = new TreeBoxNode( this.runSummaryTable );
      n.setText( 0, runSteps[si] );
      n.setText( 1, "" );
      n.setText( 2, "" );
      n.setText( 3, "" );
   }

   this.runSummaryGroup.sizer.add( this.runSummaryTable );

   // Buttons
   this.runButton = new PushButton( this.tabRun );
   this.runButton.text = "RUN";
   this.runButton.enabled = false;
   this.runButton.onClick = function()
   {
                  this.dialog.runWorkflow();

   };



   {
      let d = this.dialog;
      let stampRow = function( idx, start, finish, dur )
      {
         let node = d.runSummaryTable.child( idx );
         if ( node )
         {
            node.setText( 1, start );
            node.setText( 2, finish );
            node.setText( 3, dur );
         }
      }


   };

   let runButtons = new HorizontalSizer;
   runButtons.spacing = 6;
   runButtons.add( this.runButton );
   runButtons.addStretch();

   // Progress messages (moved to lower area)
   this.progressBox = new TextBox( this.tabRun );

   // Flush buffered logs (if any)
   if ( this.__logBuffer && this.__logBuffer.length )
   {
      for ( let i = 0; i < this.__logBuffer.length; i++ )
         this.progressBox.text += this.__logBuffer[i] + "\n";
      this.__logBuffer = [];
      this.progressBox.cursorPosition = this.progressBox.text.length;
   }
   this.progressBox.readOnly = true;
   this.progressBox.minHeight = 180;

   let runSizer = new VerticalSizer;
   runSizer.margin = 8;
   runSizer.spacing = 6;
   runSizer.add( runButtons );
   runSizer.add( this.runSummaryGroup );
   runSizer.addSpacing( 6 );
   runSizer.add( makeLeftLabel( this.tabRun, "Progress" ) );
   runSizer.add( this.progressBox );
   runSizer.addStretch();

   // Elapsed time (cumulative) label (bottom right)
   this.elapsedTimeLabel = new Label( this.tabRun );
   this.elapsedTimeLabel.text = "Elapsed Time: 00:00";
   this.elapsedTimeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   let elapsedSizer = new HorizontalSizer;
   elapsedSizer.addStretch();
   elapsedSizer.add( this.elapsedTimeLabel );

   runSizer.add( elapsedSizer );

   this.tabRun.sizer = runSizer;

   // ---------------------------
   // Add pages
   // ---------------------------
   this.tabs.addPage( this.tabMasters,         "Masters" );
   this.tabs.addPage( this.tabGraXpert,        "GraXpert" );
   this.tabs.addPage( this.tabCorrections,     "Corrections" );
   this.tabs.addPage( this.tabCombination,     "Combination" );
   this.tabs.addPage( this.tabSPCC,            "SPCC" );
   this.tabs.addPage( this.tabLinearTuning,    "Tuning (Linear)" );
   this.tabs.addPage( this.tabStretch,         "Stretching" );
   this.tabs.addPage( this.tabNonLinearTuning, "Tuning (Non-Linear)" );
   this.tabs.addPage( this.tabRun,             "Run" );

   this.tabs.onPageSelected = function()
   {
      this.dialog.state.activeStepIndex = this.currentPageIndex;
      this.dialog.updateStepButtons();
   };

   // Bottom buttons
   this.resetButton = new PushButton( this );
   this.resetButton.text = "Reset";
   this.resetButton.onClick = function()
   {
      let d = this.dialog;
      if ( d && !d.__isRunning )
         d.resetToStartupDefaults();
   };

   this.cancelButton = new PushButton( this );
   this.cancelButton.text = "Cancel";
   this.cancelButton.enabled = false;
   this.cancelButton.onClick = function()
   {
      let d = this.dialog;
      if ( d && d.__isRunning )
      {
         d.__cancelRequested = true;
         d.appendLog( "Cancel requested. Stopping after current operation…" );
      }
   };

   this.closeButton = new PushButton( this );
   this.closeButton.text = "Close";
   this.closeButton.onClick = function()
   {
      let d = this.dialog;
      if ( d && !d.__isRunning )
         this.dialog.ok();
   };

   let bottomSizer = new HorizontalSizer;
   bottomSizer.addStretch();
   bottomSizer.add( this.resetButton );
   bottomSizer.addSpacing( 6 );
   bottomSizer.add( this.cancelButton );
   bottomSizer.addSpacing( 6 );
   bottomSizer.add( this.closeButton );

   // Prevent closing while running (including window "X")
   this.onClose = function()
   {
      return !this.__isRunning;
   };

// Main layout
   let contentSizer = new HorizontalSizer;
   contentSizer.spacing = 8;
   let leftSizer = new VerticalSizer;
   leftSizer.spacing = 8;
   leftSizer.add( this.stepsGroup );
   leftSizer.add( this.prereqGroup );

   contentSizer.add( leftSizer );
   contentSizer.add( this.tabs, 100 );

   this.sizer = new VerticalSizer;
this.sizer.margin = 8;
   this.sizer.spacing = 6;
   this.sizer.add( this.headerSizer );
   this.sizer.add( contentSizer, 100 );
   this.sizer.add( bottomSizer );

   // Initial state
   this.updateHeader();
   this.updateStepButtons();
   this.hideCorrectionsStats();
   this.updateRunEnabled();
   // Validate prerequisites at startup and populate checklist
   if ( this.enforcePrerequisitesForRun )
      this.enforcePrerequisitesForRun();

   this.refreshPaletteCombo();

   // Restore last configuration (Step 2..N only). Does not touch selected masters.
   try { sbppTryLoadLastConfiguration( this ); } catch ( __eLC ) {}

   // Final dialog sizing: request 960x700, but never clip controls. 
   try
   {
      this.adjustToContents();

      var minW = this.width;
      var minH = this.height;

      var w = ( minW > 1000 ) ? minW : 1000;
      var h = ( minH > 700 ) ? minH : 700;

      this.resize( w, h );
   }
   catch ( __e ) {}
this.applyPaletteDefaults();
   this.updateCombinationEnablement();
   this.updateCombinationPreview();

      // Capture startup defaults for Reset
   try { this.captureStartupDefaults(); } catch ( __eSD ) {}
   this.setExecutionState( false );

this.activateStep( 0 );
}

SBPP_UI_Prototype_Dialog.prototype = new Dialog;
new SBPP_UI_Prototype_Dialog().execute();

})();


// ---- Cleanup ----
try
{
   var wMask = ImageWindow.windowById( baseId + "_Lum_mask" );
   if ( wMask && !wMask.isNull )
      wMask.forceClose();
} catch ( __eCl1 ) {}

try
{
   var wUSM = ImageWindow.windowById( baseId + "_Lum_USM" );
   if ( wUSM && !wUSM.isNull )
      wUSM.forceClose();
} catch ( __eCl2 ) {}

try
{
   var wMLT = ImageWindow.windowById( baseId + "_Lum_MLT" );
   if ( wMLT && !wMLT.isNull )
      wMLT.forceClose();
} catch ( __eCl3 ) {}

try
{
   var wLum = ImageWindow.windowById( baseId + "_Lum" );
   if ( wLum && !wLum.isNull )
      wLum.forceClose();
} catch ( __eCl4 ) {}
